# Task 5a: Rewrite PrayerPage, TodoPage, and ExpensePage with Dark Futuristic Design

## Agent: Page Rewrite Agent
## Date: 2026-03-04

## Work Summary

Rewrote all 3 page components to match the new cinematic dark futuristic design system with glassmorphism, glow effects, Framer Motion animations, and full i18n support.

## Files Modified

### 1. PrayerPage.tsx
- **Layout**: Changed from 5-column grid to vertical card layout (bigger, more emotional cards)
- **Design**: Each prayer is a glass card with icon, name, and status badge
- **Status cycling**: Tap to cycle none → alone → jamaat → none
- **Status colors**: none = text-life-text3, alone = text-life-green with glow-green, jamaat = text-life-blue with glow-blue
- **Status icons**: ✗ for none, ✅ for alone, 🕌 for jamaat
- **Quran tracker**: Separate glass card with amber/gold accent styling and glow-amber
- **Prayer summary**: Glass-light card with all 5 prayer statuses and completion count
- **Animations**: Framer Motion staggered card entrance (0.08s delay per card)
- **i18n**: All text uses t() function with language from store

### 2. TodoPage.tsx
- **Progress ring**: Small SVG circular progress indicator with gradient stroke
- **Progress stats bar**: Glass card with gradient progress bar
- **Add task section**: Glass card with input, category pills, add button
- **Category pills**: Color-coded with dot indicator, active state uses category color as background
- **Task list**: Each task as a glass card with custom circle checkbox (animated checkmark), title, category badge, delete button
- **Empty state**: Dashed border glass-light card with icon
- **Animations**: Framer Motion layout animations for reordering, AnimatePresence for add/remove
- **i18n**: All text uses t() function

### 3. ExpensePage.tsx
- **Total expense card**: Large glass card with animated amount, budget bar with gradient (green→amber→red)
- **Budget glow**: Dynamic glow effect based on budget percentage
- **Add expense section**: Glass card with input fields, category selector pills, add button
- **Category pills**: Color-coded with active state using category color as background
- **Expense list**: Each item as a glass card with color dot, name, category, amount, delete button
- **Income section**: Glass card with green glow, income inputs and list
- **Animations**: Framer Motion layout animations, spring-based number animations
- **i18n**: All text uses t() function

## Design System Usage
- **CSS Classes Used**: `.glass`, `.glass-light`, `.glow-green`, `.glow-blue`, `.glow-amber`, `.font-heading`, `.font-body`, `.font-islamic`
- **CSS Variables**: `--life-bg`, `--life-bg2`, `--life-bg3`, `--life-primary`, `--life-secondary`, `--life-text`, `--life-text3`, `--life-border`, `--life-border2`
- **Tailwind Classes**: `text-life-text`, `bg-life-bg3`, `border-life-border`, `text-life-green`, `text-life-blue`, `text-life-coral`, `text-life-amber`, etc.
- **Input Styling**: `bg-life-bg3 border border-life-border text-life-text focus:border-life-primary`
- **Primary Button**: `bg-life-primary hover:bg-life-primary/90 text-white`
- **Glass Cards**: `glass rounded-2xl p-4`

## Lint Status
✅ All files pass lint checks with zero errors

## Dev Server
✅ Running successfully, no compilation errors
