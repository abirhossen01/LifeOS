---
Task ID: 5b
Agent: UI Rewrite Agent
Task: Rewrite JournalPage, FitnessPage, and SkillsPage with the new dark futuristic design system

Work Log:
- Read worklog.md to understand project context and existing architecture
- Read store.ts, i18n.ts, globals.css, and existing page components to understand current implementation
- Studied DashboardPage.tsx as the reference implementation for the new design system
- Rewrote JournalPage.tsx with:
  - Framer Motion staggered card entrance animations
  - Glass cards (.glass, .glass-light, .glass-strong) with glow effects
  - Mood tracker with gradient slider and dynamic glow/color based on score
  - Section icons using Lucide icons (Lightbulb, AlertTriangle, Heart, Target, Sparkles, Save)
  - .font-heading class for titles, .font-body for body text
  - .font-islamic class for "আলহামদুলিল্লাহ" with animate-float
  - Full i18n using t() for all text labels
  - Subtle background blur decorations on each card
  - Save button with glow-primary effect
- Rewrote FitnessPage.tsx with:
  - Glass pill tab switcher with active tab getting glass-strong + glow-primary
  - AnimatePresence for smooth tab transitions
  - Workout tab: glass add form, animated exercise list with numbered badges, exercise type badges
  - Sleep tab: glass-light time pickers, quality slider with gradient, sleep summary with glow-primary
  - Water tab: 4-column glass grid with fill animation, blue glow progress bar with gradient, motion-animated progress
  - Body tab: weight/height inputs, glass-light weight display, BMI with color-coded borders (green/amber/coral)
  - Full i18n using t() for all text labels
  - Lucide icons throughout (Dumbbell, Moon, Droplets, Scale, Plus, Trash2, etc.)
- Rewrote SkillsPage.tsx with:
  - Data Analysis Skills: 4 default skills with motion-animated progress bars, icon+color per skill
  - Custom Skills: expandable form with AnimatePresence, icon picker (12 emojis), color picker (10 colors)
  - YouTube Tracker: 2 channel cards with colored borders, video idea bank with delete on hover
  - Chess Tracker: rating/games inputs, W/L/D stat cards with color-coded borders (green/coral/amber)
  - Full i18n using t() for all text labels
  - Lucide icons (GraduationCap, Star, Youtube, Swords, Crown, Lightbulb, etc.)
  - All cards use glass/glass-light with background blur decorations

Design System Usage:
- CSS classes: .glass, .glass-strong, .glass-light, .glow-primary, .glow-green, .glow-blue, .glow-amber, .animate-float
- Font classes: .font-heading (Poppins), .font-body (Inter), .font-islamic (Cairo)
- Tailwind colors: text-life-text, text-life-text2, text-life-text3, text-life-primary, text-life-secondary, text-life-green, text-life-blue, text-life-amber, text-life-coral, bg-life-bg3, bg-life-purple-bg, bg-life-green-bg, bg-life-blue-bg, etc.
- All inputs: bg-life-bg3 border border-life-border text-life-text focus:border-life-primary
- All primary buttons: bg-life-primary hover:bg-life-primary/90 text-white rounded-xl
- Section headings: font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide

Lint: All checks pass
Dev server: Running correctly, no compilation errors
