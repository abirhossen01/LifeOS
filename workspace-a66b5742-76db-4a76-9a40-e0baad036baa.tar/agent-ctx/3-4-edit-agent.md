# Task 3-4: Add Edit Functionality to GoalsPage and SkillsPage

## Summary
Added inline edit functionality to both GoalsPage and SkillsPage components, allowing users to edit goal/skill properties directly within the card UI.

## Changes Made

### GoalsPage.tsx
- **New imports**: `Pencil` icon from lucide-react
- **New state variables**: `editingGoalId`, `editTitle`, `editDescription`, `editCategory`, `editTargetDate`
- **New handlers**: 
  - `handleEditGoal(id)` - PATCHes to `/api/goals/${id}` and updates store
  - `startEditingGoal(goal)` - Populates edit fields from current goal data
- **UI changes**: 
  - Added "Edit" button with Pencil icon next to "Update Progress" and "Mark Complete"
  - Inline edit form appears when editing, with title input, description textarea, category pills, date picker, Save/Cancel
  - Three-way conditional: edit form > progress update > action buttons

### SkillsPage.tsx
- **New imports**: `Pencil`, `Check` icons from lucide-react
- **New state variables**: `editingSkillId`, `editSkillName`, `editSkillIcon`, `editSkillColor`, `editSkillTarget`
- **New handlers**:
  - `handleEditCustomSkill(id)` - PATCHes to `/api/custom-skills/${id}` and updates store
  - `startEditingSkill(skill)` - Populates edit fields from current skill data
- **UI changes**:
  - Added Pencil edit button alongside Trash2 delete button (always visible, no hover-only)
  - Removed `opacity-0 group-hover:opacity-100` from delete button and `group` class from card
  - Inline edit form with name input, icon selector, color selector, target hours, Save/Cancel

## Lint Status
All checks pass with zero errors.
