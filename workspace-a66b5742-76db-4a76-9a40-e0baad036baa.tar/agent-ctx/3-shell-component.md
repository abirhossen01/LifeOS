# Task 3: Rewrite LifeOSApp.tsx Main Shell Component

## Agent: Shell Developer
## Date: 2025-03-05

## Work Completed

### Rewrote `/home/z/my-project/src/components/life-os/LifeOSApp.tsx` with:

1. **Blur Navbar (sticky top)**:
   - Glassmorphism effect using `.glass-strong` CSS class
   - Left: Life OS logo (Next.js Image component) + app name with `.font-heading`
   - Center: XP level badge with animated progress bar (hidden on mobile, shown on md+)
   - Right: Streak counter with 🔥 emoji + amber glow, BD/EN language toggle, date display
   - Mobile: compact XP mini-badge shown instead of full XP bar
   - Subtle glow line at bottom of navbar using gradient (primary → secondary)

2. **Bottom Navigation (fixed bottom, 5 items)**:
   - Home (🏠) → dashboard, Goals (🎯) → goals, Journal (📓) → journal, Prayer (🕌) → namaz, Profile (⚙️) → settings
   - Active item: spring-animated background glow via `motion.div` with `layoutId="bottomNavGlow"`
   - Active dot indicator at top via `layoutId="bottomNavDot"`
   - Active glow boxShadow effect (primary + secondary colors)
   - Touch-friendly 44px minimum targets via `.touch-target`
   - Safe area inset support: `paddingBottom: max(8px, env(safe-area-inset-bottom))`
   - Top glow line (gradient primary → secondary)
   - Non-bottom-nav tabs (todo, expense, fitness, skills, review) still work via `setActiveTab` from dashboard quick actions

3. **Main Content Area**:
   - Smooth scroll via `life-scrollbar`
   - AnimatePresence transitions between tabs with spring animation
   - Page variants: fade + slight y-translate + subtle scale
   - Padding for bottom nav clearance: `calc(5rem + env(safe-area-inset-bottom))`
   - Loading state: dual-ring spinner with primary/secondary colors

4. **Particle Background**:
   - 4 floating gradient orbs using absolute positioning
   - Very subtle (opacity 0.08), large blur filter
   - Animated with CSS `float` animation via `animate-float` keyframes
   - Different colors: primary, secondary, accent, green
   - `pointer-events-none` and `z-0` to not interfere with content

5. **Sub-components**:
   - `FloatingOrb` - reusable gradient orb with customizable color, size, delay
   - `XPBadge` - full XP display with level badge + progress bar + fraction text
   - `StreakCounter` - fire emoji + count + unit with amber glow
   - `LanguageToggle` - BD/EN toggle button with active state highlighting

### Technical Details
- Uses `'use client'` directive
- Uses Framer Motion for page transitions and nav animations
- Uses `useLifeOSStore` for all state
- Applies `data-theme={theme}` and `data-font-size={fontSize}` to root div
- All 10 page components imported and rendered via switch statement
- Mobile-first responsive design (breakpoints: sm, md)
- All navigation works for ALL tab pages (setActiveTab works for all)
- ESLint passes clean
- No build errors
