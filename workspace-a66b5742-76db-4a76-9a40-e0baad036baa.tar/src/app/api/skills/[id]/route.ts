import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PATCH /api/skills/[id]
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    
    const skill = await db.skillLog.update({ where: { id }, data: body });
    return NextResponse.json(skill);
  } catch (error) {
    console.error('PATCH /api/skills error:', error);
    return NextResponse.json({ error: 'Failed to update skill' }, { status: 500 });
  }
}
