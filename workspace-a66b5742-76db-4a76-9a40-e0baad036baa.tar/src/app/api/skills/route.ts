import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/skills
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { dailyLogId, skillName, minutes, progress } = body;
    
    const skill = await db.skillLog.create({
      data: { dailyLogId, skillName, minutes, progress },
    });
    
    return NextResponse.json(skill);
  } catch (error) {
    console.error('POST /api/skills error:', error);
    return NextResponse.json({ error: 'Failed to create skill' }, { status: 500 });
  }
}

// GET /api/skills?dailyLogId=xxx
export async function GET(req: NextRequest) {
  try {
    const dailyLogId = req.nextUrl.searchParams.get('dailyLogId');
    if (!dailyLogId) return NextResponse.json({ error: 'dailyLogId required' }, { status: 400 });
    
    const skills = await db.skillLog.findMany({ where: { dailyLogId } });
    return NextResponse.json(skills);
  } catch (error) {
    console.error('GET /api/skills error:', error);
    return NextResponse.json({ error: 'Failed to fetch skills' }, { status: 500 });
  }
}
