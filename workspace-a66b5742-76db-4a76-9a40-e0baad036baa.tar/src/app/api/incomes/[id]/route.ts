import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// DELETE /api/incomes/[id]
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Get the income before deleting to update totals
    const income = await db.income.findUnique({ where: { id } });
    if (!income) {
      return NextResponse.json({ error: 'Income not found' }, { status: 404 });
    }

    await db.income.delete({ where: { id } });

    // Update totalIncome on the DailyLog
    await db.dailyLog.update({
      where: { id: income.dailyLogId },
      data: { totalIncome: { decrement: income.amount } },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/incomes error:', error);
    return NextResponse.json({ error: 'Failed to delete income' }, { status: 500 });
  }
}
