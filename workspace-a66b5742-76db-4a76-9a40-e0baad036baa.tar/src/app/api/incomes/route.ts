import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/incomes
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { dailyLogId, source, amount } = body;
    
    const income = await db.income.create({
      data: { dailyLogId, source, amount },
    });

    // Update totalIncome on the DailyLog
    await db.dailyLog.update({
      where: { id: dailyLogId },
      data: { totalIncome: { increment: amount } },
    });

    return NextResponse.json(income);
  } catch (error) {
    console.error('POST /api/incomes error:', error);
    return NextResponse.json({ error: 'Failed to create income' }, { status: 500 });
  }
}
