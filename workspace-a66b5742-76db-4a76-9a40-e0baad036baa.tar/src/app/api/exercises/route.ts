import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/exercises
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { dailyLogId, name, sets, reps, type } = body;
    
    const exercise = await db.exercise.create({
      data: { dailyLogId, name, sets, reps, type: type || 'other' },
    });
    
    return NextResponse.json(exercise);
  } catch (error) {
    console.error('POST /api/exercises error:', error);
    return NextResponse.json({ error: 'Failed to create exercise' }, { status: 500 });
  }
}
