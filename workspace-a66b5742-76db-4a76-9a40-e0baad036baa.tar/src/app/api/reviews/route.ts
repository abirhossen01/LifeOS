import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/reviews - Create or update a review
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { dailyLogId, type, achievements, nextGoal1, nextGoal2, nextGoal3, weekScore } = body;

    if (!dailyLogId) {
      return NextResponse.json({ error: 'dailyLogId required' }, { status: 400 });
    }

    // Upsert: update if exists, create if not
    const review = await db.review.upsert({
      where: { dailyLogId },
      update: { type, achievements, nextGoal1, nextGoal2, nextGoal3, weekScore },
      create: { dailyLogId, type, achievements, nextGoal1, nextGoal2, nextGoal3, weekScore },
    });

    return NextResponse.json(review);
  } catch (error) {
    console.error('POST /api/reviews error:', error);
    return NextResponse.json({ error: 'Failed to save review' }, { status: 500 });
  }
}

// GET /api/reviews?dailyLogId=xxx
export async function GET(req: NextRequest) {
  try {
    const dailyLogId = req.nextUrl.searchParams.get('dailyLogId');
    if (!dailyLogId) return NextResponse.json({ error: 'dailyLogId required' }, { status: 400 });

    const review = await db.review.findUnique({ where: { dailyLogId } });
    return NextResponse.json(review || {});
  } catch (error) {
    console.error('GET /api/reviews error:', error);
    return NextResponse.json({ error: 'Failed to fetch review' }, { status: 500 });
  }
}
