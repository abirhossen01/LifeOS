import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PATCH /api/planned-tasks/[id]
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const task = await db.plannedTask.update({ where: { id }, data: body });
    return NextResponse.json(task);
  } catch (error) {
    console.error('PATCH /api/planned-tasks error:', error);
    return NextResponse.json({ error: 'Failed to update planned task' }, { status: 500 });
  }
}

// DELETE /api/planned-tasks/[id]
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.plannedTask.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/planned-tasks error:', error);
    return NextResponse.json({ error: 'Failed to delete planned task' }, { status: 500 });
  }
}
