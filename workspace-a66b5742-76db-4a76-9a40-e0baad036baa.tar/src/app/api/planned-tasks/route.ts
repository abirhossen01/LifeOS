import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/planned-tasks?targetDate=YYYY-MM-DD
export async function GET(req: NextRequest) {
  try {
    const targetDate = req.nextUrl.searchParams.get('targetDate');
    const where = targetDate ? { targetDate, migrated: false } : { migrated: false };
    const tasks = await db.plannedTask.findMany({ where, orderBy: { createdAt: 'desc' } });
    return NextResponse.json(tasks);
  } catch (error) {
    console.error('GET /api/planned-tasks error:', error);
    return NextResponse.json({ error: 'Failed to fetch planned tasks' }, { status: 500 });
  }
}

// POST /api/planned-tasks
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title, category, priority, targetDate, dueTime } = body;
    const task = await db.plannedTask.create({
      data: {
        title,
        category: category || 'personal',
        priority: priority || 'medium',
        targetDate,
        dueTime: dueTime || null,
      },
    });
    return NextResponse.json(task);
  } catch (error) {
    console.error('POST /api/planned-tasks error:', error);
    return NextResponse.json({ error: 'Failed to create planned task' }, { status: 500 });
  }
}
