import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/sync?userId=xxx — Fetch all user data for cloud sync
export async function GET(req: NextRequest) {
  try {
    const userId = req.nextUrl.searchParams.get('userId');
    if (!userId) {
      return NextResponse.json({ error: 'User ID required' }, { status: 400 });
    }

    // Fetch all data from local SQLite
    const dailyLogs = await db.dailyLog.findMany({ orderBy: { date: 'desc' }, take: 90 });
    const settings = await db.userSettings.findFirst();
    const customSkills = await db.customSkill.findMany();
    const videoIdeas = await db.videoIdea.findMany();
    const books = await db.book.findMany();
    const mindsetEntries = await db.mindsetEntry.findMany({ orderBy: { date: 'desc' }, take: 90 });
    const calendarEvents = await db.calendarEvent.findMany();
    const plannedTasks = await db.plannedTask.findMany({ where: { migrated: false } });

    // Latest daily log with related data
    let latestData = {};
    if (dailyLogs.length > 0) {
      const latestLog = dailyLogs[0];
      const tasks = await db.task.findMany({ where: { dailyLogId: latestLog.id } });
      const expenses = await db.expense.findMany({ where: { dailyLogId: latestLog.id } });
      const incomes = await db.income.findMany({ where: { dailyLogId: latestLog.id } });
      const exercises = await db.exercise.findMany({ where: { dailyLogId: latestLog.id } });
      const journal = await db.journal.findUnique({ where: { dailyLogId: latestLog.id } });
      const skills = await db.skillLog.findMany({ where: { dailyLogId: latestLog.id } });
      const goals = await db.goal.findMany({ where: { dailyLogId: latestLog.id } });

      latestData = { dailyLog: latestLog, tasks, expenses, incomes, exercises, journal, skills, goals };
    }

    return NextResponse.json({
      ...latestData,
      customSkills,
      videoIdeas,
      books,
      mindsetEntries,
      calendarEvents,
      plannedTasks,
      settings,
      dailyLogs,
    });
  } catch (error) {
    console.error('GET /api/sync error:', error);
    return NextResponse.json({ error: 'Failed to fetch sync data' }, { status: 500 });
  }
}

// POST /api/sync — Push data for cloud sync
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { userId } = body;

    if (!userId) {
      return NextResponse.json({ error: 'User ID required' }, { status: 400 });
    }

    // Data is already persisted through individual API routes
    // This endpoint serves as a sync marker
    return NextResponse.json({
      success: true,
      syncedAt: new Date().toISOString(),
      userId,
    });
  } catch (error) {
    console.error('POST /api/sync error:', error);
    return NextResponse.json({ error: 'Failed to sync data' }, { status: 500 });
  }
}
