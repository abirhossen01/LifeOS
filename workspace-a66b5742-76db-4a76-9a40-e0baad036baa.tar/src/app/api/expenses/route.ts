import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/expenses
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { dailyLogId, name, amount, category } = body;
    
    const expense = await db.expense.create({
      data: { dailyLogId, name, amount, category: category || 'other' },
    });

    // Update totalExpense on the DailyLog
    await db.dailyLog.update({
      where: { id: dailyLogId },
      data: { totalExpense: { increment: amount } },
    });

    return NextResponse.json(expense);
  } catch (error) {
    console.error('POST /api/expenses error:', error);
    return NextResponse.json({ error: 'Failed to create expense' }, { status: 500 });
  }
}
