import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/video-ideas
export async function GET() {
  try {
    const ideas = await db.videoIdea.findMany({ orderBy: { createdAt: 'desc' } });
    return NextResponse.json(ideas);
  } catch (error) {
    console.error('GET /api/video-ideas error:', error);
    return NextResponse.json({ error: 'Failed to fetch video ideas' }, { status: 500 });
  }
}

// POST /api/video-ideas
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title } = body;
    
    const idea = await db.videoIdea.create({ data: { title } });
    return NextResponse.json(idea);
  } catch (error) {
    console.error('POST /api/video-ideas error:', error);
    return NextResponse.json({ error: 'Failed to create video idea' }, { status: 500 });
  }
}
