import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PATCH /api/video-ideas/[id]
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const idea = await db.videoIdea.update({
      where: { id },
      data: body,
    });
    return NextResponse.json(idea);
  } catch (error) {
    console.error('PATCH /api/video-ideas error:', error);
    return NextResponse.json({ error: 'Failed to update video idea' }, { status: 500 });
  }
}

// DELETE /api/video-ideas/[id]
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.videoIdea.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/video-ideas error:', error);
    return NextResponse.json({ error: 'Failed to delete video idea' }, { status: 500 });
  }
}
