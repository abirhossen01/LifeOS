import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PATCH /api/calendar-events/[id] - Update calendar event by id
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const event = await db.calendarEvent.update({
      where: { id },
      data: body,
    });

    return NextResponse.json(event);
  } catch (error) {
    console.error('PATCH /api/calendar-events/[id] error:', error);
    return NextResponse.json({ error: 'Failed to update calendar event' }, { status: 500 });
  }
}

// DELETE /api/calendar-events/[id] - Delete calendar event by id
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.calendarEvent.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/calendar-events/[id] error:', error);
    return NextResponse.json({ error: 'Failed to delete calendar event' }, { status: 500 });
  }
}
