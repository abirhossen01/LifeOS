import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/calendar-events - Return all calendar events
// Optional query params: ?date=2026-05-13 to filter by date, ?month=2026-05 to filter by month
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const date = searchParams.get('date');
    const month = searchParams.get('month');

    const events = await db.calendarEvent.findMany({
      where: date
        ? { date }
        : month
          ? { date: { startsWith: month } }
          : {},
      orderBy: { date: 'asc' },
    });

    return NextResponse.json(events);
  } catch (error) {
    console.error('GET /api/calendar-events error:', error);
    return NextResponse.json({ error: 'Failed to fetch calendar events' }, { status: 500 });
  }
}

// POST /api/calendar-events - Create a new calendar event
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { title, description, date, time, endTime, category, recurring } = body;

    const event = await db.calendarEvent.create({
      data: {
        title,
        description: description || '',
        date,
        time: time || '00:00',
        endTime: endTime || '00:00',
        category: category || 'personal',
        recurring: recurring || 'none',
      },
    });

    return NextResponse.json(event);
  } catch (error) {
    console.error('POST /api/calendar-events error:', error);
    return NextResponse.json({ error: 'Failed to create calendar event' }, { status: 500 });
  }
}
