import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/daily-log?date=YYYY-MM-DD
export async function GET(req: NextRequest) {
  try {
    const date = req.nextUrl.searchParams.get('date') || new Date().toISOString().split('T')[0];
    
    let dailyLog = await db.dailyLog.findUnique({ where: { date } });
    
    if (!dailyLog) {
      // Get streak from yesterday
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split('T')[0];
      const yesterdayLog = await db.dailyLog.findUnique({ where: { date: yesterdayStr } });
      const streak = yesterdayLog ? yesterdayLog.streak + 1 : 1;
      
      // Get default budget from settings
      let settings = await db.userSettings.findFirst();
      if (!settings) {
        settings = await db.userSettings.create({ data: {} });
      }
      
      dailyLog = await db.dailyLog.create({
        data: {
          date,
          streak,
          dailyBudget: settings.dailyBudget,
        },
      });
    }

    // Fetch all related data
    const tasks = await db.task.findMany({ where: { dailyLogId: dailyLog.id }, orderBy: { order: 'asc' } });
    const expenses = await db.expense.findMany({ where: { dailyLogId: dailyLog.id }, orderBy: { createdAt: 'desc' } });
    const incomes = await db.income.findMany({ where: { dailyLogId: dailyLog.id }, orderBy: { createdAt: 'desc' } });
    const exercises = await db.exercise.findMany({ where: { dailyLogId: dailyLog.id }, orderBy: { createdAt: 'desc' } });
    const journal = await db.journal.findUnique({ where: { dailyLogId: dailyLog.id } });
    const skills = await db.skillLog.findMany({ where: { dailyLogId: dailyLog.id } });
    const goals = await db.goal.findMany({ where: { dailyLogId: dailyLog.id }, orderBy: { createdAt: 'desc' } });

    // Compute accurate totals from actual records
    const totalExpense = expenses.reduce((sum, e) => sum + e.amount, 0);
    const totalIncome = incomes.reduce((sum, i) => sum + i.amount, 0);

    // Update DailyLog totals if they're out of sync
    if (dailyLog.totalExpense !== totalExpense || dailyLog.totalIncome !== totalIncome) {
      dailyLog = await db.dailyLog.update({
        where: { id: dailyLog.id },
        data: { totalExpense, totalIncome },
      });
    }

    return NextResponse.json({
      dailyLog,
      tasks,
      expenses,
      incomes,
      exercises,
      journal,
      skills,
      goals,
    });
  } catch (error) {
    console.error('GET /api/daily-log error:', error);
    return NextResponse.json({ error: 'Failed to fetch daily log' }, { status: 500 });
  }
}

// POST /api/daily-log - Create or get daily log for a date
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { date } = body;
    
    let dailyLog = await db.dailyLog.findUnique({ where: { date } });
    
    if (!dailyLog) {
      dailyLog = await db.dailyLog.create({ data: { date } });
    }
    
    return NextResponse.json(dailyLog);
  } catch (error) {
    console.error('POST /api/daily-log error:', error);
    return NextResponse.json({ error: 'Failed to create daily log' }, { status: 500 });
  }
}
