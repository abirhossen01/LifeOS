import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    
    const dailyLog = await db.dailyLog.update({
      where: { id },
      data: body,
    });
    
    return NextResponse.json(dailyLog);
  } catch (error) {
    console.error('PATCH /api/daily-log error:', error);
    return NextResponse.json({ error: 'Failed to update daily log' }, { status: 500 });
  }
}
