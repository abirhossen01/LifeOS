import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/goals
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { dailyLogId, title, description, category, targetDate } = body;
    
    const goal = await db.goal.create({
      data: { 
        dailyLogId, 
        title, 
        description: description || '',
        category: category || 'personal',
        targetDate,
      },
    });
    
    return NextResponse.json(goal);
  } catch (error) {
    console.error('POST /api/goals error:', error);
    return NextResponse.json({ error: 'Failed to create goal' }, { status: 500 });
  }
}
