import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/tasks?dailyLogId=xxx
export async function GET(req: NextRequest) {
  try {
    const dailyLogId = req.nextUrl.searchParams.get('dailyLogId');
    if (!dailyLogId) return NextResponse.json({ error: 'dailyLogId required' }, { status: 400 });
    
    const tasks = await db.task.findMany({ where: { dailyLogId }, orderBy: { order: 'asc' } });
    return NextResponse.json(tasks);
  } catch (error) {
    console.error('GET /api/tasks error:', error);
    return NextResponse.json({ error: 'Failed to fetch tasks' }, { status: 500 });
  }
}

// POST /api/tasks
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { dailyLogId, title, category, priority, dueDate, dueTime, reminder } = body;
    
    const existingCount = await db.task.count({ where: { dailyLogId } });
    
    const task = await db.task.create({
      data: {
        dailyLogId,
        title,
        category: category || 'personal',
        priority: priority || 'medium',
        order: existingCount,
        dueDate: dueDate || null,
        dueTime: dueTime || null,
        reminder: reminder || false,
      },
    });
    
    return NextResponse.json(task);
  } catch (error) {
    console.error('POST /api/tasks error:', error);
    return NextResponse.json({ error: 'Failed to create task' }, { status: 500 });
  }
}
