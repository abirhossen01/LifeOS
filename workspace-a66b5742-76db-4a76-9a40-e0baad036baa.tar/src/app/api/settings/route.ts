import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/settings
export async function GET() {
  try {
    let settings = await db.userSettings.findFirst();
    
    if (!settings) {
      settings = await db.userSettings.create({ data: {} });
    }
    
    return NextResponse.json(settings);
  } catch (error) {
    console.error('GET /api/settings error:', error);
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}
