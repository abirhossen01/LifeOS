import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/books - Return all books ordered by createdAt desc
export async function GET() {
  try {
    const books = await db.book.findMany({
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(books);
  } catch (error) {
    console.error('GET /api/books error:', error);
    return NextResponse.json({ error: 'Failed to fetch books' }, { status: 500 });
  }
}

// POST /api/books - Create a new book
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { title, author, category, totalPages, status } = body;

    const book = await db.book.create({
      data: {
        title,
        author: author || '',
        category: category || 'islamic',
        totalPages: totalPages || 0,
        status: status || 'want-to-read',
      },
    });

    return NextResponse.json(book);
  } catch (error) {
    console.error('POST /api/books error:', error);
    return NextResponse.json({ error: 'Failed to create book' }, { status: 500 });
  }
}
