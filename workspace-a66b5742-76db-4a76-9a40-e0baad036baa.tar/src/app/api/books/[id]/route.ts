import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PATCH /api/books/[id] - Update book by id
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const book = await db.book.update({
      where: { id },
      data: body,
    });

    return NextResponse.json(book);
  } catch (error) {
    console.error('PATCH /api/books/[id] error:', error);
    return NextResponse.json({ error: 'Failed to update book' }, { status: 500 });
  }
}

// DELETE /api/books/[id] - Delete book by id
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.book.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/books/[id] error:', error);
    return NextResponse.json({ error: 'Failed to delete book' }, { status: 500 });
  }
}
