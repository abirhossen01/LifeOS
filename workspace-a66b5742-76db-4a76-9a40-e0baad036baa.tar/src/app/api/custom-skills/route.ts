import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/custom-skills?settingsId=xxx
export async function GET(req: NextRequest) {
  try {
    const settingsId = req.nextUrl.searchParams.get('settingsId');
    if (!settingsId) {
      // Get from first settings
      const settings = await db.userSettings.findFirst();
      if (!settings) return NextResponse.json([]);
      const skills = await db.customSkill.findMany({ where: { settingsId: settings.id }, orderBy: { createdAt: 'asc' } });
      return NextResponse.json(skills);
    }
    const skills = await db.customSkill.findMany({ where: { settingsId }, orderBy: { createdAt: 'asc' } });
    return NextResponse.json(skills);
  } catch (error) {
    console.error('GET /api/custom-skills error:', error);
    return NextResponse.json({ error: 'Failed to fetch custom skills' }, { status: 500 });
  }
}

// POST /api/custom-skills
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { settingsId, name, icon, color, targetHours } = body;
    
    let sid = settingsId;
    if (!sid) {
      const settings = await db.userSettings.findFirst();
      if (!settings) return NextResponse.json({ error: 'No settings found' }, { status: 400 });
      sid = settings.id;
    }
    
    const skill = await db.customSkill.create({
      data: { settingsId: sid, name, icon: icon || '📘', color: color || '#3B8BD4', targetHours: targetHours || 100 },
    });
    
    return NextResponse.json(skill);
  } catch (error) {
    console.error('POST /api/custom-skills error:', error);
    return NextResponse.json({ error: 'Failed to create custom skill' }, { status: 500 });
  }
}
