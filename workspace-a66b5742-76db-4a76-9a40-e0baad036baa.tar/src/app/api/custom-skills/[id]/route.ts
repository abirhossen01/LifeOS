import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PATCH /api/custom-skills/[id]
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    
    const skill = await db.customSkill.update({ where: { id }, data: body });
    return NextResponse.json(skill);
  } catch (error) {
    console.error('PATCH /api/custom-skills error:', error);
    return NextResponse.json({ error: 'Failed to update custom skill' }, { status: 500 });
  }
}

// DELETE /api/custom-skills/[id]
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.customSkill.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/custom-skills error:', error);
    return NextResponse.json({ error: 'Failed to delete custom skill' }, { status: 500 });
  }
}
