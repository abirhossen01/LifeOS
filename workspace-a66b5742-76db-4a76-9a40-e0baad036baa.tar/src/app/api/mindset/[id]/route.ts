import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// PATCH /api/mindset/[id] - Update mindset entry by id
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const entry = await db.mindsetEntry.update({
      where: { id },
      data: body,
    });

    return NextResponse.json(entry);
  } catch (error) {
    console.error('PATCH /api/mindset/[id] error:', error);
    return NextResponse.json({ error: 'Failed to update mindset entry' }, { status: 500 });
  }
}

// DELETE /api/mindset/[id] - Delete mindset entry by id
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.mindsetEntry.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('DELETE /api/mindset/[id] error:', error);
    return NextResponse.json({ error: 'Failed to delete mindset entry' }, { status: 500 });
  }
}
