import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/mindset - Return all mindset entries ordered by date desc
// Optional query param: ?type=affirmation to filter by type
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');

    const where = type ? { type } : {};

    const entries = await db.mindsetEntry.findMany({
      where,
      orderBy: { date: 'desc' },
    });

    return NextResponse.json(entries);
  } catch (error) {
    console.error('GET /api/mindset error:', error);
    return NextResponse.json({ error: 'Failed to fetch mindset entries' }, { status: 500 });
  }
}

// POST /api/mindset - Create a new mindset entry
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { date, type, content, mood, gratitude, tags } = body;

    const entry = await db.mindsetEntry.create({
      data: {
        date,
        type: type || 'affirmation',
        content,
        mood: mood ?? 5,
        gratitude: gratitude || '',
        tags: tags || '',
      },
    });

    return NextResponse.json(entry);
  } catch (error) {
    console.error('POST /api/mindset error:', error);
    return NextResponse.json({ error: 'Failed to create mindset entry' }, { status: 500 });
  }
}
