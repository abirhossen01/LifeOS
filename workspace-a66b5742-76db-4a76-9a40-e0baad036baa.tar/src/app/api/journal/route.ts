import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST /api/journal
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { dailyLogId, learned, mistakes, gratitude1, gratitude2, gratitude3, tomorrowGoal } = body;
    
    // Upsert journal
    const journal = await db.journal.upsert({
      where: { dailyLogId },
      update: { learned, mistakes, gratitude1, gratitude2, gratitude3, tomorrowGoal },
      create: { dailyLogId, learned, mistakes, gratitude1, gratitude2, gratitude3, tomorrowGoal },
    });
    
    return NextResponse.json(journal);
  } catch (error) {
    console.error('POST /api/journal error:', error);
    return NextResponse.json({ error: 'Failed to save journal' }, { status: 500 });
  }
}
