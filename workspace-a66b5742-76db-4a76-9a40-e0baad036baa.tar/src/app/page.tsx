'use client';

import { useEffect, useState, useSyncExternalStore } from 'react';
import LifeOSApp from '@/components/life-os/LifeOSApp';
import { useLifeOSStore } from '@/lib/store';

export default function Home() {
  const isHydrated = useSyncExternalStore(
    (callback) => useLifeOSStore.persist.onFinishHydration(callback),
    () => useLifeOSStore.persist.hasHydrated(),
    () => false,
  );
  const [timedOut, setTimedOut] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => { setTimedOut(true); }, 1500);
    return () => clearTimeout(t);
  }, []);
  const ready = isHydrated || timedOut;
  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#1E1E1E' }}>
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-full border-2 border-white/10 border-t-[#FF6B35] animate-spin" />
          <p className="text-sm text-white/50">Loading Life OS...</p>
        </div>
      </div>
    );
  }
  return <LifeOSApp />;
}
