import { createClient, SupabaseClient, Session, AuthChangeEvent } from "@supabase/supabase-js";

// ---------------------------------------------------------------------------
// Environment variables
// ---------------------------------------------------------------------------
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

// ---------------------------------------------------------------------------
// Lazy-initialized Supabase client
// ---------------------------------------------------------------------------
let supabaseInstance: SupabaseClient | null = null;

function getSupabaseClient(): SupabaseClient {
  if (supabaseInstance) return supabaseInstance;

  if (!isSupabaseConfigured()) {
    throw new Error(
      "Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY in your environment."
    );
  }

  supabaseInstance = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  return supabaseInstance;
}

// ---------------------------------------------------------------------------
// Configuration check
// ---------------------------------------------------------------------------
export function isSupabaseConfigured(): boolean {
  return SUPABASE_URL.length > 0 && SUPABASE_ANON_KEY.length > 0;
}

// ---------------------------------------------------------------------------
// Email / Password Auth
// ---------------------------------------------------------------------------

/** Sign up with email, password, and optional display name. */
export async function supabaseSignUp(
  email: string,
  password: string,
  name: string
) {
  const { data, error } = await getSupabaseClient().auth.signUp({
    email,
    password,
    options: {
      data: { name },
    },
  });

  if (error) throw error;
  return data;
}

/** Sign in with email and password. */
export async function supabaseSignIn(email: string, password: string) {
  const { data, error } = await getSupabaseClient().auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;
  return data;
}

/** Sign out the current user. */
export async function supabaseSignOut() {
  const { error } = await getSupabaseClient().auth.signOut();
  if (error) throw error;
}

// ---------------------------------------------------------------------------
// OAuth Providers
// ---------------------------------------------------------------------------

type OAuthProvider = "google" | "facebook" | "github" | "apple" | "twitter";

/**
 * Generic helper that initiates an OAuth sign-in flow.
 * Redirects back to `window.location.origin` after the provider authenticates.
 */
async function signInWithProvider(provider: OAuthProvider) {
  const { data, error } = await getSupabaseClient().auth.signInWithOAuth({
    provider,
    options: {
      redirectTo: typeof window !== "undefined" ? window.location.origin : "",
    },
  });

  if (error) throw error;
  return data;
}

/** Sign in with Google OAuth. */
export async function supabaseSignInWithGoogle() {
  return signInWithProvider("google");
}

/** Sign in with Facebook OAuth. */
export async function supabaseSignInWithFacebook() {
  return signInWithProvider("facebook");
}

/** Sign in with GitHub OAuth. */
export async function supabaseSignInWithGitHub() {
  return signInWithProvider("github");
}

/** Sign in with Apple OAuth. */
export async function supabaseSignInWithApple() {
  return signInWithProvider("apple");
}

/** Sign in with Twitter OAuth. */
export async function supabaseSignInWithTwitter() {
  return signInWithProvider("twitter");
}

// ---------------------------------------------------------------------------
// Session Management
// ---------------------------------------------------------------------------

/** Retrieve the current session, or `null` if the user is not authenticated. */
export async function supabaseGetSession(): Promise<Session | null> {
  const {
    data: { session },
    error,
  } = await getSupabaseClient().auth.getSession();

  if (error) throw error;
  return session;
}

/**
 * Subscribe to authentication state changes.
 * Returns an object with an `unsubscribe` method to remove the listener.
 */
export function supabaseOnAuthStateChange(
  callback: (event: AuthChangeEvent, session: Session | null) => void
) {
  const { data } = getSupabaseClient().auth.onAuthStateChange(callback);
  return data.subscription;
}

// ---------------------------------------------------------------------------
// Password Reset
// ---------------------------------------------------------------------------

/** Send a password-reset email to the given address. */
export async function supabaseResetPassword(email: string) {
  const { data, error } = await getSupabaseClient().auth.resetPasswordForEmail(
    email,
    {
      redirectTo:
        typeof window !== "undefined"
          ? `${window.location.origin}/reset-password`
          : undefined,
    }
  );

  if (error) throw error;
  return data;
}
