import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { Language } from '@/lib/i18n';

// ===== Types =====
export type PrayerStatus = 'none' | 'alone' | 'jamaat';
export type TaskCategory = 'personal' | 'bba' | 'dev' | 'fitness' | 'freelancing' | 'chess';
export type TaskPriority = 'low' | 'medium' | 'high' | 'mit';
export type ExpenseCategory = 'food' | 'transport' | 'study' | 'health' | 'entertainment' | 'other';
export type ExerciseType = 'mma' | 'strength' | 'cardio' | 'flexibility' | 'other';
export type ThemeName = 'dashboard' | 'dark-gold' | 'dark-emerald' | 'dark-midnight' | 'light' | 'cyberpunk';
export type FontSize = 'small' | 'medium' | 'large' | 'xlarge';
export type GoalCategory = 'personal' | 'career' | 'health' | 'spiritual' | 'financial' | 'education';

export type TabPage = 'dashboard' | 'namaz' | 'todo' | 'expense' | 'journal' | 'fitness' | 'skills' | 'goals' | 'review' | 'settings' | 'books' | 'mindset' | 'calendar' | 'profile' | 'auth';

export interface SupabaseUser {
  id: string;
  email: string;
  name?: string;
  avatar_url?: string;
}

export interface TaskItem {
  id: string;
  title: string;
  category: TaskCategory;
  priority: TaskPriority;
  completed: boolean;
  order: number;
  dueDate?: string;
  dueTime?: string;
  reminder?: boolean;
}

export interface ExpenseItem {
  id: string;
  name: string;
  amount: number;
  category: ExpenseCategory;
}

export interface IncomeItem {
  id: string;
  source: string;
  amount: number;
}

export interface ExerciseItem {
  id: string;
  name: string;
  sets: number;
  reps: number;
  type: ExerciseType;
}

export interface JournalData {
  learned: string;
  mistakes: string;
  gratitude1: string;
  gratitude2: string;
  gratitude3: string;
  tomorrowGoal: string;
}

export interface SkillItem {
  id: string;
  skillName: string;
  minutes: number;
  progress: number;
}

export interface CustomSkillItem {
  id: string;
  name: string;
  icon: string;
  color: string;
  targetHours: number;
  loggedHours: number;
  progress: number;
}

export interface GoalItem {
  id: string;
  title: string;
  description: string;
  category: GoalCategory;
  completed: boolean;
  progress: number;
  targetDate?: string;
}

export interface VideoIdea {
  id: string;
  title: string;
  completed: boolean;
}

export interface BookItem {
  id: string;
  title: string;
  author: string;
  category: string;
  totalPages: number;
  readPages: number;
  status: string;
  startDate?: string;
  endDate?: string;
  notes: string;
  rating: number;
}

export interface MindsetEntryItem {
  id: string;
  date: string;
  type: string;
  content: string;
  mood: number;
  gratitude: string;
  tags: string;
}

export interface CalendarEventItem {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  endTime: string;
  category: string;
  completed: boolean;
  recurring: string;
}

export interface DefaultSkillConfig {
  id: string;
  name: string;
  color: string;
  icon: string;
}

export interface PlannedTaskItem {
  id: string;
  title: string;
  category: TaskCategory;
  priority: TaskPriority;
  targetDate: string;
  dueTime?: string;
  migrated: boolean;
}

export interface DailyLogData {
  id: string;
  date: string;
  dailyScore: number;
  streak: number;
  fajr: PrayerStatus;
  zuhr: PrayerStatus;
  asr: PrayerStatus;
  maghrib: PrayerStatus;
  isha: PrayerStatus;
  quranPages: number;
  moodScore: number;
  anxietyLevel: number;
  energyLevel: number;
  waterGlasses: number;
  sleepStart: string;
  sleepEnd: string;
  sleepQuality: number;
  weight: number;
  dailyBudget: number;
  totalExpense: number;
  totalIncome: number;
}

export interface UserSettings {
  id: string;
  name: string;
  email: string;
  bio: string;
  avatar: string;
  location: string;
  occupation: string;
  dailyBudget: number;
  waterGoal: number;
  chessRating: number;
  chessGames: number;
  chessWins: number;
  chessLosses: number;
  chessDraws: number;
  ytVideos1: number;
  ytVideos2: number;
  height: number;
  theme: ThemeName;
  fontSize: FontSize;
  language: Language;
  defaultSkillConfigs: string;
}

// ===== Helper =====
const todayStr = () => new Date().toISOString().split('T')[0];

// ===== Store Interface =====
interface LifeOSStore {
  // Navigation
  activeTab: TabPage;
  setActiveTab: (tab: TabPage) => void;

  // Theme & Preferences
  theme: ThemeName;
  setTheme: (theme: ThemeName) => void;
  fontSize: FontSize;
  setFontSize: (size: FontSize) => void;
  language: Language;
  setLanguage: (lang: Language) => void;

  // Daily Log
  dailyLog: DailyLogData | null;
  setDailyLog: (log: DailyLogData) => void;
  loadDailyLog: () => Promise<void>;

  // Tasks
  tasks: TaskItem[];
  setTasks: (tasks: TaskItem[]) => void;
  addTask: (title: string, category: TaskCategory, priority?: TaskPriority, dueDate?: string, dueTime?: string, reminder?: boolean) => Promise<void>;
  toggleTask: (id: string) => Promise<void>;
  deleteTask: (id: string) => Promise<void>;

  // Expenses
  expenses: ExpenseItem[];
  setExpenses: (expenses: ExpenseItem[]) => void;
  addExpense: (name: string, amount: number, category: ExpenseCategory) => Promise<void>;
  deleteExpense: (id: string) => Promise<void>;

  // Incomes
  incomes: IncomeItem[];
  setIncomes: (incomes: IncomeItem[]) => void;
  addIncome: (source: string, amount: number) => Promise<void>;

  // Exercises
  exercises: ExerciseItem[];
  setExercises: (exercises: ExerciseItem[]) => void;
  addExercise: (name: string, sets: number, reps: number, type: ExerciseType) => Promise<void>;
  deleteExercise: (id: string) => Promise<void>;

  // Journal
  journal: JournalData | null;
  setJournal: (journal: JournalData) => void;
  saveJournal: (data: JournalData) => Promise<void>;

  // Skills (daily)
  skills: SkillItem[];
  setSkills: (skills: SkillItem[]) => void;
  addSkill: (skillName: string, minutes: number, progress: number) => Promise<void>;
  updateSkill: (id: string, minutes: number, progress: number) => Promise<void>;

  // Custom Skills
  customSkills: CustomSkillItem[];
  setCustomSkills: (skills: CustomSkillItem[]) => void;
  loadCustomSkills: () => Promise<void>;
  addCustomSkill: (name: string, icon: string, color: string, targetHours: number) => Promise<void>;
  updateCustomSkill: (id: string, data: Partial<CustomSkillItem>) => Promise<void>;
  deleteCustomSkill: (id: string) => Promise<void>;
  logCustomSkillTime: (id: string, minutes: number) => Promise<void>;

  // Goals
  goals: GoalItem[];
  setGoals: (goals: GoalItem[]) => void;
  addGoal: (title: string, description: string, category: GoalCategory, targetDate?: string) => Promise<void>;
  toggleGoal: (id: string) => Promise<void>;
  deleteGoal: (id: string) => Promise<void>;
  updateGoalProgress: (id: string, progress: number) => Promise<void>;

  // Video Ideas
  videoIdeas: VideoIdea[];
  setVideoIdeas: (ideas: VideoIdea[]) => void;
  addVideoIdea: (title: string) => Promise<void>;
  deleteVideoIdea: (id: string) => Promise<void>;

  // Books
  books: BookItem[];
  setBooks: (books: BookItem[]) => void;
  loadBooks: () => Promise<void>;
  addBook: (title: string, author: string, category: string, totalPages: number) => Promise<void>;
  updateBook: (id: string, data: Partial<BookItem>) => Promise<void>;
  deleteBook: (id: string) => Promise<void>;
  updateBookProgress: (id: string, readPages: number) => Promise<void>;

  // Mindset
  mindsetEntries: MindsetEntryItem[];
  setMindsetEntries: (entries: MindsetEntryItem[]) => void;
  loadMindsetEntries: () => Promise<void>;
  addMindsetEntry: (date: string, type: string, content: string, mood: number, gratitude: string) => Promise<void>;
  deleteMindsetEntry: (id: string) => Promise<void>;

  // Calendar Events
  calendarEvents: CalendarEventItem[];
  setCalendarEvents: (events: CalendarEventItem[]) => void;
  loadCalendarEvents: () => Promise<void>;
  addCalendarEvent: (title: string, description: string, date: string, time: string, endTime: string, category: string, recurring: string) => Promise<void>;
  updateCalendarEvent: (id: string, data: Partial<CalendarEventItem>) => Promise<void>;
  deleteCalendarEvent: (id: string) => Promise<void>;
  toggleCalendarEvent: (id: string) => Promise<void>;

  // Default Skill Configs
  defaultSkillConfigs: DefaultSkillConfig[];
  setDefaultSkillConfigs: (configs: DefaultSkillConfig[]) => void;
  addDefaultSkillConfig: (name: string, color: string, icon: string) => Promise<void>;
  updateDefaultSkillConfig: (id: string, data: Partial<DefaultSkillConfig>) => Promise<void>;
  deleteDefaultSkillConfig: (id: string) => Promise<void>;

  // Planned Tasks
  plannedTasks: PlannedTaskItem[];
  setPlannedTasks: (tasks: PlannedTaskItem[]) => void;
  loadPlannedTasks: () => Promise<void>;
  addPlannedTask: (title: string, category: TaskCategory, priority: TaskPriority, targetDate: string, dueTime?: string) => Promise<void>;
  deletePlannedTask: (id: string) => Promise<void>;
  migratePlannedTasks: (targetDate: string) => Promise<void>;

  // Prayer
  updatePrayer: (prayer: 'fajr' | 'zuhr' | 'asr' | 'maghrib' | 'isha', status: PrayerStatus) => Promise<void>;
  updateQuranPages: (pages: number) => Promise<void>;

  // Fitness
  updateWater: (glasses: number) => Promise<void>;
  updateSleep: (start: string, end: string, quality: number) => Promise<void>;
  updateWeight: (weight: number) => Promise<void>;
  updateMood: (moodScore: number, anxietyLevel: number, energyLevel: number) => Promise<void>;

  // Settings
  settings: UserSettings | null;
  setSettings: (settings: UserSettings) => void;
  loadSettings: () => Promise<void>;
  updateSettings: (data: Partial<UserSettings>) => Promise<void>;
  incrementYT: (channel: 1 | 2) => Promise<void>;
  updateChess: (field: 'chessWins' | 'chessLosses' | 'chessDraws' | 'chessRating' | 'chessGames', value: number) => Promise<void>;

  // Score
  calculateScore: () => number;

  // XP System
  xp: number;
  level: number;
  addXP: (amount: number) => void;

  // Loading
  loading: boolean;
  setLoading: (loading: boolean) => void;

  // Auth
  supabaseUser: SupabaseUser | null;
  setSupabaseUser: (user: SupabaseUser | null) => void;
  isAuthenticated: boolean;
  isSyncing: boolean;
  setIsSyncing: (syncing: boolean) => void;
  lastSyncAt: string | null;
  syncToCloud: () => Promise<void>;
  syncFromCloud: () => Promise<void>;
  initialDataLoaded: boolean;
  setInitialDataLoaded: (loaded: boolean) => void;
}

// ===== Store =====
export const useLifeOSStore = create<LifeOSStore>()(
  persist(
    (set, get) => ({
      // Navigation
      activeTab: 'dashboard' as TabPage,
      setActiveTab: (tab) => set({ activeTab: tab }),

      // Theme & Preferences
      theme: 'dashboard' as ThemeName,
      setTheme: (theme) => {
        set({ theme });
        const settings = get().settings;
        if (settings) get().updateSettings({ theme });
      },
      fontSize: 'medium' as FontSize,
      setFontSize: (fontSize) => {
        set({ fontSize });
        const settings = get().settings;
        if (settings) get().updateSettings({ fontSize });
      },
      language: 'bn' as Language,
      setLanguage: (language) => {
        set({ language });
        const settings = get().settings;
        if (settings) get().updateSettings({ language });
      },

      // Daily Log
      dailyLog: null,
      setDailyLog: (log) => set({ dailyLog: log }),
      loadDailyLog: async () => {
        try {
          set({ loading: true });
          const date = todayStr();
          const res = await fetch(`/api/daily-log?date=${date}`);
          if (res.ok) {
            const data = await res.json();
            set({
              dailyLog: data.dailyLog,
              tasks: data.tasks || [],
              expenses: data.expenses || [],
              incomes: data.incomes || [],
              exercises: data.exercises || [],
              journal: data.journal || null,
              skills: data.skills || [],
              goals: data.goals || [],
            });
          }

          // Load new features
          get().loadBooks();
          get().loadMindsetEntries();
          get().loadCalendarEvents();
          get().loadPlannedTasks();

          // Migrate planned tasks for today
          get().migratePlannedTasks(date);
        } catch (error) {
          console.error('Failed to load daily log:', error);
        } finally {
          set({ loading: false });
        }
      },

      // Tasks
      tasks: [],
      setTasks: (tasks) => set({ tasks }),
      addTask: async (title, category, priority = 'medium', dueDate, dueTime, reminder = false) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch('/api/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dailyLogId: log.id, title, category, priority, dueDate, dueTime, reminder }),
          });
          if (res.ok) {
            const task = await res.json();
            set({ tasks: [...get().tasks, task] });
          }
        } catch (error) { console.error('Failed to add task:', error); }
      },
      toggleTask: async (id) => {
        const task = get().tasks.find(t => t.id === id);
        if (!task) return;
        try {
          const res = await fetch(`/api/tasks/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ completed: !task.completed }),
          });
          if (res.ok) {
            set({ tasks: get().tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t) });
          }
        } catch (error) { console.error('Failed to toggle task:', error); }
      },
      deleteTask: async (id) => {
        try {
          const res = await fetch(`/api/tasks/${id}`, { method: 'DELETE' });
          if (res.ok) { set({ tasks: get().tasks.filter(t => t.id !== id) }); }
        } catch (error) { console.error('Failed to delete task:', error); }
      },

      // Expenses
      expenses: [],
      setExpenses: (expenses) => set({ expenses }),
      addExpense: async (name, amount, category) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch('/api/expenses', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dailyLogId: log.id, name, amount, category }),
          });
          if (res.ok) {
            const expense = await res.json();
            const newExpenses = [...get().expenses, expense];
            const totalExpense = newExpenses.reduce((sum, e) => sum + e.amount, 0);
            set({ expenses: newExpenses });
            await fetch(`/api/daily-log/${log.id}`, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ totalExpense }),
            });
            set({ dailyLog: { ...log, totalExpense } });
          }
        } catch (error) { console.error('Failed to add expense:', error); }
      },
      deleteExpense: async (id) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch(`/api/expenses/${id}`, { method: 'DELETE' });
          if (res.ok) {
            const newExpenses = get().expenses.filter(e => e.id !== id);
            const totalExpense = newExpenses.reduce((sum, e) => sum + e.amount, 0);
            set({ expenses: newExpenses });
            await fetch(`/api/daily-log/${log.id}`, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ totalExpense }),
            });
            set({ dailyLog: { ...log, totalExpense } });
          }
        } catch (error) { console.error('Failed to delete expense:', error); }
      },

      // Incomes
      incomes: [],
      setIncomes: (incomes) => set({ incomes }),
      addIncome: async (source, amount) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch('/api/incomes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dailyLogId: log.id, source, amount }),
          });
          if (res.ok) {
            const income = await res.json();
            const newIncomes = [...get().incomes, income];
            const totalIncome = newIncomes.reduce((sum, i) => sum + i.amount, 0);
            set({ incomes: newIncomes });
            await fetch(`/api/daily-log/${log.id}`, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ totalIncome }),
            });
            set({ dailyLog: { ...log, totalIncome } });
          }
        } catch (error) { console.error('Failed to add income:', error); }
      },

      // Exercises
      exercises: [],
      setExercises: (exercises) => set({ exercises }),
      addExercise: async (name, sets, reps, type) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch('/api/exercises', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dailyLogId: log.id, name, sets, reps, type }),
          });
          if (res.ok) {
            const exercise = await res.json();
            set({ exercises: [...get().exercises, exercise] });
          }
        } catch (error) { console.error('Failed to add exercise:', error); }
      },
      deleteExercise: async (id) => {
        try {
          const res = await fetch(`/api/exercises/${id}`, { method: 'DELETE' });
          if (res.ok) { set({ exercises: get().exercises.filter(e => e.id !== id) }); }
        } catch (error) { console.error('Failed to delete exercise:', error); }
      },

      // Journal
      journal: null,
      setJournal: (journal) => set({ journal }),
      saveJournal: async (data) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch('/api/journal', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dailyLogId: log.id, ...data }),
          });
          if (res.ok) { set({ journal: data }); }
        } catch (error) { console.error('Failed to save journal:', error); }
      },

      // Skills (daily)
      skills: [],
      setSkills: (skills) => set({ skills }),
      addSkill: async (skillName, minutes, progress) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch('/api/skills', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dailyLogId: log.id, skillName, minutes, progress }),
          });
          if (res.ok) {
            const skill = await res.json();
            set({ skills: [...get().skills, skill] });
          }
        } catch (error) { console.error('Failed to add skill:', error); }
      },
      updateSkill: async (id, minutes, progress) => {
        try {
          const res = await fetch(`/api/skills/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ minutes, progress }),
          });
          if (res.ok) {
            set({ skills: get().skills.map(s => s.id === id ? { ...s, minutes, progress } : s) });
          }
        } catch (error) { console.error('Failed to update skill:', error); }
      },

      // Custom Skills
      customSkills: [],
      setCustomSkills: (customSkills) => set({ customSkills }),
      loadCustomSkills: async () => {
        try {
          const res = await fetch('/api/custom-skills');
          if (res.ok) {
            const data = await res.json();
            set({ customSkills: data });
          }
        } catch (error) { console.error('Failed to load custom skills:', error); }
      },
      addCustomSkill: async (name, icon, color, targetHours) => {
        try {
          const settings = get().settings;
          const res = await fetch('/api/custom-skills', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ settingsId: settings?.id, name, icon, color, targetHours }),
          });
          if (res.ok) {
            const skill = await res.json();
            set({ customSkills: [...get().customSkills, skill] });
          }
        } catch (error) { console.error('Failed to add custom skill:', error); }
      },
      updateCustomSkill: async (id, data) => {
        try {
          const res = await fetch(`/api/custom-skills/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
          });
          if (res.ok) {
            set({ customSkills: get().customSkills.map(s => s.id === id ? { ...s, ...data } : s) });
          }
        } catch (error) { console.error('Failed to update custom skill:', error); }
      },
      deleteCustomSkill: async (id) => {
        try {
          const res = await fetch(`/api/custom-skills/${id}`, { method: 'DELETE' });
          if (res.ok) { set({ customSkills: get().customSkills.filter(s => s.id !== id) }); }
        } catch (error) { console.error('Failed to delete custom skill:', error); }
      },
      logCustomSkillTime: async (id, minutes) => {
        const skill = get().customSkills.find(s => s.id === id);
        if (!skill) return;
        const newHours = skill.loggedHours + minutes / 60;
        const newProgress = Math.min(Math.round((newHours / skill.targetHours) * 100), 100);
        await get().updateCustomSkill(id, { loggedHours: parseFloat(newHours.toFixed(1)), progress: newProgress });
      },

      // Goals
      goals: [],
      setGoals: (goals) => set({ goals }),
      addGoal: async (title, description, category, targetDate) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch('/api/goals', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dailyLogId: log.id, title, description, category, targetDate }),
          });
          if (res.ok) {
            const goal = await res.json();
            set({ goals: [...get().goals, goal] });
          }
        } catch (error) { console.error('Failed to add goal:', error); }
      },
      toggleGoal: async (id) => {
        const goal = get().goals.find(g => g.id === id);
        if (!goal) return;
        try {
          const res = await fetch(`/api/goals/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ completed: !goal.completed, progress: !goal.completed ? 100 : goal.progress }),
          });
          if (res.ok) {
            set({ goals: get().goals.map(g => g.id === id ? { ...g, completed: !g.completed, progress: !g.completed ? 100 : g.progress } : g) });
          }
        } catch (error) { console.error('Failed to toggle goal:', error); }
      },
      deleteGoal: async (id) => {
        try {
          const res = await fetch(`/api/goals/${id}`, { method: 'DELETE' });
          if (res.ok) { set({ goals: get().goals.filter(g => g.id !== id) }); }
        } catch (error) { console.error('Failed to delete goal:', error); }
      },
      updateGoalProgress: async (id, progress) => {
        try {
          const res = await fetch(`/api/goals/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ progress, completed: progress >= 100 }),
          });
          if (res.ok) {
            set({ goals: get().goals.map(g => g.id === id ? { ...g, progress, completed: progress >= 100 } : g) });
          }
        } catch (error) { console.error('Failed to update goal progress:', error); }
      },

      // Video Ideas
      videoIdeas: [],
      setVideoIdeas: (videoIdeas) => set({ videoIdeas }),
      addVideoIdea: async (title) => {
        try {
          const res = await fetch('/api/video-ideas', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title }),
          });
          if (res.ok) {
            const idea = await res.json();
            set({ videoIdeas: [...get().videoIdeas, idea] });
          }
        } catch (error) { console.error('Failed to add video idea:', error); }
      },
      deleteVideoIdea: async (id) => {
        try {
          const res = await fetch(`/api/video-ideas/${id}`, { method: 'DELETE' });
          if (res.ok) { set({ videoIdeas: get().videoIdeas.filter(i => i.id !== id) }); }
        } catch (error) { console.error('Failed to delete video idea:', error); }
      },

      // Books
      books: [],
      setBooks: (books) => set({ books }),
      loadBooks: async () => {
        try {
          const res = await fetch('/api/books');
          if (res.ok) {
            const data = await res.json();
            set({ books: data });
          }
        } catch (error) { console.error('Failed to load books:', error); }
      },
      addBook: async (title, author, category, totalPages) => {
        try {
          const res = await fetch('/api/books', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, author, category, totalPages }),
          });
          if (res.ok) {
            const book = await res.json();
            set({ books: [book, ...get().books] });
          }
        } catch (error) { console.error('Failed to add book:', error); }
      },
      updateBook: async (id, data) => {
        try {
          const res = await fetch(`/api/books/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
          });
          if (res.ok) {
            set({ books: get().books.map(b => b.id === id ? { ...b, ...data } : b) });
          }
        } catch (error) { console.error('Failed to update book:', error); }
      },
      deleteBook: async (id) => {
        try {
          const res = await fetch(`/api/books/${id}`, { method: 'DELETE' });
          if (res.ok) { set({ books: get().books.filter(b => b.id !== id) }); }
        } catch (error) { console.error('Failed to delete book:', error); }
      },
      updateBookProgress: async (id, readPages) => {
        const book = get().books.find(b => b.id === id);
        if (!book) return;
        const status = readPages >= book.totalPages ? 'completed' : readPages > 0 ? 'reading' : 'want-to-read';
        await get().updateBook(id, { readPages, status });

        // Update the local state immediately too
        set({ books: get().books.map(b => b.id === id ? { ...b, readPages, status } : b) });
      },

      // Mindset
      mindsetEntries: [],
      setMindsetEntries: (mindsetEntries) => set({ mindsetEntries }),
      loadMindsetEntries: async () => {
        try {
          const res = await fetch('/api/mindset');
          if (res.ok) {
            const data = await res.json();
            set({ mindsetEntries: data });
          }
        } catch (error) { console.error('Failed to load mindset entries:', error); }
      },
      addMindsetEntry: async (date, type, content, mood, gratitude) => {
        try {
          const res = await fetch('/api/mindset', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ date, type, content, mood, gratitude }),
          });
          if (res.ok) {
            const entry = await res.json();
            set({ mindsetEntries: [entry, ...get().mindsetEntries] });
          }
        } catch (error) { console.error('Failed to add mindset entry:', error); }
      },
      deleteMindsetEntry: async (id) => {
        try {
          const res = await fetch(`/api/mindset/${id}`, { method: 'DELETE' });
          if (res.ok) { set({ mindsetEntries: get().mindsetEntries.filter(e => e.id !== id) }); }
        } catch (error) { console.error('Failed to delete mindset entry:', error); }
      },

      // Calendar Events
      calendarEvents: [],
      setCalendarEvents: (calendarEvents) => set({ calendarEvents }),
      loadCalendarEvents: async () => {
        try {
          const res = await fetch('/api/calendar-events');
          if (res.ok) {
            const data = await res.json();
            set({ calendarEvents: data });
          }
        } catch (error) { console.error('Failed to load calendar events:', error); }
      },
      addCalendarEvent: async (title, description, date, time, endTime, category, recurring) => {
        try {
          const res = await fetch('/api/calendar-events', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, description, date, time, endTime, category, recurring }),
          });
          if (res.ok) {
            const event = await res.json();
            set({ calendarEvents: [...get().calendarEvents, event] });
          }
        } catch (error) { console.error('Failed to add calendar event:', error); }
      },
      updateCalendarEvent: async (id, data) => {
        try {
          const res = await fetch(`/api/calendar-events/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
          });
          if (res.ok) {
            set({ calendarEvents: get().calendarEvents.map(e => e.id === id ? { ...e, ...data } : e) });
          }
        } catch (error) { console.error('Failed to update calendar event:', error); }
      },
      deleteCalendarEvent: async (id) => {
        try {
          const res = await fetch(`/api/calendar-events/${id}`, { method: 'DELETE' });
          if (res.ok) { set({ calendarEvents: get().calendarEvents.filter(e => e.id !== id) }); }
        } catch (error) { console.error('Failed to delete calendar event:', error); }
      },
      toggleCalendarEvent: async (id) => {
        const event = get().calendarEvents.find(e => e.id === id);
        if (!event) return;
        await get().updateCalendarEvent(id, { completed: !event.completed });
      },

      // Default Skill Configs
      defaultSkillConfigs: [],
      setDefaultSkillConfigs: (defaultSkillConfigs) => set({ defaultSkillConfigs }),
      addDefaultSkillConfig: async (name, color, icon) => {
        const newConfig: DefaultSkillConfig = {
          id: `dsc_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
          name, color, icon,
        };
        const configs = [...get().defaultSkillConfigs, newConfig];
        set({ defaultSkillConfigs: configs });
        // Persist to settings
        const settings = get().settings;
        if (settings) {
          await get().updateSettings({ defaultSkillConfigs: JSON.stringify(configs) });
        }
      },
      updateDefaultSkillConfig: async (id, data) => {
        const configs = get().defaultSkillConfigs.map(c => c.id === id ? { ...c, ...data } : c);
        set({ defaultSkillConfigs: configs });
        const settings = get().settings;
        if (settings) {
          await get().updateSettings({ defaultSkillConfigs: JSON.stringify(configs) });
        }
      },
      deleteDefaultSkillConfig: async (id) => {
        const configs = get().defaultSkillConfigs.filter(c => c.id !== id);
        set({ defaultSkillConfigs: configs });
        const settings = get().settings;
        if (settings) {
          await get().updateSettings({ defaultSkillConfigs: JSON.stringify(configs) });
        }
      },

      // Planned Tasks
      plannedTasks: [],
      setPlannedTasks: (plannedTasks) => set({ plannedTasks }),
      loadPlannedTasks: async () => {
        try {
          const res = await fetch('/api/planned-tasks');
          if (res.ok) {
            const data = await res.json();
            set({ plannedTasks: data });
          }
        } catch (error) { console.error('Failed to load planned tasks:', error); }
      },
      addPlannedTask: async (title, category, priority, targetDate, dueTime) => {
        try {
          const res = await fetch('/api/planned-tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, category, priority, targetDate, dueTime }),
          });
          if (res.ok) {
            const task = await res.json();
            set({ plannedTasks: [task, ...get().plannedTasks] });
          }
        } catch (error) { console.error('Failed to add planned task:', error); }
      },
      deletePlannedTask: async (id) => {
        try {
          const res = await fetch(`/api/planned-tasks/${id}`, { method: 'DELETE' });
          if (res.ok) { set({ plannedTasks: get().plannedTasks.filter(t => t.id !== id) }); }
        } catch (error) { console.error('Failed to delete planned task:', error); }
      },
      migratePlannedTasks: async (targetDate) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch(`/api/planned-tasks?targetDate=${targetDate}`);
          if (res.ok) {
            const tasks: PlannedTaskItem[] = await res.json();
            const unmigrated = tasks.filter(t => !t.migrated);
            for (const pt of unmigrated) {
              // Create as regular task in today's daily log
              await fetch('/api/tasks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  dailyLogId: log.id,
                  title: pt.title,
                  category: pt.category,
                  priority: pt.priority,
                  dueDate: pt.targetDate,
                  dueTime: pt.dueTime,
                }),
              });
              // Mark as migrated
              await fetch(`/api/planned-tasks/${pt.id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ migrated: true }),
              });
            }
            // Reload tasks and planned tasks
            if (unmigrated.length > 0) {
              const logRes = await fetch(`/api/daily-log?date=${targetDate}`);
              if (logRes.ok) {
                const data = await logRes.json();
                set({ tasks: data.tasks || [] });
              }
              get().loadPlannedTasks();
            }
          }
        } catch (error) { console.error('Failed to migrate planned tasks:', error); }
      },

      // Prayer
      updatePrayer: async (prayer, status) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch(`/api/daily-log/${log.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ [prayer]: status }),
          });
          if (res.ok) { set({ dailyLog: { ...log, [prayer]: status } }); }
        } catch (error) { console.error('Failed to update prayer:', error); }
      },
      updateQuranPages: async (pages) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch(`/api/daily-log/${log.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ quranPages: pages }),
          });
          if (res.ok) { set({ dailyLog: { ...log, quranPages: pages } }); }
        } catch (error) { console.error('Failed to update quran pages:', error); }
      },

      // Fitness
      updateWater: async (glasses) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch(`/api/daily-log/${log.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ waterGlasses: glasses }),
          });
          if (res.ok) { set({ dailyLog: { ...log, waterGlasses: glasses } }); }
        } catch (error) { console.error('Failed to update water:', error); }
      },
      updateSleep: async (start, end, quality) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch(`/api/daily-log/${log.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sleepStart: start, sleepEnd: end, sleepQuality: quality }),
          });
          if (res.ok) { set({ dailyLog: { ...log, sleepStart: start, sleepEnd: end, sleepQuality: quality } }); }
        } catch (error) { console.error('Failed to update sleep:', error); }
      },
      updateWeight: async (weight) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch(`/api/daily-log/${log.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ weight }),
          });
          if (res.ok) { set({ dailyLog: { ...log, weight } }); }
        } catch (error) { console.error('Failed to update weight:', error); }
      },
      updateMood: async (moodScore, anxietyLevel, energyLevel) => {
        const log = get().dailyLog;
        if (!log) return;
        try {
          const res = await fetch(`/api/daily-log/${log.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ moodScore, anxietyLevel, energyLevel }),
          });
          if (res.ok) { set({ dailyLog: { ...log, moodScore, anxietyLevel, energyLevel } }); }
        } catch (error) { console.error('Failed to update mood:', error); }
      },

      // Settings
      settings: null,
      setSettings: (settings) => {
        // Parse defaultSkillConfigs from JSON string
        let parsedConfigs: DefaultSkillConfig[] = [];
        try {
          if (settings.defaultSkillConfigs) {
            parsedConfigs = JSON.parse(settings.defaultSkillConfigs);
          }
        } catch { parsedConfigs = []; }
        set({
          settings,
          theme: (settings.theme as ThemeName) || 'dashboard',
          fontSize: (settings.fontSize as FontSize) || 'medium',
          language: (settings.language as Language) || 'bn',
          defaultSkillConfigs: parsedConfigs,
        });
      },
      loadSettings: async () => {
        try {
          const res = await fetch('/api/settings');
          if (res.ok) {
            const data = await res.json();
            get().setSettings(data);
          }
        } catch (error) { console.error('Failed to load settings:', error); }
      },
      updateSettings: async (data) => {
        const settings = get().settings;
        if (!settings) return;
        try {
          const res = await fetch(`/api/settings/${settings.id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
          });
          if (res.ok) { set({ settings: { ...settings, ...data } }); }
        } catch (error) { console.error('Failed to update settings:', error); }
      },
      incrementYT: async (channel) => {
        const settings = get().settings;
        if (!settings) return;
        const field = channel === 1 ? 'ytVideos1' : 'ytVideos2';
        const newVal = (settings[field] || 0) + 1;
        await get().updateSettings({ [field]: newVal });
      },
      updateChess: async (field, value) => {
        await get().updateSettings({ [field]: value });
      },

      // Score Calculation
      calculateScore: () => {
        const { dailyLog, tasks } = get();
        if (!dailyLog) return 0;
        const prayers = ['fajr', 'zuhr', 'asr', 'maghrib', 'isha'] as const;
        let prayerScore = 0;
        prayers.forEach(p => {
          if (dailyLog[p] === 'jamaat') prayerScore += 4;
          else if (dailyLog[p] === 'alone') prayerScore += 3;
        });
        prayerScore = Math.min(prayerScore, 20);
        const totalTasks = tasks.length;
        const completedTasks = tasks.filter(t => t.completed).length;
        const productivityScore = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 20) : 0;
        const waterGoal = get().settings?.waterGoal || 8;
        const waterScore = Math.min((dailyLog.waterGlasses / waterGoal) * 10, 10);
        const hasWorkout = get().exercises.length > 0 ? 10 : 0;
        const fitnessScore = Math.round(waterScore + hasWorkout);
        const quranScore = Math.min(dailyLog.quranPages * 4, 10);
        const hasSkills = get().skills.length > 0 ? 10 : 0;
        const learningScore = Math.min(Math.round(quranScore + hasSkills), 20);
        const budget = dailyLog.dailyBudget;
        const spent = dailyLog.totalExpense;
        const financeScore = budget > 0 ? Math.round(Math.max(0, (1 - spent / budget)) * 20) : 10;
        return Math.min(prayerScore + productivityScore + fitnessScore + learningScore + financeScore, 100);
      },

      // XP System
      xp: 0,
      level: 1,
      addXP: (amount) => {
        const newXp = get().xp + amount;
        const newLevel = Math.floor(newXp / 100) + 1;
        set({ xp: newXp, level: newLevel });
      },

      // Loading
      loading: false,
      setLoading: (loading) => set({ loading }),

      // Auth
      supabaseUser: null,
      setSupabaseUser: (user) => set({ supabaseUser: user, isAuthenticated: !!user }),
      isAuthenticated: false,
      isSyncing: false,
      setIsSyncing: (syncing) => set({ isSyncing: syncing }),
      lastSyncAt: null,
      syncToCloud: async () => {
        const { supabaseUser } = get();
        if (!supabaseUser) return;
        try {
          set({ isSyncing: true });
          await fetch('/api/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: supabaseUser.id }),
          });
          set({ lastSyncAt: new Date().toISOString() });
        } catch (error) { console.error('Failed to sync to cloud:', error); }
        finally { set({ isSyncing: false }); }
      },
      syncFromCloud: async () => {
        const { supabaseUser } = get();
        if (!supabaseUser) return;
        try {
          set({ isSyncing: true });
          const res = await fetch(`/api/sync?userId=${supabaseUser.id}`);
          if (res.ok) {
            const data = await res.json();
            if (data.dailyLog) set({ dailyLog: data.dailyLog });
            if (data.tasks) set({ tasks: data.tasks });
            if (data.settings) get().setSettings(data.settings);
          }
          set({ lastSyncAt: new Date().toISOString() });
        } catch (error) { console.error('Failed to sync from cloud:', error); }
        finally { set({ isSyncing: false }); }
      },
      initialDataLoaded: false,
      setInitialDataLoaded: (loaded) => set({ initialDataLoaded: loaded }),
    }),
    {
      name: 'life-os-storage',
      storage: createJSONStorage(() => {
        if (typeof window === 'undefined') {
          return {
            getItem: () => null,
            setItem: () => {},
            removeItem: () => {},
          };
        }
        return localStorage;
      }),
      partialize: (state) => ({
        activeTab: state.activeTab,
        theme: state.theme,
        fontSize: state.fontSize,
        language: state.language,
        dailyLog: state.dailyLog,
        tasks: state.tasks,
        expenses: state.expenses,
        incomes: state.incomes,
        exercises: state.exercises,
        journal: state.journal,
        skills: state.skills,
        customSkills: state.customSkills,
        goals: state.goals,
        videoIdeas: state.videoIdeas,
        books: state.books,
        mindsetEntries: state.mindsetEntries,
        calendarEvents: state.calendarEvents,
        defaultSkillConfigs: state.defaultSkillConfigs,
        plannedTasks: state.plannedTasks,
        settings: state.settings,
        xp: state.xp,
        level: state.level,
        supabaseUser: state.supabaseUser,
        isAuthenticated: state.isAuthenticated,
        lastSyncAt: state.lastSyncAt,
      }),
      merge: (persistedState, currentState) => ({
        ...currentState,
        ...(persistedState as Partial<LifeOSStore>),
        loading: false,
        isSyncing: false,
      }),
    }
  )
);
