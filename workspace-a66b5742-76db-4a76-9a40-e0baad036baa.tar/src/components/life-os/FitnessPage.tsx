'use client';

import { useLifeOSStore, ExerciseType } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Dumbbell, Moon, Droplets, Scale, Plus, Trash2,
  Clock, ChevronDown, BedDouble, Sun, Waves,
} from 'lucide-react';
import { fadeInUpScale, fadeInUpExit, staggerContainer } from '@/lib/animations';

type FitnessTab = 'workout' | 'sleep' | 'water' | 'body';

const EXERCISE_TYPES: { value: ExerciseType; label: string; bn: string }[] = [
  { value: 'mma', label: 'MMA/Boxing', bn: 'MMA/বক্সিং' },
  { value: 'strength', label: 'Strength', bn: 'শক্তি' },
  { value: 'cardio', label: 'Cardio', bn: 'কার্ডিও' },
  { value: 'flexibility', label: 'Flexibility', bn: 'ফ্লেক্সিবিলিটি' },
  { value: 'other', label: 'Other', bn: 'অন্যান্য' },
];

const SLEEP_EMOJIS = ['😫', '😴', '😐', '😊', '🌟'];

export default function FitnessPage() {
  const { dailyLog, exercises, addExercise, deleteExercise, updateWater, updateSleep, updateWeight, settings, updateSettings, language } = useLifeOSStore();
  const [activeTab, setActiveTab] = useState<FitnessTab>('workout');
  const [exName, setExName] = useState('');
  const [exSets, setExSets] = useState('');
  const [exReps, setExReps] = useState('');
  const [exType, setExType] = useState<ExerciseType>('mma');
  const [sleepStart, setSleepStart] = useState(dailyLog?.sleepStart || '22:00');
  const [sleepEnd, setSleepEnd] = useState(dailyLog?.sleepEnd || '06:00');
  const [sleepQuality, setSleepQuality] = useState(dailyLog?.sleepQuality || 3);
  const [bodyWeight, setBodyWeight] = useState('');

  if (!dailyLog) return null;

  const waterGoal = settings?.waterGoal || 8;

  const handleAddExercise = async () => {
    if (!exName.trim()) return;
    await addExercise(exName.trim(), parseInt(exSets) || 0, parseInt(exReps) || 0, exType);
    setExName('');
    setExSets('');
    setExReps('');
  };

  const handleSaveSleep = async () => {
    await updateSleep(sleepStart, sleepEnd, sleepQuality);
  };

  const handleSaveWeight = async () => {
    if (bodyWeight) {
      await updateWeight(parseFloat(bodyWeight));
    }
  };

  const handleWaterClick = (glasses: number) => {
    updateWater(glasses);
  };

  const calculateSleepHours = () => {
    const [sh, sm] = sleepStart.split(':').map(Number);
    const [eh, em] = sleepEnd.split(':').map(Number);
    let start = sh * 60 + sm;
    let end = eh * 60 + em;
    if (end <= start) end += 24 * 60;
    return ((end - start) / 60).toFixed(1);
  };

  const calculateBMI = () => {
    const w = dailyLog.weight || parseFloat(bodyWeight);
    const h = (settings?.height || 170) / 100;
    if (!w || !h) return null;
    return (w / (h * h)).toFixed(1);
  };

  const getBMIStatus = (bmi: number) => {
    if (bmi < 18.5) return language === 'bn' ? 'কম ওজন' : 'Underweight';
    if (bmi < 25) return language === 'bn' ? 'স্বাভাবিক' : 'Normal';
    if (bmi < 30) return language === 'bn' ? 'বেশি ওজন' : 'Overweight';
    return language === 'bn' ? 'স্থূলতা' : 'Obese';
  };

  const getBMIColor = (bmi: number) => {
    if (bmi < 18.5) return 'text-life-amber';
    if (bmi < 25) return 'text-life-green';
    if (bmi < 30) return 'text-life-amber';
    return 'text-life-coral';
  };

  const getBMIBgClass = (bmi: number) => {
    if (bmi < 18.5) return 'bg-life-amber-bg border-life-amber/30';
    if (bmi < 25) return 'bg-life-green-bg border-life-green/30';
    if (bmi < 30) return 'bg-life-amber-bg border-life-amber/30';
    return 'bg-life-coral-bg border-life-coral/30';
  };

  const tabs: { id: FitnessTab; icon: React.ReactNode; label: string; color: string }[] = [
    { id: 'workout', icon: <Dumbbell className="w-4 h-4" />, label: t('fitness.workout', language), color: '#22C55E' },
    { id: 'sleep', icon: <Moon className="w-4 h-4" />, label: t('fitness.sleep', language), color: '#A78BFA' },
    { id: 'water', icon: <Droplets className="w-4 h-4" />, label: t('fitness.water', language), color: '#06B6D4' },
    { id: 'body', icon: <Scale className="w-4 h-4" />, label: t('fitness.body', language), color: '#F59E0B' },
  ];

  const exerciseTypeLabel = (type: ExerciseType) => {
    const et = EXERCISE_TYPES.find(e => e.value === type);
    return language === 'bn' ? (et?.bn || type) : (et?.label || type);
  };

  return (
    <motion.div
      className="space-y-4 pb-4"
      variants={staggerContainer}
      initial="hidden"
      animate="show"
    >
      {/* Page Title */}
      <motion.div variants={fadeInUpScale}>
        <h1 className="font-heading text-2xl sm:text-3xl font-bold text-life-text flex items-center gap-2.5">
          <Dumbbell className="w-6 h-6" />
          {t('fitness.title', language)}
        </h1>
        <p className="text-sm text-life-text3 mt-1 font-body">{t('fitness.subtitle', language)}</p>
      </motion.div>

      {/* Tab Switcher */}
      <motion.div variants={fadeInUpScale} className="flex gap-2 overflow-x-auto nav-scroll pb-1">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-200 ${
              activeTab === tab.id
                ? 'text-life-text'
                : 'text-life-text3 hover:text-life-text2'
            }`}
            style={activeTab === tab.id ? { backgroundColor: 'var(--life-bg2)', border: `1px solid var(--life-border)`, borderColor: `${tab.color}40` } : { backgroundColor: 'var(--life-bg3)' }}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </motion.div>

      {/* Tab Content */}
      <AnimatePresence mode="wait">
        {/* ===== WORKOUT TAB ===== */}
        {activeTab === 'workout' && (
          <motion.div
            key="workout"
            variants={fadeInUpExit}
            initial="hidden"
            animate="show"
            exit="exit"
            className="space-y-4"
          >
            {/* Add Exercise Card */}
            <div className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
              <div className="absolute top-0 right-0 w-20 h-20 bg-green-500/5 rounded-full blur-2xl pointer-events-none" />
              <div className="relative z-10">
                <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
                  <Plus className="w-4 h-4 text-life-green" />
                  {t('fitness.addWorkout', language)}
                </div>
                <input
                  className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary mb-3 font-body placeholder:text-life-text3"
                  placeholder={t('fitness.exerciseName', language)}
                  value={exName}
                  onChange={(e) => setExName(e.target.value)}
                />
                <div className="flex gap-2 flex-wrap">
                  <input
                    type="number"
                    className="w-20 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary font-body placeholder:text-life-text3"
                    placeholder={t('fitness.sets', language)}
                    value={exSets}
                    onChange={(e) => setExSets(e.target.value)}
                  />
                  <input
                    type="number"
                    className="w-24 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary font-body placeholder:text-life-text3"
                    placeholder={t('fitness.repsMin', language)}
                    value={exReps}
                    onChange={(e) => setExReps(e.target.value)}
                  />
                  <div className="relative flex-1 min-w-[120px]">
                    <select
                      className="w-full bg-life-bg3 border border-life-border text-life-text2 rounded-xl px-3 py-2.5 text-xs outline-none cursor-pointer appearance-none pr-8"
                      value={exType}
                      onChange={(e) => setExType(e.target.value as ExerciseType)}
                    >
                      {EXERCISE_TYPES.map((et) => (
                        <option key={et.value} value={et.value}>
                          {language === 'bn' ? et.bn : et.label}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-life-text3 pointer-events-none" />
                  </div>
                  <motion.button
                    onClick={handleAddExercise}
                    className="px-4 py-2.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-sm font-semibold flex items-center gap-1.5 transition-colors"
                    whileTap={{ scale: 0.95 }}
                  >
                    <Plus className="w-4 h-4" />
                    {t('fitness.add', language)}
                  </motion.button>
                </div>
              </div>
            </div>

            {/* Today's Workout List */}
            <div className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
              <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
                <Dumbbell className="w-4 h-4 text-life-green" />
                {t('fitness.todayWorkout', language)}
              </div>
              {exercises.length === 0 ? (
                <div className="text-center text-life-text3 text-sm py-8 border border-dashed border-life-border rounded-xl">
                  {t('fitness.noWorkout', language)}
                </div>
              ) : (
                <div className="space-y-2.5 max-h-96 overflow-y-auto life-scrollbar">
                  {exercises.map((ex, i) => (
                    <motion.div
                      key={ex.id}
                      className="rounded-xl p-3 flex items-center gap-3 group"
                      style={{ backgroundColor: 'var(--life-bg3)' }}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                    >
                      <div className="w-9 h-9 bg-life-green-bg border border-life-green/30 rounded-lg flex items-center justify-center text-life-green text-sm font-bold">
                        {i + 1}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-life-text truncate">{ex.name}</div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[11px] text-life-text3">
                            {ex.sets > 0 ? `${ex.sets}×${ex.reps}` : `${ex.reps} ${language === 'bn' ? 'মিনিট' : 'min'}`}
                          </span>
                          <span className="text-[10px] text-life-primary bg-life-purple-bg px-2 py-0.5 rounded-full">
                            {exerciseTypeLabel(ex.type)}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => deleteExercise(ex.id)}
                        className="text-life-text3 hover:text-life-coral transition-colors p-1.5 opacity-0 group-hover:opacity-100"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* ===== SLEEP TAB ===== */}
        {activeTab === 'sleep' && (
          <motion.div
            key="sleep"
            variants={fadeInUpExit}
            initial="hidden"
            animate="show"
            exit="exit"
            className="space-y-4"
          >
            {/* Sleep Log Card */}
            <div className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
              <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10">
                <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-4 flex items-center gap-2">
                  <BedDouble className="w-4 h-4 text-life-purple" />
                  {t('fitness.sleepLog', language)}
                </div>
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="rounded-xl p-3.5 text-center" style={{ backgroundColor: 'var(--life-bg3)' }}>
                    <div className="text-[11px] text-life-text3 mb-2 flex items-center justify-center gap-1">
                      <Moon className="w-3 h-3" />
                      {t('fitness.sleepTime', language)}
                    </div>
                    <input
                      type="time"
                      className="bg-transparent text-life-text text-center outline-none text-lg font-heading w-full"
                      value={sleepStart}
                      onChange={(e) => setSleepStart(e.target.value)}
                    />
                  </div>
                  <div className="rounded-xl p-3.5 text-center" style={{ backgroundColor: 'var(--life-bg3)' }}>
                    <div className="text-[11px] text-life-text3 mb-2 flex items-center justify-center gap-1">
                      <Sun className="w-3 h-3" />
                      {t('fitness.wakeTime', language)}
                    </div>
                    <input
                      type="time"
                      className="bg-transparent text-life-text text-center outline-none text-lg font-heading w-full"
                      value={sleepEnd}
                      onChange={(e) => setSleepEnd(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-[11px] text-life-text3 whitespace-nowrap">{t('fitness.sleepQuality', language)}</span>
                  <input
                    type="range"
                    min={1}
                    max={5}
                    value={sleepQuality}
                    onChange={(e) => setSleepQuality(parseInt(e.target.value))}
                    className="flex-1 h-2 rounded-full appearance-none cursor-pointer"
                    style={{
                      background: 'linear-gradient(to right, #EF4444, #F59E0B, #22C55E, #7C3AED, #A78BFA)',
                    }}
                  />
                  <span className="text-2xl">{SLEEP_EMOJIS[sleepQuality - 1]}</span>
                </div>
                <motion.button
                  onClick={handleSaveSleep}
                  className="w-full py-3 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-sm font-semibold font-heading transition-colors"
                  whileTap={{ scale: 0.98 }}
                >
                  {t('fitness.save', language)}
                </motion.button>
              </div>
            </div>

            {/* Sleep Summary */}
            <div className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
              <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4 text-life-purple2" />
                {t('fitness.sleepSummary', language)}
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl p-4 text-center" style={{ backgroundColor: 'var(--life-bg3)' }}>
                  <div className="text-3xl font-bold font-heading text-life-purple2">{calculateSleepHours()}</div>
                  <div className="text-[11px] text-life-text3 mt-1">{t('fitness.hoursSlept', language)}</div>
                </div>
                <div className="rounded-xl p-4 text-center" style={{ backgroundColor: 'var(--life-bg3)' }}>
                  <div className="text-3xl">
                    {SLEEP_EMOJIS[dailyLog.sleepQuality - 1]}
                  </div>
                  <div className="text-[11px] text-life-text3 mt-1">{t('fitness.quality', language)}</div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {/* ===== WATER TAB ===== */}
        {activeTab === 'water' && (
          <motion.div
            key="water"
            variants={fadeInUpExit}
            initial="hidden"
            animate="show"
            exit="exit"
            className="space-y-4"
          >
            <div className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
              <div className="absolute bottom-0 left-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10">
                <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-4 flex items-center gap-2">
                  <Waves className="w-4 h-4 text-life-blue" />
                  {t('fitness.waterTracker', language)}
                </div>

                {/* Water Glass Grid */}
                <div className="grid grid-cols-4 gap-2.5 mb-4">
                  {Array.from({ length: waterGoal }, (_, i) => i + 1).map((glass) => {
                    const filled = dailyLog.waterGlasses >= glass;
                    return (
                      <motion.button
                        key={glass}
                        onClick={() => handleWaterClick(glass)}
                        className={`aspect-square rounded-xl flex flex-col items-center justify-center text-lg transition-all duration-300 border ${
                          filled
                            ? 'bg-life-blue-bg border-life-blue/40 text-life-blue shadow-[0_0_12px_rgba(6,182,212,0.15)]'
                            : 'border-life-border text-life-text3'
                        }`}
                        style={!filled ? { backgroundColor: 'var(--life-bg3)' } : {}}
                        whileTap={{ scale: 0.9 }}
                        whileHover={{ scale: 1.05 }}
                      >
                        <span className={filled ? 'drop-shadow-[0_0_8px_rgba(6,182,212,0.5)]' : ''}>
                          💧
                        </span>
                        <span className={`text-[10px] mt-0.5 ${filled ? 'text-life-blue font-bold' : 'text-life-text3'}`}>
                          {glass}
                        </span>
                      </motion.button>
                    );
                  })}
                </div>

                {/* Water Progress */}
                <div className="text-center mb-3">
                  <span className="text-4xl font-bold font-heading text-life-blue">{dailyLog.waterGlasses}</span>
                  <span className="text-life-text3 text-lg"> / {waterGoal}</span>
                  <span className="text-life-text3 text-sm ml-1">{t('fitness.waterGoal', language)}</span>
                </div>

                <div className="h-3 bg-life-bg3 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-blue-500"
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min((dailyLog.waterGlasses / waterGoal) * 100, 100)}%` }}
                    transition={{ duration: 0.6, ease: 'easeOut' }}
                    style={{ boxShadow: '0 0 12px rgba(6, 182, 212, 0.4)' }}
                  />
                </div>

                {dailyLog.waterGlasses > 0 && (
                  <motion.button
                    onClick={() => handleWaterClick(dailyLog.waterGlasses - 1)}
                    className="mt-3 text-xs text-life-text3 hover:text-life-coral transition-colors flex items-center gap-1 mx-auto"
                    whileTap={{ scale: 0.95 }}
                  >
                    {t('fitness.reduceGlass', language)}
                  </motion.button>
                )}
              </div>
            </div>
          </motion.div>
        )}

        {/* ===== BODY TAB ===== */}
        {activeTab === 'body' && (
          <motion.div
            key="body"
            variants={fadeInUpExit}
            initial="hidden"
            animate="show"
            exit="exit"
            className="space-y-4"
          >
            <div className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
              <div className="absolute top-0 right-0 w-20 h-20 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
              <div className="relative z-10">
                <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-4 flex items-center gap-2">
                  <Scale className="w-4 h-4 text-life-amber" />
                  {t('fitness.bodyMeasure', language)}
                </div>

                {/* Weight Input */}
                <div className="mb-4">
                  <div className="text-[11px] text-life-text3 mb-1.5">{t('fitness.currentWeight', language)}</div>
                  <div className="flex gap-2 items-center">
                    <input
                      type="number"
                      className="flex-1 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary font-body placeholder:text-life-text3"
                      placeholder="55.0"
                      step="0.1"
                      value={bodyWeight}
                      onChange={(e) => setBodyWeight(e.target.value)}
                    />
                    <motion.button
                      onClick={handleSaveWeight}
                      className="px-4 py-2.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-sm font-semibold transition-colors"
                      whileTap={{ scale: 0.95 }}
                    >
                      {t('fitness.save', language)}
                    </motion.button>
                  </div>
                </div>

                {/* Height Input */}
                <div className="mb-4">
                  <div className="text-[11px] text-life-text3 mb-1.5">{t('fitness.height', language)}</div>
                  <input
                    type="number"
                    className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary font-body placeholder:text-life-text3"
                    placeholder="170"
                    value={settings?.height || 170}
                    onChange={(e) => updateSettings({ height: parseFloat(e.target.value) || 170 })}
                  />
                </div>

                {/* Current Weight Display */}
                {dailyLog.weight > 0 && (
                  <div className="rounded-xl p-4 text-center mb-4" style={{ backgroundColor: 'var(--life-bg3)' }}>
                    <div className="text-[11px] text-life-text3 mb-1">
                      {language === 'bn' ? 'বর্তমান ওজন' : 'Current Weight'}
                    </div>
                    <div className="text-3xl font-bold font-heading text-life-amber">
                      {dailyLog.weight}
                      <span className="text-sm text-life-text3 ml-1">kg</span>
                    </div>
                  </div>
                )}

                {/* BMI Display */}
                {calculateBMI() && (
                  <div className={`rounded-xl p-4 text-center border ${getBMIBgClass(parseFloat(calculateBMI()!))}`}>
                    <div className="text-[11px] text-life-text3 mb-1">{t('fitness.bmi', language)}</div>
                    <div className={`text-3xl font-bold font-heading ${getBMIColor(parseFloat(calculateBMI()!))}`}>
                      {calculateBMI()}
                    </div>
                    <div className={`text-xs mt-1 ${getBMIColor(parseFloat(calculateBMI()!))}`}>
                      {getBMIStatus(parseFloat(calculateBMI()!))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
