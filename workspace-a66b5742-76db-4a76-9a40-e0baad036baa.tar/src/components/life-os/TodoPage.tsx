'use client';

import { useLifeOSStore, TaskCategory, TaskPriority } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion, AnimatePresence } from 'framer-motion';
import { useState, useMemo } from 'react';
import {
  CheckCircle2,
  ClipboardList,
  Clock,
  Calendar,
  AlertTriangle,
  ArrowRight,
  Bell,
  BellOff,
  ChevronDown,
  ChevronUp,
  Timer,
  Flame,
  Zap,
  Minus,
  Trash2,
  Plus,
} from 'lucide-react';

const CATEGORIES: { value: TaskCategory; labelKey: string; bg: string; text: string; dot: string }[] = [
  { value: 'personal', labelKey: 'todo.personal', bg: 'bg-life-amber/15', text: 'text-life-amber', dot: '#F59E0B' },
  { value: 'bba', labelKey: 'todo.bba', bg: 'bg-life-purple/15', text: 'text-life-purple2', dot: '#7C3AED' },
  { value: 'dev', labelKey: 'todo.dev', bg: 'bg-life-blue/15', text: 'text-life-blue', dot: '#06B6D4' },
  { value: 'fitness', labelKey: 'todo.fitness', bg: 'bg-life-coral/15', text: 'text-life-coral', dot: '#EF4444' },
  { value: 'freelancing', labelKey: 'todo.freelancing', bg: 'bg-life-green/15', text: 'text-life-green', dot: '#22C55E' },
  { value: 'chess', labelKey: 'todo.chess', bg: 'bg-life-pink/15', text: 'text-life-pink', dot: '#EC4899' },
];

const PRIORITIES: { value: TaskPriority; labelKey: string; icon: typeof Flame; color: string; bg: string }[] = [
  { value: 'mit', labelKey: 'todo.mit', icon: Flame, color: 'text-red-400', bg: 'bg-red-500/15' },
  { value: 'high', labelKey: 'todo.high', icon: Zap, color: 'text-orange-400', bg: 'bg-orange-500/15' },
  { value: 'medium', labelKey: 'todo.medium', icon: Minus, color: 'text-yellow-400', bg: 'bg-yellow-500/15' },
  { value: 'low', labelKey: 'todo.low', icon: Clock, color: 'text-blue-400', bg: 'bg-blue-500/15' },
];

// SVG Progress Ring Component
function ProgressRing({ percent, size = 56, strokeWidth = 4 }: { percent: number; size?: number; strokeWidth?: number }) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percent / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="var(--life-border)"
          strokeWidth={strokeWidth}
        />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="url(#progressGradient)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        />
        <defs>
          <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="var(--life-primary)" />
            <stop offset="100%" stopColor="var(--life-secondary)" />
          </linearGradient>
        </defs>
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-xs font-bold text-life-text font-heading">{percent}%</span>
      </div>
    </div>
  );
}

// Format time for display (24h to 12h)
function formatTimeDisplay(time: string | undefined, language: string): string {
  if (!time) return '';
  const [h, m] = time.split(':').map(Number);
  if (language === 'bn') {
    const period = h >= 12 ? 'PM' : 'AM';
    const hour12 = h % 12 || 12;
    return `${hour12}:${m.toString().padStart(2, '0')} ${period}`;
  }
  const period = h >= 12 ? 'PM' : 'AM';
  const hour12 = h % 12 || 12;
  return `${hour12}:${m.toString().padStart(2, '0')} ${period}`;
}

// Check if a task is overdue
function isOverdue(dueDate?: string, dueTime?: string, completed?: boolean): boolean {
  if (completed || !dueDate) return false;
  const now = new Date();
  const dueDateTime = new Date(`${dueDate}T${dueTime || '23:59'}`);
  return now > dueDateTime;
}

// Check if task is due today
function isDueToday(dueDate?: string): boolean {
  if (!dueDate) return false;
  const today = new Date().toISOString().split('T')[0];
  return dueDate === today;
}

// Check if task is due tomorrow
function isDueTomorrow(dueDate?: string): boolean {
  if (!dueDate) return false;
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  return dueDate === tomorrow.toISOString().split('T')[0];
}

// Format date for display
function formatDateDisplay(dateStr: string, language: string): string {
  const date = new Date(dateStr + 'T00:00:00');
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const diff = Math.floor((date.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  if (diff === 0) return language === 'bn' ? 'আজ' : 'Today';
  if (diff === 1) return language === 'bn' ? 'আগামীকাল' : 'Tomorrow';
  if (diff === -1) return language === 'bn' ? 'গতকাল' : 'Yesterday';
  if (diff < -1) return language === 'bn' ? `${Math.abs(diff)} দিন আগে` : `${Math.abs(diff)} days ago`;
  if (diff <= 7) return language === 'bn' ? `${diff} দিন পরে` : `In ${diff} days`;
  return date.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', { month: 'short', day: 'numeric' });
}

type SortMode = 'time' | 'priority' | 'category';

export default function TodoPage() {
  const { tasks, addTask, toggleTask, deleteTask, language, plannedTasks, addPlannedTask, deletePlannedTask } = useLifeOSStore();
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<TaskCategory>('personal');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [dueDate, setDueDate] = useState('');
  const [dueTime, setDueTime] = useState('');
  const [reminder, setReminder] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [sortMode, setSortMode] = useState<SortMode>('priority');
  const [showSortMenu, setShowSortMenu] = useState(false);  const [showPlanTomorrow, setShowPlanTomorrow] = useState(false);
  const [planTitle, setPlanTitle] = useState('');
  const [planCategory, setPlanCategory] = useState<TaskCategory>('personal');
  const [planPriority, setPlanPriority] = useState<TaskPriority>('medium');
  const [planTime, setPlanTime] = useState('');
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [editDueDate, setEditDueDate] = useState('');
  const [editDueTime, setEditDueTime] = useState('');

  const handleAdd = async () => {
    if (!title.trim()) return;
    await addTask(title.trim(), category, priority, dueDate || undefined, dueTime || undefined, reminder);
    setTitle('');
    setDueDate('');
    setDueTime('');
    setReminder(false);
    setShowAdvanced(false);
  };

  const completedCount = tasks.filter((task) => task.completed).length;
  const totalCount = tasks.length;
  const percent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  const getCategoryStyle = (cat: TaskCategory) => {
    return CATEGORIES.find((c) => c.value === cat) || CATEGORIES[0];
  };

  const getPriorityStyle = (pri: TaskPriority) => {
    return PRIORITIES.find((p) => p.value === pri) || PRIORITIES[2];
  };

  // Overdue count
  const overdueCount = tasks.filter((t) => isOverdue(t.dueDate, t.dueTime, t.completed)).length;
  // Due today count (non-completed)
  const dueTodayCount = tasks.filter((t) => !t.completed && isDueToday(t.dueDate)).length;

  // Sort tasks
  const sortedTasks = useMemo(() => {
    const incomplete = tasks.filter((t) => !t.completed);
    const complete = tasks.filter((t) => t.completed);

    const priorityOrder: Record<TaskPriority, number> = { mit: 0, high: 1, medium: 2, low: 3 };

    const sortFn = (a: typeof tasks[0], b: typeof tasks[0]) => {
      if (sortMode === 'priority') {
        return (priorityOrder[a.priority] ?? 2) - (priorityOrder[b.priority] ?? 2);
      }
      if (sortMode === 'time') {
        // Tasks with no due date go last
        if (!a.dueDate && !b.dueDate) return 0;
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        const aDate = `${a.dueDate}T${a.dueTime || '23:59'}`;
        const bDate = `${b.dueDate}T${b.dueTime || '23:59'}`;
        return aDate.localeCompare(bDate);
      }
      if (sortMode === 'category') {
        return a.category.localeCompare(b.category);
      }
      return 0;
    };

    incomplete.sort(sortFn);
    complete.sort(sortFn);

    return [...incomplete, ...complete];
  }, [tasks, sortMode]);

  // Handle edit time/date for existing task
  const handleEditTime = async (taskId: string) => {
    try {
      const res = await fetch(`/api/tasks/${taskId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dueDate: editDueDate || null, dueTime: editDueTime || null }),
      });
      if (res.ok) {
        const updatedTask = await res.json();
        const currentTasks = useLifeOSStore.getState().tasks;
        useLifeOSStore.getState().setTasks(
          currentTasks.map((t) => (t.id === taskId ? { ...t, dueDate: editDueDate || undefined, dueTime: editDueTime || undefined } : t))
        );
        setEditingTaskId(null);
      }
    } catch (error) {
      console.error('Failed to update task time:', error);
    }
  };

  return (
    <div className="space-y-4">
      {/* ===== Page Header ===== */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex items-center justify-between"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}>
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-heading text-xl font-bold text-life-text">
              {t('todo.title', language)}
            </h2>
            <p className="text-xs text-life-text3 mt-0.5">
              {t('todo.subtitle', language)}
            </p>
          </div>
        </div>

        {/* Progress Ring */}
        {totalCount > 0 && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20, delay: 0.2 }}
          >
            <ProgressRing percent={percent} />
          </motion.div>
        )}
      </motion.div>

      {/* ===== Quick Stats Row ===== */}
      {totalCount > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-2"
        >
          <div
            className="rounded-xl p-3 text-center"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
          >
            <div className="text-lg font-bold text-life-green">{completedCount}</div>
            <div className="text-[10px] text-life-text3">{t('todo.done', language)}</div>
          </div>
          {overdueCount > 0 && (
            <div
              className="rounded-xl p-3 text-center"
              style={{ backgroundColor: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)' }}
            >
              <div className="text-lg font-bold text-red-400">{overdueCount}</div>
              <div className="text-[10px] text-red-400/70">{t('todo.overdue', language)}</div>
            </div>
          )}
          {dueTodayCount > 0 && (
            <div
              className="rounded-xl p-3 text-center"
              style={{ backgroundColor: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.3)' }}
            >
              <div className="text-lg font-bold text-life-amber">{dueTodayCount}</div>
              <div className="text-[10px] text-life-amber/70">{t('todo.dueToday', language)}</div>
            </div>
          )}
          <div
            className="rounded-xl p-3 text-center"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
          >
            <div className="text-lg font-bold text-life-text2">{totalCount - completedCount}</div>
            <div className="text-[10px] text-life-text3">{t('todo.pending', language)}</div>
          </div>
        </motion.div>
      )}

      {/* ===== Progress Bar ===== */}
      {totalCount > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="rounded-xl p-4 flex items-center gap-4"
          style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
        >
          <div className="flex-1">
            <div className="flex justify-between text-xs text-life-text3 mb-1.5">
              <span>{completedCount} {t('todo.done', language)}</span>
              <span>{t('todo.total', language)} {totalCount}</span>
            </div>
            <div className="h-2 bg-life-bg3 rounded-full overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-life-primary to-life-secondary"
                initial={{ width: 0 }}
                animate={{ width: `${percent}%` }}
                transition={{ duration: 0.6, ease: 'easeOut' }}
              />
            </div>
          </div>
        </motion.div>
      )}

      {/* ===== Add Task Section ===== */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="rounded-xl p-4"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        {/* Title Input */}
        <div className="flex gap-2 mb-3">
          <input
            className="flex-1 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3.5 py-2.5 text-sm focus:border-life-primary transition-colors"
            placeholder={t('todo.addNew', language)}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
          />
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleAdd}
            className="px-4 py-2.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-sm font-semibold transition-colors touch-target flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            {t('todo.add', language)}
          </motion.button>
        </div>

        {/* Category Picker */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setCategory(cat.value)}
              className={`
                px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all duration-200 touch-target
                ${category === cat.value
                  ? `${cat.bg} ${cat.text} border border-current/30`
                  : 'bg-life-bg3 text-life-text3 border border-life-border hover:border-life-border2'
                }
              `}
            >
              <span
                className="inline-block w-1.5 h-1.5 rounded-full mr-1"
                style={{ background: cat.dot }}
              />
              {t(cat.labelKey, language)}
            </button>
          ))}
        </div>

        {/* Priority Picker */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {PRIORITIES.map((pri) => {
            const Icon = pri.icon;
            return (
              <button
                key={pri.value}
                onClick={() => setPriority(pri.value)}
                className={`
                  px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all duration-200 touch-target flex items-center gap-1
                  ${priority === pri.value
                    ? `${pri.bg} ${pri.color} border border-current/30`
                    : 'bg-life-bg3 text-life-text3 border border-life-border hover:border-life-border2'
                  }
                `}
              >
                <Icon className="w-3 h-3" />
                {t(pri.labelKey, language)}
              </button>
            );
          })}
        </div>

        {/* Advanced Toggle */}
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="flex items-center gap-1.5 text-xs text-life-text3 hover:text-life-primary transition-colors mb-2 touch-target"
        >
          {showAdvanced ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          <Timer className="w-3.5 h-3.5" />
          {t('todo.setTime', language)}
        </button>

        {/* Time & Date Pickers */}
        <AnimatePresence>
          {showAdvanced && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div className="grid grid-cols-2 gap-3 pt-2">
                {/* Due Date */}
                <div>
                  <label className="text-[10px] text-life-text3 mb-1 block flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {t('todo.dueDate', language)}
                  </label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full bg-life-bg3 border border-life-border text-life-text rounded-lg px-3 py-2 text-xs focus:border-life-primary transition-colors [color-scheme:dark]"
                  />
                </div>

                {/* Due Time */}
                <div>
                  <label className="text-[10px] text-life-text3 mb-1 block flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {t('todo.dueTime', language)}
                  </label>
                  <input
                    type="time"
                    value={dueTime}
                    onChange={(e) => setDueTime(e.target.value)}
                    className="w-full bg-life-bg3 border border-life-border text-life-text rounded-lg px-3 py-2 text-xs focus:border-life-primary transition-colors [color-scheme:dark]"
                  />
                </div>

                {/* Reminder Toggle */}
                <div className="col-span-2">
                  <button
                    onClick={() => setReminder(!reminder)}
                    className={`
                      flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all touch-target
                      ${reminder
                        ? 'bg-life-primary/15 text-life-primary border border-life-primary/30'
                        : 'bg-life-bg3 text-life-text3 border border-life-border'
                      }
                    `}
                  >
                    {reminder ? <Bell className="w-3.5 h-3.5" /> : <BellOff className="w-3.5 h-3.5" />}
                    {reminder ? t('todo.reminderOn', language) : t('todo.reminderOff', language)}
                  </button>
                </div>

                {/* Quick Time Presets */}
                <div className="col-span-2">
                  <label className="text-[10px] text-life-text3 mb-1 block">{t('todo.quickSet', language)}</label>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { label: '6:00 AM', time: '06:00' },
                      { label: '9:00 AM', time: '09:00' },
                      { label: '12:00 PM', time: '12:00' },
                      { label: '3:00 PM', time: '15:00' },
                      { label: '6:00 PM', time: '18:00' },
                      { label: '9:00 PM', time: '21:00' },
                    ].map((preset) => (
                      <button
                        key={preset.time}
                        onClick={() => {
                          setDueTime(preset.time);
                          if (!dueDate) setDueDate(new Date().toISOString().split('T')[0]);
                        }}
                        className={`
                          px-2 py-1 rounded-md text-[10px] font-medium transition-all touch-target
                          ${dueTime === preset.time
                            ? 'bg-life-primary/15 text-life-primary border border-life-primary/30'
                            : 'bg-life-bg3 text-life-text3 border border-life-border hover:border-life-border2'
                          }
                        `}
                      >
                        {preset.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* ===== Plan Tomorrow Section ===== */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="rounded-xl overflow-hidden"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        {/* Header Toggle */}
        <button
          onClick={() => setShowPlanTomorrow(!showPlanTomorrow)}
          className="w-full p-4 flex items-center justify-between touch-target"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-orange-500/15">
              <ArrowRight className="w-4 h-4 text-orange-400" />
            </div>
            <div className="text-left">
              <span className="text-sm font-semibold text-life-text">{t('todo.planTomorrow', language)}</span>
              <p className="text-[10px] text-life-text3">
                {plannedTasks.filter(pt => {
                  const tomorrow = new Date();
                  tomorrow.setDate(tomorrow.getDate() + 1);
                  return pt.targetDate === tomorrow.toISOString().split('T')[0];
                }).length} {language === 'bn' ? 'টি কাজ পরিকল্পিত' : 'tasks planned'}
              </p>
            </div>
          </div>
          {showPlanTomorrow ? <ChevronUp className="w-4 h-4 text-life-text3" /> : <ChevronDown className="w-4 h-4 text-life-text3" />}
        </button>

        <AnimatePresence>
          {showPlanTomorrow && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="overflow-hidden"
            >
              <div className="px-4 pb-4 space-y-3">
                {/* Add Planned Task */}
                <div className="flex gap-2">
                  <input
                    className="flex-1 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3.5 py-2.5 text-sm focus:border-life-primary transition-colors"
                    placeholder={t('todo.addForTomorrow', language)}
                    value={planTitle}
                    onChange={(e) => setPlanTitle(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && planTitle.trim()) {
                        const tomorrow = new Date();
                        tomorrow.setDate(tomorrow.getDate() + 1);
                        addPlannedTask(planTitle.trim(), planCategory, planPriority, tomorrow.toISOString().split('T')[0], planTime || undefined);
                        setPlanTitle('');
                        setPlanTime('');
                      }
                    }}
                  />
                  <motion.button
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      if (!planTitle.trim()) return;
                      const tomorrow = new Date();
                      tomorrow.setDate(tomorrow.getDate() + 1);
                      addPlannedTask(planTitle.trim(), planCategory, planPriority, tomorrow.toISOString().split('T')[0], planTime || undefined);
                      setPlanTitle('');
                      setPlanTime('');
                    }}
                    className="px-4 py-2.5 bg-orange-500 hover:bg-orange-500/90 text-white rounded-xl text-sm font-semibold transition-colors touch-target flex items-center gap-1.5"
                  >
                    <ArrowRight className="w-4 h-4" />
                    {t('common.add', language)}
                  </motion.button>
                </div>

                {/* Category & Priority & Time */}
                <div className="flex flex-wrap gap-1.5">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.value}
                      onClick={() => setPlanCategory(cat.value)}
                      className={`
                        px-2 py-0.5 rounded-md text-[10px] font-medium transition-all touch-target
                        ${planCategory === cat.value
                          ? `${cat.bg} ${cat.text} border border-current/30`
                          : 'bg-life-bg3 text-life-text3 border border-life-border'
                        }
                      `}
                    >
                      {t(cat.labelKey, language)}
                    </button>
                  ))}
                  <span className="text-life-border mx-0.5">|</span>
                  {PRIORITIES.map((pri) => {
                    const Icon = pri.icon;
                    return (
                      <button
                        key={pri.value}
                        onClick={() => setPlanPriority(pri.value)}
                        className={`
                          px-2 py-0.5 rounded-md text-[10px] font-medium transition-all touch-target flex items-center gap-0.5
                          ${planPriority === pri.value
                            ? `${pri.bg} ${pri.color} border border-current/30`
                            : 'bg-life-bg3 text-life-text3 border border-life-border'
                          }
                        `}
                      >
                        <Icon className="w-2.5 h-2.5" />
                        {t(pri.labelKey, language)}
                      </button>
                    );
                  })}
                </div>

                {/* Time */}
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-life-text3" />
                  <input
                    type="time"
                    value={planTime}
                    onChange={(e) => setPlanTime(e.target.value)}
                    className="bg-life-bg3 border border-life-border text-life-text rounded-lg px-2.5 py-1.5 text-xs focus:border-life-primary transition-colors [color-scheme:dark]"
                  />
                </div>

                {/* Planned Tasks List */}
                {plannedTasks.length > 0 ? (
                  <div className="space-y-1.5 max-h-64 overflow-y-auto">
                    {plannedTasks.map((pt) => {
                      const catStyle = getCategoryStyle(pt.category as TaskCategory);
                      const priStyle = getPriorityStyle(pt.priority as TaskPriority);
                      const PriIcon = priStyle.icon;
                      return (
                        <div
                          key={pt.id}
                          className="flex items-center gap-2.5 p-2.5 rounded-lg"
                          style={{ backgroundColor: 'var(--life-bg3)' }}
                        >
                          <ArrowRight className="w-3 h-3 text-orange-400 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <span className="text-xs font-medium text-life-text">{pt.title}</span>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className={`text-[9px] px-1.5 py-0.5 rounded-md ${catStyle.bg} ${catStyle.text}`}>
                                {t(catStyle.labelKey, language)}
                              </span>
                              <PriIcon className={`w-2.5 h-2.5 ${priStyle.color}`} />
                              {pt.dueTime && (
                                <span className="text-[9px] text-life-text3 flex items-center gap-0.5">
                                  <Clock className="w-2.5 h-2.5" />
                                  {formatTimeDisplay(pt.dueTime, language)}
                                </span>
                              )}
                              <span className="text-[9px] text-life-text3">
                                {formatDateDisplay(pt.targetDate, language)}
                              </span>
                            </div>
                          </div>
                          <button
                            onClick={() => deletePlannedTask(pt.id)}
                            className="text-life-text3 hover:text-life-coral transition-colors p-0.5 touch-target"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center text-xs text-life-text3 py-4">
                    {t('todo.noPlannedTasks', language)}
                  </div>
                )}

                {/* Info note */}
                <div className="text-[10px] text-life-text3 bg-life-primary/5 rounded-lg p-2.5 flex items-start gap-1.5">
                  <Calendar className="w-3 h-3 mt-0.5 text-life-primary flex-shrink-0" />
                  {language === 'bn'
                    ? 'আগামীকালের জন্য পরিকল্পিত কাজগুলো স্বয়ংক্রিয়ভাবে আগামীকালের টু-ডু লিস্টে যোগ হবে'
                    : "Tasks planned for tomorrow will automatically appear in tomorrow's to-do list"
                  }
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* ===== Sort Controls ===== */}
      {tasks.length > 0 && (
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-life-text3">{t('todo.sortBy', language)}:</span>
          {(['priority', 'time', 'category'] as SortMode[]).map((mode) => (
            <button
              key={mode}
              onClick={() => setSortMode(mode)}
              className={`
                px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all touch-target
                ${sortMode === mode
                  ? 'bg-life-primary/15 text-life-primary border border-life-primary/30'
                  : 'bg-life-bg3 text-life-text3 border border-life-border'
                }
              `}
            >
              {t(`todo.sort${mode.charAt(0).toUpperCase() + mode.slice(1)}`, language)}
            </button>
          ))}
        </div>
      )}

      {/* ===== Task List ===== */}
      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {tasks.length === 0 ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="rounded-xl p-8 border-2 border-dashed border-life-border2 flex flex-col items-center gap-3"
              style={{ backgroundColor: 'var(--life-bg3)' }}
            >
              <ClipboardList className="w-10 h-10 text-life-text3 opacity-40" />
              <p className="text-sm text-life-text3 text-center">{t('todo.noTasks', language)}</p>
            </motion.div>
          ) : (
            sortedTasks.map((task) => {
              const catStyle = getCategoryStyle(task.category);
              const priStyle = getPriorityStyle(task.priority);
              const PriIcon = priStyle.icon;
              const overdue = isOverdue(task.dueDate, task.dueTime, task.completed);
              const dueToday = isDueToday(task.dueDate);
              const dueTomorrow = isDueTomorrow(task.dueDate);
              const isEditing = editingTaskId === task.id;

              return (
                <motion.div
                  key={task.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20, scale: 0.95 }}
                  transition={{
                    layout: { type: 'spring', stiffness: 400, damping: 30 },
                    opacity: { duration: 0.2 },
                    x: { duration: 0.3 },
                  }}
                  className={`
                    rounded-xl p-4 transition-all duration-200
                    ${task.completed ? 'opacity-50' : ''}
                    ${overdue ? 'ring-1 ring-red-500/40' : ''}
                  `}
                  style={{
                    backgroundColor: overdue ? 'rgba(239,68,68,0.06)' : 'var(--life-bg2)',
                    border: overdue ? '1px solid rgba(239,68,68,0.3)' : '1px solid var(--life-border)',
                  }}
                >
                  <div className="flex items-center gap-3">
                    {/* Custom Checkbox */}
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={() => toggleTask(task.id)}
                      className={`
                        w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0
                        transition-all duration-300 touch-target
                        ${task.completed
                          ? 'bg-life-green border-life-green'
                          : overdue
                            ? 'border-red-400 hover:border-red-300'
                            : 'border-life-border2 hover:border-life-primary'
                        }
                      `}
                    >
                      {task.completed && (
                        <motion.svg
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ type: 'spring', stiffness: 500, damping: 20 }}
                          className="w-3.5 h-3.5 text-white"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </motion.svg>
                      )}
                    </motion.button>

                    {/* Task Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-sm leading-snug font-body ${
                            task.completed ? 'line-through text-life-text3' : 'text-life-text'
                          }`}
                        >
                          {task.title}
                        </span>
                        {/* Priority Icon */}
                        {!task.completed && (
                          <PriIcon className={`w-3.5 h-3.5 flex-shrink-0 ${priStyle.color}`} />
                        )}
                        {/* Reminder Indicator */}
                        {task.reminder && !task.completed && (
                          <Bell className="w-3 h-3 text-life-amber flex-shrink-0" />
                        )}
                      </div>

                      {/* Time & Date Display */}
                      {(task.dueDate || task.dueTime) && !isEditing && (
                        <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                          {task.dueDate && (
                            <button
                              onClick={() => {
                                setEditingTaskId(task.id);
                                setEditDueDate(task.dueDate || '');
                                setEditDueTime(task.dueTime || '');
                              }}
                              className={`
                                flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-medium transition-colors touch-target
                                ${overdue
                                  ? 'bg-red-500/15 text-red-400'
                                  : dueToday
                                    ? 'bg-life-amber/15 text-life-amber'
                                    : dueTomorrow
                                      ? 'bg-orange-500/15 text-orange-400'
                                      : 'bg-life-bg3 text-life-text3'
                                }
                              `}
                            >
                              <Calendar className="w-3 h-3" />
                              {formatDateDisplay(task.dueDate, language)}
                              {overdue && <AlertTriangle className="w-3 h-3 ml-0.5" />}
                            </button>
                          )}
                          {task.dueTime && (
                            <button
                              onClick={() => {
                                setEditingTaskId(task.id);
                                setEditDueDate(task.dueDate || '');
                                setEditDueTime(task.dueTime || '');
                              }}
                              className={`
                                flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-medium transition-colors touch-target
                                ${overdue
                                  ? 'bg-red-500/15 text-red-400'
                                  : 'bg-life-bg3 text-life-text3'
                                }
                              `}
                            >
                              <Clock className="w-3 h-3" />
                              {formatTimeDisplay(task.dueTime, language)}
                            </button>
                          )}
                        </div>
                      )}

                      {/* Inline Edit Time/Date */}
                      {isEditing && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          className="mt-2"
                        >
                          <div className="flex items-center gap-2">
                            <input
                              type="date"
                              value={editDueDate}
                              onChange={(e) => setEditDueDate(e.target.value)}
                              className="bg-life-bg3 border border-life-border text-life-text rounded-lg px-2 py-1.5 text-[11px] focus:border-life-primary transition-colors [color-scheme:dark]"
                            />
                            <input
                              type="time"
                              value={editDueTime}
                              onChange={(e) => setEditDueTime(e.target.value)}
                              className="bg-life-bg3 border border-life-border text-life-text rounded-lg px-2 py-1.5 text-[11px] focus:border-life-primary transition-colors [color-scheme:dark]"
                            />
                            <button
                              onClick={() => handleEditTime(task.id)}
                              className="px-2 py-1.5 bg-life-primary/15 text-life-primary rounded-lg text-[11px] font-medium touch-target"
                            >
                              {t('common.save', language)}
                            </button>
                            <button
                              onClick={() => setEditingTaskId(null)}
                              className="px-2 py-1.5 bg-life-bg3 text-life-text3 rounded-lg text-[11px] touch-target"
                            >
                              {t('common.cancel', language)}
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </div>

                    {/* Category Badge */}
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full flex-shrink-0 font-medium ${catStyle.bg} ${catStyle.text}`}
                    >
                      {t(catStyle.labelKey, language)}
                    </span>

                    {/* Delete Button */}
                    <motion.button
                      whileTap={{ scale: 0.85 }}
                      onClick={() => deleteTask(task.id)}
                      className="text-life-text3 hover:text-life-coral transition-colors touch-target p-1"
                      aria-label={t('common.delete', language)}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </motion.button>
                  </div>
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
