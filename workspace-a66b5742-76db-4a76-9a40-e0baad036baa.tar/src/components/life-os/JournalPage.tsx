'use client';

import { useLifeOSStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { fadeInUpScale } from '@/lib/animations';
import { BookOpen, Lightbulb, AlertTriangle, Heart, Target, Save, Sparkles } from 'lucide-react';

const MOOD_EMOJIS = ['', '😫', '😟', '😕', '😐', '🙂', '😊', '😄', '😃', '🌟', '🤩'];

// Animation variants
const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
};

export default function JournalPage() {
  const { journal, saveJournal, dailyLog, updateMood, language } = useLifeOSStore();
  const [learned, setLearned] = useState(journal?.learned || '');
  const [mistakes, setMistakes] = useState(journal?.mistakes || '');
  const [gratitude1, setGratitude1] = useState(journal?.gratitude1 || '');
  const [gratitude2, setGratitude2] = useState(journal?.gratitude2 || '');
  const [gratitude3, setGratitude3] = useState(journal?.gratitude3 || '');
  const [tomorrowGoal, setTomorrowGoal] = useState(journal?.tomorrowGoal || '');
  const [moodScore, setMoodScore] = useState(dailyLog?.moodScore || 5);
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    await saveJournal({
      learned,
      mistakes,
      gratitude1,
      gratitude2,
      gratitude3,
      tomorrowGoal,
    });
    await updateMood(moodScore, dailyLog?.anxietyLevel || 5, dailyLog?.energyLevel || 5);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const getMoodGradient = () => {
    if (moodScore <= 3) return 'from-red-500/20 to-orange-500/20';
    if (moodScore <= 5) return 'from-amber-500/20 to-yellow-500/20';
    if (moodScore <= 7) return 'from-green-500/20 to-emerald-500/20';
    return 'from-purple-500/20 to-cyan-500/20';
  };

  const gratitudeItems = [
    {
      num: '1',
      value: gratitude1,
      setter: setGratitude1,
      placeholder: t('journal.gratitude1', language),
    },
    {
      num: '2',
      value: gratitude2,
      setter: setGratitude2,
      placeholder: t('journal.gratitude2', language),
    },
    {
      num: '3',
      value: gratitude3,
      setter: setGratitude3,
      placeholder: t('journal.gratitude3', language),
    },
  ];

  return (
    <motion.div
      className="space-y-4 pb-4"
      variants={container}
      initial="hidden"
      animate="show"
    >
      {/* Page Title */}
      <motion.div variants={fadeInUpScale}>
        <h1 className="font-heading text-2xl sm:text-3xl font-bold text-life-text flex items-center gap-2.5">
          <BookOpen className="w-6 h-6" />
          {t('journal.title', language)}
        </h1>
        <p className="text-sm text-life-text3 mt-1 font-body">{t('journal.subtitle', language)}</p>
      </motion.div>

      {/* Mood Tracker Card */}
      <motion.div
        variants={fadeInUpScale}
        className={`rounded-xl p-4 relative overflow-hidden`}
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className={`absolute inset-0 bg-gradient-to-br ${getMoodGradient()} pointer-events-none`} />
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-life-primary" />
            {t('journal.mood', language)}
          </div>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <input
                type="range"
                min={1}
                max={10}
                value={moodScore}
                onChange={(e) => setMoodScore(parseInt(e.target.value))}
                className="w-full h-2 rounded-full appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #EF4444, #F59E0B, #22C55E, #7C3AED)`,
                }}
              />
              <div className="flex justify-between mt-1.5">
                <span className="text-[10px] text-life-text3">1</span>
                <span className="text-[10px] text-life-text3">5</span>
                <span className="text-[10px] text-life-text3">10</span>
              </div>
            </div>
            <div className="flex flex-col items-center gap-1 min-w-[56px]">
              <span className="text-3xl">{MOOD_EMOJIS[moodScore] || '😐'}</span>
              <span className={`text-lg font-bold font-heading`} style={{ color: 'var(--life-accent)' }}>
                {moodScore}
              </span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* What I Learned Card */}
      <motion.div variants={fadeInUpScale} className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="absolute top-0 right-0 w-20 h-20 bg-cyan-500/5 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
            <Lightbulb className="w-4 h-4 text-life-secondary" />
            {t('journal.learned', language)}
          </div>
          <textarea
            className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary resize-y min-h-[100px] leading-relaxed font-body placeholder:text-life-text3"
            placeholder={t('journal.learnedPlaceholder', language)}
            value={learned}
            onChange={(e) => setLearned(e.target.value)}
          />
        </div>
      </motion.div>

      {/* Mistakes Card */}
      <motion.div variants={fadeInUpScale} className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="absolute bottom-0 left-0 w-20 h-20 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-life-amber" />
            {t('journal.mistakes', language)}
          </div>
          <textarea
            className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary resize-y min-h-[100px] leading-relaxed font-body placeholder:text-life-text3"
            placeholder={t('journal.mistakesPlaceholder', language)}
            value={mistakes}
            onChange={(e) => setMistakes(e.target.value)}
          />
        </div>
      </motion.div>

      {/* 3 Gratitudes Card */}
      <motion.div variants={fadeInUpScale} className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="absolute top-0 left-0 w-24 h-24 bg-green-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-1 flex items-center gap-2">
            <Heart className="w-4 h-4 text-life-green" />
            {t('journal.gratitude', language)}
          </div>
          <div className="font-islamic text-life-green text-sm mb-3 animate-float inline-block">
            {language === 'bn' ? 'আলহামদুলিল্লাহ' : 'Alhamdulillah'}
          </div>
          <div className="space-y-2.5">
            {gratitudeItems.map((item) => (
              <div key={item.num} className="flex gap-2.5 items-start">
                <div className="w-7 h-7 bg-life-green-bg border border-life-green/30 rounded-lg flex items-center justify-center text-xs text-life-green font-bold flex-shrink-0 mt-1">
                  {item.num}
                </div>
                <input
                  className="flex-1 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-green font-body placeholder:text-life-text3"
                  placeholder={item.placeholder}
                  value={item.value}
                  onChange={(e) => item.setter(e.target.value)}
                />
              </div>
            ))}
          </div>
        </div>
      </motion.div>

      {/* Tomorrow's Goal Card */}
      <motion.div variants={fadeInUpScale} className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="absolute bottom-0 right-0 w-20 h-20 bg-purple-500/5 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
            <Target className="w-4 h-4 text-life-primary" />
            {t('journal.tomorrowGoal', language)}
          </div>
          <input
            className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary font-body placeholder:text-life-text3"
            placeholder={t('journal.tomorrowGoalPlaceholder', language)}
            value={tomorrowGoal}
            onChange={(e) => setTomorrowGoal(e.target.value)}
          />
        </div>
      </motion.div>

      {/* Save Button */}
      <motion.div variants={fadeInUpScale} className="pt-1">
        <motion.button
          onClick={handleSave}
          className="w-full py-3.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-sm font-semibold font-heading flex items-center justify-center gap-2 transition-colors"
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.98 }}
        >
          <Save className="w-4 h-4" />
          {t('journal.save', language)}
        </motion.button>

        {saved && (
          <motion.div
            className="text-center py-3 text-life-green text-sm font-medium"
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {t('journal.saved', language)}
          </motion.div>
        )}
      </motion.div>
    </motion.div>
  );
}
