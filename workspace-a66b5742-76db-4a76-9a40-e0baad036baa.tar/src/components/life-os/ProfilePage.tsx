'use client';

import { useLifeOSStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  User, Mail, MapPin, Briefcase, Heart, Star, Calendar,
  Trophy, Save, Camera, X, Flame, Zap, Target, Church,
  Dumbbell, BookOpen, DollarSign, Award, Clock, Edit3,
} from 'lucide-react';
import { fadeInUp, staggerContainer } from '@/lib/animations';

// ===== Animation Variants =====
const fadeIn = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0 },
};

// ===== Score Breakdown Categories =====
interface ScoreCategory {
  key: string;
  labelKey: string;
  labelKeyBn: string;
  color: string;
  icon: React.ReactNode;
  maxScore: number;
}

const SCORE_CATEGORIES: ScoreCategory[] = [
  {
    key: 'prayer',
    labelKey: 'Prayer',
    labelKeyBn: 'নামাজ',
    color: '#22C55E',
    icon: <Church className="w-4 h-4" />,
    maxScore: 20,
  },
  {
    key: 'productivity',
    labelKey: 'Productivity',
    labelKeyBn: 'উৎপাদনশীলতা',
    color: '#FF6B35',
    icon: <Target className="w-4 h-4" />,
    maxScore: 20,
  },
  {
    key: 'fitness',
    labelKey: 'Fitness',
    labelKeyBn: 'ফিটনেস',
    color: '#06B6D4',
    icon: <Dumbbell className="w-4 h-4" />,
    maxScore: 20,
  },
  {
    key: 'learning',
    labelKey: 'Learning',
    labelKeyBn: 'শিক্ষা',
    color: '#A78BFA',
    icon: <BookOpen className="w-4 h-4" />,
    maxScore: 20,
  },
  {
    key: 'finance',
    labelKey: 'Finance',
    labelKeyBn: 'অর্থ',
    color: '#F59E0B',
    icon: <DollarSign className="w-4 h-4" />,
    maxScore: 20,
  },
];

// ===== Helper: Calculate individual score categories =====
function calculateCategoryScores(
  dailyLog: NonNullable<ReturnType<typeof useLifeOSStore.getState>['dailyLog']>,
  tasks: ReturnType<typeof useLifeOSStore.getState>['tasks'],
  exercises: ReturnType<typeof useLifeOSStore.getState>['exercises'],
  skills: ReturnType<typeof useLifeOSStore.getState>['skills'],
  waterGoal: number,
) {
  // Prayer score
  const prayers = ['fajr', 'zuhr', 'asr', 'maghrib', 'isha'] as const;
  let prayerScore = 0;
  prayers.forEach(p => {
    if (dailyLog[p] === 'jamaat') prayerScore += 4;
    else if (dailyLog[p] === 'alone') prayerScore += 3;
  });
  prayerScore = Math.min(prayerScore, 20);

  // Productivity score
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const productivityScore = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 20) : 0;

  // Fitness score
  const waterScore = Math.min((dailyLog.waterGlasses / waterGoal) * 10, 10);
  const hasWorkout = exercises.length > 0 ? 10 : 0;
  const fitnessScore = Math.round(waterScore + hasWorkout);

  // Learning score
  const quranScore = Math.min(dailyLog.quranPages * 4, 10);
  const hasSkills = skills.length > 0 ? 10 : 0;
  const learningScore = Math.min(Math.round(quranScore + hasSkills), 20);

  // Finance score
  const budget = dailyLog.dailyBudget;
  const spent = dailyLog.totalExpense;
  const financeScore = budget > 0 ? Math.round(Math.max(0, (1 - spent / budget)) * 20) : 10;

  return {
    prayer: prayerScore,
    productivity: productivityScore,
    fitness: fitnessScore,
    learning: learningScore,
    finance: financeScore,
  };
}

// ===== Main Component =====
export default function ProfilePage() {
  const {
    settings,
    updateSettings,
    dailyLog,
    calculateScore,
    xp,
    level,
    language,
    tasks,
    exercises,
    skills,
  } = useLifeOSStore();

  const [isEditing, setIsEditing] = useState(false);
  const [saved, setSaved] = useState(false);

  // Form state
  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editLocation, setEditLocation] = useState('');
  const [editOccupation, setEditOccupation] = useState('');

  const score = calculateScore();
  const streak = dailyLog?.streak || 0;
  const waterGoal = settings?.waterGoal || 8;

  // Category scores
  const categoryScores = dailyLog
    ? calculateCategoryScores(dailyLog, tasks, exercises, skills, waterGoal)
    : { prayer: 0, productivity: 0, fitness: 0, learning: 0, finance: 0 };

  // XP calculations
  const xpForNextLevel = level * 100;
  const currentLevelXp = (level - 1) * 100;
  const xpProgress = xpForNextLevel > currentLevelXp
    ? ((xp - currentLevelXp) / (xpForNextLevel - currentLevelXp)) * 100
    : 0;
  const xpToNextLevel = xpForNextLevel - xp;

  // Profile data
  const name = settings?.name || '';
  const email = settings?.email || '';
  const bio = settings?.bio || '';
  const location = settings?.location || '';
  const occupation = settings?.occupation || '';
  const avatar = settings?.avatar || '';
  const createdAt = (settings as unknown as Record<string, unknown> & { createdAt?: string })?.createdAt;

  // Format member since date
  const memberSince = createdAt
    ? new Date(createdAt).toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    : '—';

  // First letter of name for avatar
  const avatarLetter = name ? name.charAt(0).toUpperCase() : '?';

  // Start editing
  const handleEdit = () => {
    setEditName(name);
    setEditEmail(email);
    setEditBio(bio);
    setEditLocation(location);
    setEditOccupation(occupation);
    setIsEditing(true);
  };

  // Cancel editing
  const handleCancel = () => {
    setIsEditing(false);
  };

  // Save profile
  const handleSave = async () => {
    await updateSettings({
      name: editName,
      email: editEmail,
      bio: editBio,
      location: editLocation,
      occupation: editOccupation,
    });
    setIsEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  // Stats cards data
  const statsCards = [
    {
      icon: <Award className="w-5 h-5" />,
      label: language === 'bn' ? 'লেভেল' : 'Level',
      value: level,
      color: '#FF6B35',
    },
    {
      icon: <Zap className="w-5 h-5" />,
      label: language === 'bn' ? 'মোট XP' : 'Total XP',
      value: xp,
      color: '#06B6D4',
    },
    {
      icon: <Flame className="w-5 h-5" />,
      label: language === 'bn' ? 'স্ট্রিক' : 'Streak',
      value: `${streak} ${language === 'bn' ? 'দিন' : 'days'}`,
      color: '#F59E0B',
    },
    {
      icon: <Star className="w-5 h-5" />,
      label: language === 'bn' ? "আজকের স্কোর" : "Today's Score",
      value: score,
      color: '#22C55E',
    },
  ];

  return (
    <motion.div
      className="space-y-5 pb-4"
      variants={staggerContainer}
      initial="hidden"
      animate="show"
    >
      {/* ===== Page Header ===== */}
      <motion.div variants={fadeInUp} className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}
        >
          <User className="w-5 h-5" />
        </div>
        <div>
          <h1 className="font-heading text-xl font-bold" style={{ color: 'var(--life-text)' }}>
            {t('profile.title', language)}
          </h1>
          <p className="text-xs" style={{ color: 'var(--life-text3)' }}>
            {t('profile.subtitle', language)}
          </p>
        </div>
      </motion.div>

      {/* ===== Profile Header Card ===== */}
      <motion.div
        variants={fadeInUp}
        className="rounded-xl p-6 relative overflow-hidden"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        {/* Background glow */}
        <div
          className="absolute top-0 right-0 w-40 h-40 rounded-full blur-3xl pointer-events-none"
          style={{ backgroundColor: 'rgba(255,107,53,0.06)' }}
        />
        <div
          className="absolute bottom-0 left-0 w-28 h-28 rounded-full blur-3xl pointer-events-none"
          style={{ backgroundColor: 'rgba(6,182,212,0.04)' }}
        />

        <div className="relative z-10">
          <AnimatePresence mode="wait">
            {!isEditing ? (
              <motion.div
                key="view"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                {/* Avatar + Info Row */}
                <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
                  {/* Avatar */}
                  <div className="relative group">
                    {avatar ? (
                      <div
                        className="w-24 h-24 rounded-full overflow-hidden border-2"
                        style={{ borderColor: 'var(--life-accent)' }}
                      >
                        <img
                          src={avatar}
                          alt={name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <div
                        className="w-24 h-24 rounded-full flex items-center justify-center text-3xl font-bold font-heading text-white border-2"
                        style={{
                          background: 'linear-gradient(135deg, var(--life-accent), var(--life-secondary))',
                          borderColor: 'var(--life-accent)',
                        }}
                      >
                        {avatarLetter}
                      </div>
                    )}
                    {/* Camera overlay */}
                    <div
                      className="absolute inset-0 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-200 cursor-pointer"
                      style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
                      onClick={handleEdit}
                    >
                      <Camera className="w-6 h-6 text-white" />
                    </div>
                  </div>

                  {/* Info */}
                  <div className="flex-1 text-center sm:text-left">
                    <h2
                      className="font-heading text-2xl font-bold mb-1"
                      style={{ color: 'var(--life-text)' }}
                    >
                      {name || (language === 'bn' ? 'আপনার নাম' : 'Your Name')}
                    </h2>

                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-3 mb-3">
                      {occupation && (
                        <div className="flex items-center gap-1.5">
                          <Briefcase className="w-3.5 h-3.5" style={{ color: 'var(--life-accent)' }} />
                          <span className="text-sm" style={{ color: 'var(--life-text2)' }}>
                            {occupation}
                          </span>
                        </div>
                      )}
                      {location && (
                        <div className="flex items-center gap-1.5">
                          <MapPin className="w-3.5 h-3.5" style={{ color: 'var(--life-accent)' }} />
                          <span className="text-sm" style={{ color: 'var(--life-text2)' }}>
                            {location}
                          </span>
                        </div>
                      )}
                      {email && (
                        <div className="flex items-center gap-1.5">
                          <Mail className="w-3.5 h-3.5" style={{ color: 'var(--life-text3)' }} />
                          <span className="text-sm" style={{ color: 'var(--life-text3)' }}>
                            {email}
                          </span>
                        </div>
                      )}
                    </div>

                    {bio ? (
                      <p className="text-sm leading-relaxed max-w-lg" style={{ color: 'var(--life-text2)' }}>
                        {bio}
                      </p>
                    ) : (
                      <p className="text-sm italic" style={{ color: 'var(--life-text3)' }}>
                        {language === 'bn' ? 'কোনো বায়ো নেই। এডিট করুন!' : 'No bio yet. Edit your profile!'}
                      </p>
                    )}

                    {/* Edit Button */}
                    <motion.button
                      onClick={handleEdit}
                      className="mt-4 flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white transition-colors duration-200"
                      style={{ backgroundColor: 'var(--life-accent)' }}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.97 }}
                    >
                      <Edit3 className="w-4 h-4" />
                      {language === 'bn' ? 'প্রোফাইল এডিট করুন' : 'Edit Profile'}
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="edit"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.25 }}
              >
                <div className="flex items-center justify-between mb-5">
                  <h3 className="font-heading text-lg font-semibold" style={{ color: 'var(--life-text)' }}>
                    {language === 'bn' ? 'প্রোফাইল সম্পাদনা' : 'Edit Profile'}
                  </h3>
                  <button
                    onClick={handleCancel}
                    className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors duration-200 hover:bg-white/10"
                    style={{ color: 'var(--life-text3)' }}
                    aria-label="Cancel"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  {/* Name */}
                  <div>
                    <label className="text-xs font-medium mb-2 flex items-center gap-1.5" style={{ color: 'var(--life-text3)' }}>
                      <User className="w-3.5 h-3.5" />
                      {t('profile.name', language)}
                    </label>
                    <input
                      type="text"
                      className="w-full rounded-xl px-4 py-3 text-sm transition-colors"
                      style={{
                        backgroundColor: 'var(--life-bg3)',
                        border: '1px solid var(--life-border)',
                        color: 'var(--life-text)',
                      }}
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      placeholder={language === 'bn' ? 'আপনার নাম' : 'Your name'}
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="text-xs font-medium mb-2 flex items-center gap-1.5" style={{ color: 'var(--life-text3)' }}>
                      <Mail className="w-3.5 h-3.5" />
                      {t('profile.email', language)}
                    </label>
                    <input
                      type="email"
                      className="w-full rounded-xl px-4 py-3 text-sm transition-colors"
                      style={{
                        backgroundColor: 'var(--life-bg3)',
                        border: '1px solid var(--life-border)',
                        color: 'var(--life-text)',
                      }}
                      value={editEmail}
                      onChange={(e) => setEditEmail(e.target.value)}
                      placeholder={language === 'bn' ? 'ইমেইল' : 'Email address'}
                    />
                  </div>

                  {/* Bio */}
                  <div>
                    <label className="text-xs font-medium mb-2 flex items-center gap-1.5" style={{ color: 'var(--life-text3)' }}>
                      <Heart className="w-3.5 h-3.5" />
                      {t('profile.bio', language)}
                    </label>
                    <textarea
                      className="w-full rounded-xl px-4 py-3 text-sm transition-colors resize-none"
                      style={{
                        backgroundColor: 'var(--life-bg3)',
                        border: '1px solid var(--life-border)',
                        color: 'var(--life-text)',
                        minHeight: '80px',
                      }}
                      value={editBio}
                      onChange={(e) => setEditBio(e.target.value)}
                      placeholder={language === 'bn' ? 'নিজের সম্পর্কে কিছু লিখুন...' : 'Write something about yourself...'}
                    />
                  </div>

                  {/* Location */}
                  <div>
                    <label className="text-xs font-medium mb-2 flex items-center gap-1.5" style={{ color: 'var(--life-text3)' }}>
                      <MapPin className="w-3.5 h-3.5" />
                      {t('profile.location', language)}
                    </label>
                    <input
                      type="text"
                      className="w-full rounded-xl px-4 py-3 text-sm transition-colors"
                      style={{
                        backgroundColor: 'var(--life-bg3)',
                        border: '1px solid var(--life-border)',
                        color: 'var(--life-text)',
                      }}
                      value={editLocation}
                      onChange={(e) => setEditLocation(e.target.value)}
                      placeholder={language === 'bn' ? 'অবস্থান' : 'Location'}
                    />
                  </div>

                  {/* Occupation */}
                  <div>
                    <label className="text-xs font-medium mb-2 flex items-center gap-1.5" style={{ color: 'var(--life-text3)' }}>
                      <Briefcase className="w-3.5 h-3.5" />
                      {t('profile.occupation', language)}
                    </label>
                    <input
                      type="text"
                      className="w-full rounded-xl px-4 py-3 text-sm transition-colors"
                      style={{
                        backgroundColor: 'var(--life-bg3)',
                        border: '1px solid var(--life-border)',
                        color: 'var(--life-text)',
                      }}
                      value={editOccupation}
                      onChange={(e) => setEditOccupation(e.target.value)}
                      placeholder={language === 'bn' ? 'পেশা' : 'Occupation'}
                    />
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-3 pt-2">
                    <motion.button
                      onClick={handleSave}
                      className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold text-white transition-colors duration-200"
                      style={{ backgroundColor: 'var(--life-accent)' }}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.97 }}
                    >
                      <Save className="w-4 h-4" />
                      {t('profile.save', language)}
                    </motion.button>
                    <motion.button
                      onClick={handleCancel}
                      className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-colors duration-200"
                      style={{
                        backgroundColor: 'var(--life-bg3)',
                        border: '1px solid var(--life-border)',
                        color: 'var(--life-text2)',
                      }}
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.97 }}
                    >
                      <X className="w-4 h-4" />
                      {t('common.cancel', language)}
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Saved Toast */}
          {saved && (
            <motion.div
              className="mt-4 text-center text-sm py-2 rounded-lg"
              style={{ color: '#22C55E', backgroundColor: 'rgba(34,197,94,0.1)' }}
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              ✅ {t('profile.saved', language)}
            </motion.div>
          )}
        </div>
      </motion.div>

      {/* ===== Stats Cards Grid ===== */}
      <motion.section variants={fadeInUp}>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {statsCards.map((card) => (
            <motion.div
              key={card.label}
              className="rounded-xl p-5 group cursor-default transition-all duration-300"
              style={{
                backgroundColor: 'var(--life-bg2)',
                border: '1px solid var(--life-border)',
              }}
              variants={fadeIn}
              whileHover={{ y: -3, transition: { duration: 0.2 } }}
            >
              <div className="flex items-center gap-2 mb-3">
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${card.color}15`, color: card.color }}
                >
                  {card.icon}
                </div>
                <span className="text-[12px] font-medium" style={{ color: 'var(--life-text3)' }}>
                  {card.label}
                </span>
              </div>
              <div className="text-2xl font-bold font-heading" style={{ color: 'var(--life-text)' }}>
                {card.value}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* ===== Life Score Breakdown ===== */}
      <motion.div
        variants={fadeInUp}
        className="rounded-xl p-5 relative overflow-hidden"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="absolute top-0 left-0 w-32 h-32 rounded-full blur-3xl pointer-events-none" style={{ backgroundColor: 'rgba(167,139,250,0.04)' }} />

        <div className="relative z-10">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <Trophy className="w-4 h-4" style={{ color: 'var(--life-accent)' }} />
              <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
                {language === 'bn' ? 'দৈনিক স্কোর ব্রেকডাউন' : 'Daily Score Breakdown'}
              </span>
            </div>
            <div className="flex items-center gap-1.5 text-[12px] font-bold px-2.5 py-1 rounded-full" style={{ backgroundColor: 'rgba(255,107,53,0.1)', color: 'var(--life-accent)' }}>
              {score}/100
            </div>
          </div>

          <div className="space-y-4">
            {SCORE_CATEGORIES.map((cat) => {
              const catScore = categoryScores[cat.key as keyof typeof categoryScores] || 0;
              const percent = cat.maxScore > 0 ? (catScore / cat.maxScore) * 100 : 0;

              return (
                <div key={cat.key}>
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-6 h-6 rounded-md flex items-center justify-center"
                        style={{ backgroundColor: `${cat.color}15`, color: cat.color }}
                      >
                        {cat.icon}
                      </div>
                      <span className="text-[12px] font-medium" style={{ color: 'var(--life-text2)' }}>
                        {language === 'bn' ? cat.labelKeyBn : cat.labelKey}
                      </span>
                    </div>
                    <span className="text-[12px] font-semibold" style={{ color: cat.color }}>
                      {catScore}/{cat.maxScore}
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full overflow-hidden" style={{ backgroundColor: 'var(--life-bg4)' }}>
                    <motion.div
                      className="h-full rounded-full"
                      style={{ backgroundColor: cat.color }}
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(percent, 100)}%` }}
                      transition={{ duration: 0.8, ease: 'easeOut', delay: 0.1 }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </motion.div>

      {/* ===== Achievements Section ===== */}
      <motion.div
        variants={fadeInUp}
        className="rounded-xl p-5 relative overflow-hidden"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="absolute bottom-0 right-0 w-28 h-28 rounded-full blur-3xl pointer-events-none" style={{ backgroundColor: 'rgba(255,107,53,0.05)' }} />

        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-5">
            <Star className="w-4 h-4" style={{ color: 'var(--life-accent)' }} />
            <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
              {language === 'bn' ? 'অর্জন ও অভিজ্ঞতা' : 'Achievements & XP'}
            </span>
          </div>

          {/* Level Progress */}
          <div className="flex items-center gap-4 mb-5">
            <div
              className="w-16 h-16 rounded-xl flex items-center justify-center text-2xl font-bold font-heading text-white flex-shrink-0"
              style={{ background: 'linear-gradient(135deg, var(--life-accent), var(--life-secondary))' }}
            >
              {level}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
                  {t('xp.level', language)} {level}
                </span>
                <span className="text-xs" style={{ color: 'var(--life-text3)' }}>
                  {xp} / {xpForNextLevel} {t('xp.points', language)}
                </span>
              </div>
              <div className="h-3 rounded-full overflow-hidden" style={{ backgroundColor: 'var(--life-bg3)' }}>
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: 'linear-gradient(90deg, var(--life-accent), var(--life-secondary))' }}
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(xpProgress, 100)}%` }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                />
              </div>
              <div className="flex items-center justify-between mt-1.5">
                <span className="text-[11px]" style={{ color: 'var(--life-text3)' }}>
                  {t('xp.nextLevel', language)}: {level + 1}
                </span>
                <span className="text-[11px] font-medium" style={{ color: 'var(--life-accent)' }}>
                  {xpToNextLevel} {t('xp.points', language)} {language === 'bn' ? 'বাকি' : 'to go'}
                </span>
              </div>
            </div>
          </div>

          {/* Achievement Badges Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div
              className="rounded-lg p-3 text-center"
              style={{ backgroundColor: 'var(--life-bg3)' }}
            >
              <div className="text-xl mb-1">🕌</div>
              <div className="text-[10px] font-medium" style={{ color: 'var(--life-text2)' }}>
                {language === 'bn' ? 'নামাজ যোদ্ধা' : 'Prayer Warrior'}
              </div>
              <div className="text-[9px] mt-0.5" style={{ color: 'var(--life-text3)' }}>
                {language === 'bn' ? '৫ ওয়াক্ত জামাত' : '5 Jamaat Prayers'}
              </div>
            </div>
            <div
              className="rounded-lg p-3 text-center"
              style={{ backgroundColor: 'var(--life-bg3)' }}
            >
              <div className="text-xl mb-1">🔥</div>
              <div className="text-[10px] font-medium" style={{ color: 'var(--life-text2)' }}>
                {language === 'bn' ? 'স্ট্রিক মাস্টার' : 'Streak Master'}
              </div>
              <div className="text-[9px] mt-0.5" style={{ color: 'var(--life-text3)' }}>
                {language === 'bn' ? `${streak} দিন ধারাবাহিক` : `${streak} day streak`}
              </div>
            </div>
            <div
              className="rounded-lg p-3 text-center"
              style={{ backgroundColor: 'var(--life-bg3)' }}
            >
              <div className="text-xl mb-1">📚</div>
              <div className="text-[10px] font-medium" style={{ color: 'var(--life-text2)' }}>
                {language === 'bn' ? 'শিক্ষার্থী' : 'Learner'}
              </div>
              <div className="text-[9px] mt-0.5" style={{ color: 'var(--life-text3)' }}>
                {language === 'bn' ? 'দক্ষতা অর্জন' : 'Skill Builder'}
              </div>
            </div>
            <div
              className="rounded-lg p-3 text-center"
              style={{ backgroundColor: 'var(--life-bg3)' }}
            >
              <div className="text-xl mb-1">💪</div>
              <div className="text-[10px] font-medium" style={{ color: 'var(--life-text2)' }}>
                {language === 'bn' ? 'ফিটনেস গুরু' : 'Fitness Guru'}
              </div>
              <div className="text-[9px] mt-0.5" style={{ color: 'var(--life-text3)' }}>
                {language === 'bn' ? 'ওয়ার্কআউট করুন' : 'Workout Regular'}
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ===== Member Since ===== */}
      <motion.div
        variants={fadeInUp}
        className="rounded-xl p-5 text-center"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="flex items-center justify-center gap-2 mb-2">
          <Calendar className="w-4 h-4" style={{ color: 'var(--life-accent)' }} />
          <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
            {t('profile.joinDate', language)}
          </span>
        </div>
        <div className="text-lg font-heading font-semibold" style={{ color: 'var(--life-accent)' }}>
          {memberSince}
        </div>
        <div className="flex items-center justify-center gap-1 mt-2" style={{ color: 'var(--life-text3)' }}>
          <Clock className="w-3 h-3" />
          <span className="text-[11px]">
            {language === 'bn' ? 'Life OS দিয়ে নিজেকে আপগ্রেড করুন' : 'Upgrading yourself with Life OS'}
          </span>
        </div>
      </motion.div>
    </motion.div>
  );
}
