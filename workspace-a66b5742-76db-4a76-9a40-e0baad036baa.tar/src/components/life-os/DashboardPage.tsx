'use client';

import { useLifeOSStore, PrayerStatus, TabPage } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { fadeInUp, staggerContainer } from '@/lib/animations';
import {
  Moon, Brain, Zap, BookOpen, Dumbbell, DollarSign, Church,
  CheckCircle2, Flame, Smile, Bot,
  Target, TrendingUp, Sparkles, ChevronRight,
  BarChart3, ListTodo,
  ArrowUpRight, ArrowDownRight, Minus, MoreVertical,
  Activity
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar
} from 'recharts';

// ===== Animation Variants =====
const fadeIn = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0 },
};

// ===== Chart mock data =====
const weeklyChartData = [
  { name: 'SAT', score: 65, prev: 55 },
  { name: 'SUN', score: 72, prev: 60 },
  { name: 'MON', score: 58, prev: 48 },
  { name: 'TUE', score: 80, prev: 70 },
  { name: 'WED', score: 75, prev: 65 },
  { name: 'THU', score: 68, prev: 58 },
  { name: 'FRI', score: 0, prev: 72 },
];

// ===== Custom Tooltip for Charts =====
function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ value: number; dataKey: string }>; label?: string }) {
  if (!active || !payload?.length) return null;
  return (
    <div
      className="rounded-lg px-3 py-2 text-xs shadow-xl"
      style={{ backgroundColor: 'var(--life-bg3)', border: '1px solid var(--life-border)' }}
    >
      <p className="font-medium" style={{ color: 'var(--life-text)' }}>{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.dataKey === 'score' ? 'var(--life-accent)' : 'var(--life-text3)' }}>
          {p.dataKey === 'score' ? 'This week' : 'Last week'}: {p.value}
        </p>
      ))}
    </div>
  );
}

// ===== Score Ring Component =====
function ScoreRing({ score, size = 120 }: { score: number; size?: number }) {
  const radius = (size - 14) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="transform -rotate-90">
        <defs>
          <linearGradient id="scoreGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF6B35" />
            <stop offset="100%" stopColor="#06B6D4" />
          </linearGradient>
        </defs>
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="8"
        />
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none" stroke="url(#scoreGrad)" strokeWidth="8" strokeLinecap="round"
          strokeDasharray={circumference} strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 1s cubic-bezier(0.4,0,0.2,1)' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-3xl font-bold font-heading" style={{ color: 'var(--life-accent)' }}>
          {score}
        </span>
        <span className="text-[9px]" style={{ color: 'var(--life-text3)' }}>
          {t('dash.score', useLifeOSStore.getState().language)}
        </span>
      </div>
    </div>
  );
}

// ===== Mini Progress Bar =====
function MiniProgressBar({ value, color }: { value: number; color: string }) {
  return (
    <div className="w-full h-1.5 rounded-full overflow-hidden mt-2" style={{ backgroundColor: 'var(--life-bg4)' }}>
      <motion.div
        className="h-full rounded-full"
        style={{ background: color }}
        initial={{ width: 0 }}
        animate={{ width: `${Math.min(value, 100)}%` }}
        transition={{ duration: 0.8, ease: 'easeOut', delay: 0.3 }}
      />
    </div>
  );
}

// ===== Heatmap Helper =====
function generateHeatmapData(todayScore: number): number[] {
  const data: number[] = [];
  for (let i = 27; i >= 0; i--) {
    if (i === 0) {
      data.push(todayScore);
    } else {
      const base = 30 + Math.random() * 50;
      const variance = Math.random() * 20 - 10;
      data.push(Math.max(0, Math.min(100, Math.round(base + variance))));
    }
  }
  return data;
}

function getHeatmapColor(score: number): string {
  if (score === 0) return 'rgba(255, 107, 53, 0.05)';
  if (score <= 30) return 'rgba(255, 107, 53, 0.2)';
  if (score <= 60) return 'rgba(255, 107, 53, 0.45)';
  return 'rgba(255, 107, 53, 0.8)';
}

// ===== Main Component =====
export default function DashboardPage() {
  const {
    dailyLog, tasks, skills, calculateScore,
    setActiveTab, language, updatePrayer,
  } = useLifeOSStore();

  if (!dailyLog) return null;

  const score = calculateScore();
  const prayers = ['fajr', 'zuhr', 'asr', 'maghrib', 'isha'] as const;
  const prayersDone = prayers.filter(p => dailyLog[p] !== 'none').length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const totalTasks = tasks.length;
  const todoPercent = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
  const streak = dailyLog.streak || 0;
  const moodScore = dailyLog.moodScore || 0;
  const waterGlasses = dailyLog.waterGlasses || 0;
  const quranPages = dailyLog.quranPages || 0;
  const totalSkillMinutes = skills.reduce((sum, s) => sum + s.minutes, 0);
  const learningScore = quranPages + Math.round(totalSkillMinutes / 30);

  const ayahIndex = new Date().getDate() % 5;
  const ayahText = t(`ayah.${ayahIndex + 1}`, language);
  const ayahRef = t(`ayah.${ayahIndex + 1}.ref`, language);

  const heatmapData = generateHeatmapData(score);

  const cyclePrayer = (prayer: typeof prayers[number]) => {
    const current = dailyLog[prayer] as PrayerStatus;
    const next: PrayerStatus = current === 'none' ? 'alone' : current === 'alone' ? 'jamaat' : 'none';
    updatePrayer(prayer, next);
  };

  const getScoreMsg = () => {
    if (score >= 80) return language === 'bn' ? 'অসাধারণ পারফরম্যান্স!' : 'Excellent Performance!';
    if (score >= 60) return language === 'bn' ? 'ভালো যাচ্ছে!' : 'On Track';
    if (score >= 40) return language === 'bn' ? 'মোটামুটি' : 'Average';
    if (score >= 20) return language === 'bn' ? 'উন্নতি দরকার' : 'Needs Work';
    return language === 'bn' ? 'শুরু করুন' : 'Just Started';
  };



  // AI Insights
  const getInsights = () => {
    const insights: { icon: React.ReactNode; text: string; action: string; color: string }[] = [];
    if (moodScore > 0 && moodScore < 5) {
      insights.push({
        icon: <Smile className="w-4 h-4" />,
        text: language === 'bn' ? 'আপনার মুড কম আছে। জার্নাল লেখা বা হাঁটার চেষ্টা করুন।' : 'Your mood has been low. Try journaling or going for a walk.',
        action: language === 'bn' ? 'জার্নাল খুলুন' : 'Open Journal',
        color: '#F59E0B',
      });
    }
    if (waterGlasses < 6) {
      insights.push({
        icon: <Activity className="w-4 h-4" />,
        text: language === 'bn' ? 'পর্যাপ্ত পানি পান করছেন না। ৮ গ্লাস লক্ষ্য রাখুন।' : "You're not drinking enough water. Aim for 8 glasses.",
        action: language === 'bn' ? 'পানি ট্র্যাক করুন' : 'Track Water',
        color: '#06B6D4',
      });
    }
    if (prayersDone < 3) {
      insights.push({
        icon: <Moon className="w-4 h-4" />,
        text: language === 'bn' ? 'জামাতে বেশি নামাজ পড়ার চেষ্টা করুন।' : 'Try to pray more prayers in Jamaat.',
        action: language === 'bn' ? 'নামাজ ট্র্যাক করুন' : 'Track Prayer',
        color: '#22C55E',
      });
    }
    if (dailyLog.totalExpense > dailyLog.dailyBudget && dailyLog.dailyBudget > 0) {
      insights.push({
        icon: <DollarSign className="w-4 h-4" />,
        text: language === 'bn' ? 'দৈনিক বাজেট ছাড়িয়ে গেছেন।' : "You've exceeded your daily budget.",
        action: language === 'bn' ? 'খরচ দেখুন' : 'View Expenses',
        color: '#EF4444',
      });
    }
    if (insights.length === 0) {
      insights.push({
        icon: <Sparkles className="w-4 h-4" />,
        text: language === 'bn' ? 'চমৎকার কাজ! ধারাবাহিকতাই চাবিকাঠি।' : 'Keep up the great work! Consistency is key.',
        action: language === 'bn' ? 'রিভিউ দেখুন' : 'View Review',
        color: 'var(--life-accent)',
      });
    }
    return insights;
  };

  const insightActionTabs: Record<string, TabPage> = {
    'Open Journal': 'journal',
    'Track Water': 'fitness',
    'Track Prayer': 'namaz',
    'View Expenses': 'expense',
    'View Review': 'review',
    'জার্নাল খুলুন': 'journal',
    'পানি ট্র্যাক করুন': 'fitness',
    'নামাজ ট্র্যাক করুন': 'namaz',
    'খরচ দেখুন': 'expense',
    'রিভিউ দেখুন': 'review',
  };

  // ===== Metric Cards =====
  const metricCards = [
    {
      icon: <Church className="w-5 h-5" />,
      title: language === 'bn' ? 'নামাজ' : 'Prayers',
      value: `${prayersDone}/5`,
      subtitle: language === 'bn' ? `${5 - prayersDone}টি বাকি` : `${5 - prayersDone} remaining`,
      trend: prayersDone >= 3 ? 'up' : prayersDone > 0 ? 'neutral' : 'down',
      trendValue: prayersDone >= 3 ? `${language === 'bn' ? 'ভালো' : 'Good'}` : prayersDone > 0 ? `${language === 'bn' ? 'মোটামুটি' : 'Okay'}` : `${language === 'bn' ? 'শুরু করুন' : 'Start'}`,
      color: '#22C55E',
    },
    {
      icon: <CheckCircle2 className="w-5 h-5" />,
      title: language === 'bn' ? 'কাজ' : 'Tasks',
      value: `${completedTasks}/${totalTasks}`,
      subtitle: `${todoPercent}% ${language === 'bn' ? 'সম্পন্ন' : 'completed'}`,
      trend: todoPercent >= 60 ? 'up' : todoPercent >= 30 ? 'neutral' : 'down',
      trendValue: `${todoPercent}%`,
      color: 'var(--life-accent)',
    },
    {
      icon: <Dumbbell className="w-5 h-5" />,
      title: language === 'bn' ? 'ফিটনেস' : 'Fitness',
      value: `${waterGlasses}`,
      subtitle: language === 'bn' ? 'গ্লাস পানি' : 'glasses water',
      trend: waterGlasses >= 6 ? 'up' : 'down',
      trendValue: waterGlasses >= 6 ? `${language === 'bn' ? 'ভালো' : 'Good'}` : `${language === 'bn' ? 'কম' : 'Low'}`,
      color: '#06B6D4',
    },
    {
      icon: <BookOpen className="w-5 h-5" />,
      title: language === 'bn' ? 'শিক্ষা' : 'Learning',
      value: `${quranPages}`,
      subtitle: language === 'bn' ? 'কোরআন পৃষ্ঠা' : 'Quran pages',
      trend: quranPages >= 3 ? 'up' : 'neutral',
      trendValue: `+${learningScore}`,
      color: '#A78BFA',
    },
  ];

  // ===== Life Areas =====
  const lifeAreas = [
    { icon: <Brain className="w-5 h-5" />, label: t('areas.mindset', language), color: '#7C3AED', tab: 'journal' as TabPage },
    { icon: <Zap className="w-5 h-5" />, label: t('areas.discipline', language), color: '#F59E0B', tab: 'todo' as TabPage },
    { icon: <BookOpen className="w-5 h-5" />, label: t('areas.learning', language), color: '#06B6D4', tab: 'skills' as TabPage },
    { icon: <Dumbbell className="w-5 h-5" />, label: t('areas.fitness', language), color: '#22C55E', tab: 'fitness' as TabPage },
    { icon: <DollarSign className="w-5 h-5" />, label: t('areas.money', language), color: '#FBBF24', tab: 'expense' as TabPage },
    { icon: <Church className="w-5 h-5" />, label: t('areas.spirituality', language), color: '#34D399', tab: 'namaz' as TabPage },
  ];

  // ===== Prayer status config =====
  const prayerStatusConfig: Record<PrayerStatus, { label: string; bg: string; dot: string }> = {
    none: { label: language === 'bn' ? 'নেই' : 'Not yet', bg: '', dot: 'bg-white/20' },
    alone: { label: language === 'bn' ? 'একা' : 'Alone', bg: '', dot: 'bg-cyan-400' },
    jamaat: { label: language === 'bn' ? 'জামাত' : 'Jamaat', bg: '', dot: 'bg-green-400' },
  };

  const prayerLabels: Record<string, string> = {
    fajr: t('prayer.fajr', language),
    zuhr: t('prayer.zuhr', language),
    asr: t('prayer.asr', language),
    maghrib: t('prayer.maghrib', language),
    isha: t('prayer.isha', language),
  };



  // Update chart last day with today's score
  const chartData = weeklyChartData.map((d, i) =>
    i === 6 ? { ...d, score } : d
  );

  return (
    <motion.div
      className="space-y-5 pb-4"
      variants={staggerContainer}
      initial="hidden"
      animate="show"
    >
      {/* ===== 1. METRIC CARDS ROW ===== */}
      <motion.section variants={fadeInUp}>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {metricCards.map((card) => (
            <motion.div
              key={card.title}
              className="rounded-xl p-5 group cursor-default transition-all duration-300 hover:translate-y-[-2px]"
              style={{
                backgroundColor: 'var(--life-bg2)',
                border: '1px solid var(--life-border)',
              }}
              variants={fadeIn}
              whileHover={{ y: -4, transition: { duration: 0.2 } }}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div
                    className="w-9 h-9 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${card.color}15`, color: card.color }}
                  >
                    {card.icon}
                  </div>
                  <span className="text-[12px] font-medium" style={{ color: 'var(--life-text3)' }}>{card.title}</span>
                </div>
                {/* Trend indicator */}
                <div className={`flex items-center gap-0.5 text-[11px] font-medium px-1.5 py-0.5 rounded-full ${
                  card.trend === 'up' ? '' : card.trend === 'down' ? '' : ''
                }`}
                  style={{
                    color: card.trend === 'up' ? '#4CAF50' : card.trend === 'down' ? '#EF4444' : '#F59E0B',
                    backgroundColor: card.trend === 'up' ? 'rgba(76,175,80,0.1)' : card.trend === 'down' ? 'rgba(239,68,68,0.1)' : 'rgba(245,158,11,0.1)',
                  }}
                >
                  {card.trend === 'up' ? <ArrowUpRight className="w-3 h-3" /> : card.trend === 'down' ? <ArrowDownRight className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                  {card.trendValue}
                </div>
              </div>
              <div className="text-2xl font-bold font-heading" style={{ color: 'var(--life-text)' }}>
                {card.value}
              </div>
              <div className="text-[11px] mt-1" style={{ color: 'var(--life-text3)' }}>
                {card.subtitle}
              </div>
              <MiniProgressBar
                value={card.title === (language === 'bn' ? 'নামাজ' : 'Prayers') ? (prayersDone / 5) * 100
                  : card.title === (language === 'bn' ? 'কাজ' : 'Tasks') ? todoPercent
                  : card.title === (language === 'bn' ? 'ফিটনেস' : 'Fitness') ? (waterGlasses / 8) * 100
                  : Math.min(quranPages * 20, 100)
                }
                color={card.color}
              />
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* ===== 2. CHART + PRAYER SECTION ===== */}
      <motion.section variants={fadeInUp}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Line Chart Card */}
          <div
            className="lg:col-span-2 rounded-xl p-5"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
          >
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-medium" style={{ color: 'var(--life-text3)' }}>
                    {language === 'bn' ? 'সাপ্তাহিক' : 'YTD'}
                  </span>
                  <span
                    className="text-[11px] font-medium px-1.5 py-0.5 rounded-full"
                    style={{ color: '#4CAF50', backgroundColor: 'rgba(76,175,80,0.1)' }}
                  >
                    {language === 'bn' ? 'ট্র্যাকে আছে' : 'On track'}
                  </span>
                </div>
                <div className="text-2xl font-bold font-heading mt-1" style={{ color: 'var(--life-text)' }}>
                  {score}{language === 'bn' ? ' পয়েন্ট' : ' pts'}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: 'var(--life-accent)' }} />
                  <span className="text-[10px]" style={{ color: 'var(--life-text3)' }}>
                    {language === 'bn' ? 'এই সপ্তাহ' : 'This week'}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: 'rgba(255,255,255,0.2)' }} />
                  <span className="text-[10px]" style={{ color: 'var(--life-text3)' }}>
                    {language === 'bn' ? 'গত সপ্তাহ' : 'Last week'}
                  </span>
                </div>
              </div>
            </div>

            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#FF6B35" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#FF6B35" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis
                    dataKey="name"
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 10, fill: '#888888' }}
                  />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 10, fill: '#888888' }}
                    domain={[0, 100]}
                  />
                  <Tooltip content={<CustomTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="prev"
                    stroke="rgba(255,255,255,0.2)"
                    strokeWidth={1.5}
                    fill="transparent"
                    dot={false}
                  />
                  <Area
                    type="monotone"
                    dataKey="score"
                    stroke="#FF6B35"
                    strokeWidth={2}
                    fill="url(#areaGradient)"
                    dot={{ r: 3, fill: '#FF6B35', strokeWidth: 0 }}
                    activeDot={{ r: 5, fill: '#FF6B35', stroke: '#FFFFFF', strokeWidth: 2 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Prayer Tracker Card */}
          <div
            className="rounded-xl p-5 relative overflow-hidden"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
          >
            {/* Green glow decoration */}
            <div className="absolute top-0 right-0 w-20 h-20 rounded-full blur-3xl pointer-events-none" style={{ backgroundColor: 'rgba(34,197,94,0.08)' }} />

            <div className="relative z-10">
              {/* Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Moon className="w-4 h-4" style={{ color: '#22C55E' }} />
                  <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
                    {t('prayer.title', language)}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full" style={{ color: '#4CAF50', backgroundColor: 'rgba(76,175,80,0.1)' }}>
                  <div className="w-1.5 h-1.5 rounded-full bg-green-400" />
                  {prayersDone}/5
                </div>
              </div>

              {/* Prayer Grid */}
              <div className="space-y-2 mb-4">
                {prayers.map((prayer) => {
                  const status = dailyLog[prayer] as PrayerStatus;
                  const config = prayerStatusConfig[status];
                  const isJamaat = status === 'jamaat';
                  const isAlone = status === 'alone';
                  return (
                    <motion.button
                      key={prayer}
                      onClick={() => cyclePrayer(prayer)}
                      className="w-full flex items-center justify-between rounded-lg px-3 py-2 transition-all duration-200"
                      style={{
                        backgroundColor: isJamaat ? 'rgba(34,197,94,0.1)' : isAlone ? 'rgba(6,182,212,0.1)' : 'var(--life-bg3)',
                        border: `1px solid ${isJamaat ? 'rgba(34,197,94,0.3)' : isAlone ? 'rgba(6,182,212,0.3)' : 'var(--life-border)'}`,
                      }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`w-2 h-2 rounded-full ${config.dot}`} />
                        <span className="text-[12px] font-medium" style={{ color: 'var(--life-text)' }}>
                          {prayerLabels[prayer]}
                        </span>
                      </div>
                      <span className="text-[10px] font-medium" style={{
                        color: isJamaat ? '#22C55E' : isAlone ? '#06B6D4' : 'var(--life-text3)'
                      }}>
                        {config.label}
                      </span>
                    </motion.button>
                  );
                })}
              </div>

              {/* Islamic Quote */}
              <div className="text-center border-t pt-3" style={{ borderColor: 'var(--life-border)' }}>
                <div className="font-islamic text-[12px] leading-6" style={{ color: 'rgba(34,197,94,0.8)' }}>
                  {language === 'bn'
                    ? '"নামাজ মুমিনের মিরাজ"'
                    : '"Prayer is the Mi\'raj of the believer"'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* ===== 3. TASKS + AI COACH ===== */}
      <motion.section variants={fadeInUp}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Tasks Card */}
          <div
            className="rounded-xl p-5"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <ListTodo className="w-4 h-4" style={{ color: 'var(--life-accent)' }} />
                <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
                  {language === 'bn' ? 'আজকের কাজ' : "Today's Tasks"}
                </span>
              </div>
              <button
                onClick={() => setActiveTab('todo')}
                className="text-[11px] font-medium flex items-center gap-1 transition-colors hover:opacity-80"
                style={{ color: 'var(--life-accent)' }}
              >
                {language === 'bn' ? 'সব দেখুন' : 'View all'}
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto life-scrollbar">
              {tasks.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-[12px]" style={{ color: 'var(--life-text3)' }}>
                    {language === 'bn' ? 'কোনো কাজ নেই।' : 'No tasks yet.'}
                  </p>
                </div>
              ) : (
                tasks.slice(0, 6).map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center gap-3 rounded-lg px-3 py-2 transition-all duration-200"
                    style={{ backgroundColor: 'var(--life-bg3)' }}
                  >
                    <div
                      className="w-5 h-5 rounded flex items-center justify-center flex-shrink-0 cursor-pointer"
                      style={{
                        backgroundColor: task.completed ? 'var(--life-accent)' : 'transparent',
                        border: task.completed ? 'none' : '1.5px solid var(--life-border2)',
                      }}
                    >
                      {task.completed && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
                    </div>
                    <span
                      className={`text-[12px] flex-1 ${task.completed ? 'line-through' : ''}`}
                      style={{ color: task.completed ? 'var(--life-text3)' : 'var(--life-text)' }}
                    >
                      {task.title}
                    </span>
                    <MoreVertical className="w-3.5 h-3.5 flex-shrink-0" style={{ color: 'var(--life-text3)' }} />
                  </div>
                ))
              )}
            </div>
          </div>

          {/* AI Coach Card */}
          <div
            className="rounded-xl p-5 relative overflow-hidden"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
          >
            <div className="absolute bottom-0 left-0 w-24 h-24 rounded-full blur-3xl pointer-events-none" style={{ backgroundColor: 'rgba(255,107,53,0.05)' }} />

            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ background: 'linear-gradient(135deg, var(--life-accent), var(--life-secondary))' }}
                  >
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
                      {t('ai.title', language)}
                    </span>
                    <p className="text-[10px]" style={{ color: 'var(--life-text3)' }}>
                      {t('ai.subtitle', language)}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                {getInsights().map((insight, i) => (
                  <motion.div
                    key={i}
                    className="rounded-lg p-3 flex items-start gap-3"
                    style={{ backgroundColor: 'var(--life-bg3)' }}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 * i + 0.3 }}
                  >
                    <div
                      className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0 mt-0.5"
                      style={{ backgroundColor: `${insight.color}15`, color: insight.color }}
                    >
                      {insight.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[12px] leading-relaxed" style={{ color: 'var(--life-text2)' }}>{insight.text}</p>
                      <button
                        onClick={() => {
                          const tab = insightActionTabs[insight.action];
                          if (tab) setActiveTab(tab);
                        }}
                        className="text-[10px] font-medium mt-1.5 flex items-center gap-1 transition-colors hover:opacity-80"
                        style={{ color: insight.color }}
                      >
                        {insight.action}
                        <ChevronRight className="w-3 h-3" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* ===== 4. LIFE AREAS + AYAH ===== */}
      <motion.section variants={fadeInUp}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Life Areas Grid */}
          <div
            className="lg:col-span-2 rounded-xl p-5"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4" style={{ color: 'var(--life-accent)' }} />
                <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
                  {t('areas.title', language)}
                </span>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {lifeAreas.map((area) => (
                <motion.button
                  key={area.label}
                  onClick={() => setActiveTab(area.tab)}
                  className="rounded-lg p-4 text-left group relative overflow-hidden transition-all duration-300"
                  style={{ backgroundColor: 'var(--life-bg3)' }}
                  whileHover={{ y: -2, scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div
                    className="w-9 h-9 rounded-lg flex items-center justify-center mb-2"
                    style={{ backgroundColor: `${area.color}15`, color: area.color }}
                  >
                    {area.icon}
                  </div>
                  <div className="text-[12px] font-semibold" style={{ color: 'var(--life-text)' }}>
                    {area.label}
                  </div>
                  <div className="text-[10px] mt-0.5 flex items-center gap-1" style={{ color: 'var(--life-text3)' }}>
                    <ChevronRight className="w-3 h-3" />
                    {language === 'bn' ? 'বিস্তারিত' : 'View'}
                  </div>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Ayah Card */}
          <div
            className="rounded-xl p-5 relative overflow-hidden"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
          >
            <div className="absolute top-0 right-0 w-20 h-20 rounded-full blur-3xl pointer-events-none" style={{ backgroundColor: 'rgba(34,197,94,0.06)' }} />

            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-4">
                <Moon className="w-4 h-4" style={{ color: '#22C55E' }} />
                <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
                  {language === 'bn' ? 'আজকের আয়াত' : "Today's Ayah"}
                </span>
              </div>

              <div className="font-islamic text-[14px] leading-8 mb-4" style={{ color: 'var(--life-text)' }}>
                {ayahText}
              </div>

              <div className="text-[11px] font-medium" style={{ color: 'rgba(34,197,94,0.7)' }}>
                {ayahRef}
              </div>

              {/* Daily Score Mini */}
              <div
                className="mt-5 rounded-lg p-3 flex items-center gap-3"
                style={{ backgroundColor: 'var(--life-bg3)' }}
              >
                <ScoreRing score={score} size={56} />
                <div>
                  <div className="text-[12px] font-semibold" style={{ color: 'var(--life-text)' }}>
                    {getScoreMsg()}
                  </div>
                  <div className="text-[10px]" style={{ color: 'var(--life-text3)' }}>
                    {t('dash.score', language)}: {score}/100
                  </div>
                  <div className="flex items-center gap-1 mt-1">
                    <Flame className="w-3 h-3" style={{ color: '#F59E0B' }} />
                    <span className="text-[10px] font-medium" style={{ color: '#F59E0B' }}>
                      {streak} {language === 'bn' ? 'দিন স্ট্রিক' : 'day streak'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.section>

      {/* ===== 5. ANALYTICS SECTION ===== */}
      <motion.section variants={fadeInUp}>
        <div
          className="rounded-xl p-5"
          style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" style={{ color: 'var(--life-accent)' }} />
              <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
                {t('analytics.title', language)}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Weekly Score Bar Chart */}
            <div>
              <div className="text-[11px] font-medium mb-3" style={{ color: 'var(--life-text3)' }}>
                {t('analytics.weekly', language)}
              </div>
              <div className="h-[160px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis
                      dataKey="name"
                      tickLine={false}
                      axisLine={false}
                      tick={{ fontSize: 10, fill: '#888888' }}
                    />
                    <YAxis
                      tickLine={false}
                      axisLine={false}
                      tick={{ fontSize: 10, fill: '#888888' }}
                      domain={[0, 100]}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="score" fill="#FF6B35" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Life Heatmap */}
            <div>
              <div className="text-[11px] font-medium mb-3" style={{ color: 'var(--life-text3)' }}>
                {t('analytics.heatmap', language)}
              </div>
              <div className="flex gap-1.5 mb-2">
                {Array.from({ length: 4 }).map((_, weekIdx) => (
                  <div key={weekIdx} className="flex flex-col gap-1.5 flex-1">
                    {Array.from({ length: 7 }).map((_, dayIdx) => {
                      const dataIdx = weekIdx * 7 + dayIdx;
                      const cellScore = heatmapData[dataIdx] ?? 0;
                      return (
                        <motion.div
                          key={dayIdx}
                          className="heatmap-cell w-full aspect-square rounded-[3px]"
                          style={{ background: getHeatmapColor(cellScore) }}
                          title={`${cellScore}%`}
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: dataIdx * 0.01, duration: 0.2 }}
                        />
                      );
                    })}
                  </div>
                ))}
              </div>
              {/* Legend */}
              <div className="flex items-center gap-2 justify-end">
                <span className="text-[9px]" style={{ color: 'var(--life-text3)' }}>
                  {language === 'bn' ? 'কম' : 'Less'}
                </span>
                {[0, 0.2, 0.45, 0.8].map((opacity, i) => (
                  <div
                    key={i}
                    className="w-3 h-3 rounded-[2px]"
                    style={{ background: `rgba(255, 107, 53, ${opacity})` }}
                  />
                ))}
                <span className="text-[9px]" style={{ color: 'var(--life-text3)' }}>
                  {language === 'bn' ? 'বেশি' : 'More'}
                </span>
              </div>

              {/* Productivity Trend */}
              <div className="rounded-lg p-3 mt-3" style={{ backgroundColor: 'var(--life-bg3)' }}>
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" style={{ color: 'var(--life-accent)' }} />
                  <span className="text-[11px] font-medium" style={{ color: 'var(--life-text2)' }}>
                    {t('analytics.productivity', language)}
                  </span>
                </div>
                <p className="text-[11px] mt-1" style={{ color: 'var(--life-text3)' }}>
                  {score >= 70
                    ? language === 'bn'
                      ? 'উৎপাদনশীলতা বেশি! এই গতি বজায় রাখুন 🔥'
                      : 'Productivity is high! Keep this momentum going 🔥'
                    : score >= 40
                      ? language === 'bn'
                        ? 'মোটামুটি অগ্রগতি। আরেকটু চেষ্টা করুন 📈'
                        : 'Decent progress. Push a bit more for great results 📈'
                      : language === 'bn'
                        ? 'আজকে ধীরগতি, কাল নতুন করে শুরু করুন! 💪'
                        : 'Slow day today, start fresh tomorrow! 💪'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </motion.section>
    </motion.div>
  );
}
