'use client';

import { useLifeOSStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import { fadeInUpScale } from '@/lib/animations';
import { useState, useMemo } from 'react';
import { Brain, Sparkles, Heart, Smile, Sun, Trash2, Plus, BarChart3 } from 'lucide-react';

// ===== Constants =====
type MindsetType = 'affirmation' | 'gratitude' | 'reflection' | 'goal';

const ENTRY_TYPES: { key: MindsetType; labelKey: string; color: string; bg: string; border: string }[] = [
  { key: 'affirmation', labelKey: 'mindset.affirmation', color: 'text-purple-400', bg: 'bg-purple-500/15', border: 'border-purple-500/30' },
  { key: 'gratitude', labelKey: 'mindset.gratitude', color: 'text-green-400', bg: 'bg-green-500/15', border: 'border-green-500/30' },
  { key: 'reflection', labelKey: 'mindset.reflection', color: 'text-cyan-400', bg: 'bg-cyan-500/15', border: 'border-cyan-500/30' },
  { key: 'goal', labelKey: 'mindset.goal', color: 'text-amber-400', bg: 'bg-amber-500/15', border: 'border-amber-500/30' },
];

const MOOD_EMOJIS = ['', '😫', '😟', '😕', '😐', '🙂', '😊', '😄', '😃', '🌟', '🤩'];

const AFFIRMATIONS = [
  'I am capable of achieving extraordinary things.',
  'Every challenge is an opportunity for growth.',
  'I choose progress over perfection.',
  'My potential is limitless, and I act on it daily.',
  'I am resilient, strong, and unstoppable.',
  'Today I choose focus, discipline, and gratitude.',
  'I am becoming the best version of myself.',
  'I attract positivity and abundance into my life.',
  'My mind is clear, my heart is strong.',
  'I trust the process and keep moving forward.',
];

// Animation variants
const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.08 } },
};

export default function MindsetPage() {
  const { mindsetEntries, addMindsetEntry, deleteMindsetEntry, language } = useLifeOSStore();

  // Form state
  const [entryType, setEntryType] = useState<MindsetType>('affirmation');
  const [content, setContent] = useState('');
  const [mood, setMood] = useState(5);
  const [gratitude, setGratitude] = useState('');
  const [saving, setSaving] = useState(false);

  // Today's affirmation — deterministic based on day of year
  const todayAffirmation = useMemo(() => {
    const dayOfYear = Math.floor(
      (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000
    );
    return AFFIRMATIONS[dayOfYear % AFFIRMATIONS.length];
  }, []);

  // Last 7 entries for mood chart
  const last7Entries = useMemo(() => {
    return mindsetEntries.slice(0, 7).reverse();
  }, [mindsetEntries]);

  // Get type config
  const getTypeConfig = (type: string) => {
    return ENTRY_TYPES.find((et) => et.key === type) || ENTRY_TYPES[0];
  };

  // Get mood emoji
  const getMoodEmoji = (moodVal: number) => {
    return MOOD_EMOJIS[Math.min(Math.max(moodVal, 0), 10)] || '😐';
  };

  // Handle save
  const handleSave = async () => {
    if (!content.trim()) return;
    setSaving(true);
    try {
      const date = new Date().toISOString().split('T')[0];
      await addMindsetEntry(date, entryType, content.trim(), mood, gratitude.trim());
      setContent('');
      setGratitude('');
      setMood(5);
    } finally {
      setSaving(false);
    }
  };

  // Handle delete
  const handleDelete = async (id: string) => {
    await deleteMindsetEntry(id);
  };

  // Format date
  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <motion.div
      className="space-y-4 pb-4"
      variants={container}
      initial="hidden"
      animate="show"
    >
      {/* ===== Page Header ===== */}
      <motion.div variants={fadeInUpScale} className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}
        >
          <Brain className="w-5 h-5" />
        </div>
        <div>
          <h2 className="font-heading text-xl font-bold text-life-text">
            {t('mindset.title', language)}
          </h2>
          <p className="text-xs text-life-text3 mt-0.5 font-body">
            {t('mindset.subtitle', language)}
          </p>
        </div>
      </motion.div>

      {/* ===== Today's Affirmation Card ===== */}
      <motion.div
        variants={fadeInUpScale}
        className="rounded-xl p-5 relative overflow-hidden"
        style={{
          backgroundColor: 'rgba(34,197,94,0.08)',
          border: '1px solid rgba(34,197,94,0.15)',
        }}
      >
        {/* Soft glow effect */}
        <div
          className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl pointer-events-none"
          style={{ backgroundColor: 'rgba(34,197,94,0.12)' }}
        />
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-green-400" />
            <span className="font-heading text-xs font-semibold text-green-400 uppercase tracking-wider">
              {t('mindset.todayAffirmation', language)}
            </span>
          </div>
          <p
            className="text-base sm:text-lg font-body leading-relaxed italic"
            style={{ color: 'var(--life-text)' }}
          >
            &ldquo;{todayAffirmation}&rdquo;
          </p>
        </div>
      </motion.div>

      {/* ===== Add Entry Form ===== */}
      <motion.div
        variants={fadeInUpScale}
        className="rounded-xl p-4"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        {/* Type Selector — Pill Buttons */}
        <div className="mb-4">
          <div className="font-heading text-xs font-semibold text-life-text3 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
            <Sun className="w-3.5 h-3.5" />
            {t('mindset.type', language)}
          </div>
          <div className="flex flex-wrap gap-2">
            {ENTRY_TYPES.map((type) => (
              <button
                key={type.key}
                onClick={() => setEntryType(type.key)}
                className={`
                  px-3 py-1.5 rounded-full text-xs font-semibold font-heading
                  transition-all duration-200 border
                  ${entryType === type.key
                    ? `${type.bg} ${type.color} ${type.border}`
                    : 'bg-life-bg3 text-life-text3 border-life-border hover:border-life-border2'
                  }
                `}
              >
                {t(type.labelKey, language)}
              </button>
            ))}
          </div>
        </div>

        {/* Content Textarea */}
        <div className="mb-4">
          <div className="font-heading text-xs font-semibold text-life-text3 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Brain className="w-3.5 h-3.5" />
            {t('mindset.addEntry', language)}
          </div>
          <textarea
            className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary resize-y min-h-[80px] leading-relaxed font-body placeholder:text-life-text3"
            placeholder={t('mindset.content', language)}
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
        </div>

        {/* Mood Slider */}
        <div className="mb-4">
          <div className="font-heading text-xs font-semibold text-life-text3 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Smile className="w-3.5 h-3.5" />
            {t('mindset.mood', language)}
          </div>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <input
                type="range"
                min={1}
                max={10}
                value={mood}
                onChange={(e) => setMood(parseInt(e.target.value))}
                className="w-full h-2 rounded-full appearance-none cursor-pointer"
                style={{
                  background: 'linear-gradient(to right, #EF4444, #F59E0B, #22C55E, #7C3AED)',
                }}
              />
              <div className="flex justify-between mt-1">
                <span className="text-[10px] text-life-text3">1</span>
                <span className="text-[10px] text-life-text3">5</span>
                <span className="text-[10px] text-life-text3">10</span>
              </div>
            </div>
            <div className="flex flex-col items-center gap-0.5 min-w-[48px]">
              <span className="text-2xl">{getMoodEmoji(mood)}</span>
              <span
                className="text-sm font-bold font-heading"
                style={{ color: 'var(--life-accent)' }}
              >
                {mood}
              </span>
            </div>
          </div>
        </div>

        {/* Gratitude Input */}
        <div className="mb-4">
          <div className="font-heading text-xs font-semibold text-life-text3 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Heart className="w-3.5 h-3.5 text-green-400" />
            {t('mindset.gratitudePrompt', language)}
          </div>
          <input
            className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary font-body placeholder:text-life-text3"
            placeholder={t('mindset.gratitudePrompt', language)}
            value={gratitude}
            onChange={(e) => setGratitude(e.target.value)}
          />
        </div>

        {/* Save Button */}
        <motion.button
          onClick={handleSave}
          disabled={!content.trim() || saving}
          className={`
            w-full py-3 rounded-xl text-sm font-semibold font-heading
            flex items-center justify-center gap-2 transition-all duration-200
            ${content.trim() && !saving
              ? 'text-white hover:opacity-90'
              : 'bg-life-bg3 text-life-text3 cursor-not-allowed'
            }
          `}
          style={
            content.trim() && !saving
              ? { backgroundColor: 'var(--life-accent)' }
              : undefined
          }
          whileHover={content.trim() && !saving ? { scale: 1.01 } : undefined}
          whileTap={content.trim() && !saving ? { scale: 0.98 } : undefined}
        >
          <Plus className="w-4 h-4" />
          {saving ? t('common.loading', language) : t('mindset.save', language)}
        </motion.button>
      </motion.div>

      {/* ===== Daily Mood Chart ===== */}
      {last7Entries.length > 0 && (
        <motion.div
          variants={fadeInUpScale}
          className="rounded-xl p-4"
          style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
        >
          <div className="font-heading text-xs font-semibold text-life-text3 uppercase tracking-wider mb-3 flex items-center gap-1.5">
            <BarChart3 className="w-3.5 h-3.5" />
            {t('analytics.mood', language)}
          </div>
          <div className="flex items-end gap-2 h-20">
            {last7Entries.map((entry, i) => {
              const barHeight = Math.max((entry.mood / 10) * 100, 8);
              const typeConfig = getTypeConfig(entry.type);
              return (
                <div key={entry.id || i} className="flex-1 flex flex-col items-center gap-1">
                  <div className="w-full relative flex justify-center" style={{ height: '60px' }}>
                    <motion.div
                      className={`w-full max-w-[28px] rounded-t-md ${typeConfig.bg}`}
                      initial={{ height: 0 }}
                      animate={{ height: `${barHeight}%` }}
                      transition={{ delay: i * 0.06, duration: 0.4, ease: 'easeOut' }}
                      style={{ position: 'absolute', bottom: 0 }}
                    />
                  </div>
                  <span className="text-[9px] text-life-text3">{entry.mood}</span>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}

      {/* ===== Entry List ===== */}
      {mindsetEntries.length === 0 ? (
        <motion.div
          variants={fadeInUpScale}
          className="rounded-xl p-6 text-center"
          style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
        >
          <Sparkles className="w-8 h-8 mx-auto text-life-text3 mb-2 opacity-50" />
          <p className="text-sm text-life-text3 font-body">
            {t('mindset.noEntries', language)}
          </p>
        </motion.div>
      ) : (
        <div className="space-y-3">
          {mindsetEntries.map((entry) => {
            const typeConfig = getTypeConfig(entry.type);
            return (
              <motion.div
                key={entry.id}
                variants={fadeInUpScale}
                className="rounded-xl p-4 relative overflow-hidden group"
                style={{
                  backgroundColor: 'var(--life-bg2)',
                  border: '1px solid var(--life-border)',
                }}
                whileHover={{ scale: 1.005 }}
                transition={{ duration: 0.15 }}
              >
                {/* Subtle glow for entry type */}
                <div
                  className="absolute top-0 right-0 w-16 h-16 rounded-full blur-2xl pointer-events-none opacity-40"
                  style={{
                    backgroundColor:
                      entry.type === 'affirmation'
                        ? 'rgba(124,58,237,0.15)'
                        : entry.type === 'gratitude'
                          ? 'rgba(34,197,94,0.15)'
                          : entry.type === 'reflection'
                            ? 'rgba(6,182,212,0.15)'
                            : 'rgba(245,158,11,0.15)',
                  }}
                />

                <div className="relative z-10">
                  {/* Top row: type badge + date + delete */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {/* Type badge */}
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-semibold font-heading ${typeConfig.bg} ${typeConfig.color} ${typeConfig.border} border`}
                      >
                        {t(typeConfig.labelKey, language)}
                      </span>
                      {/* Mood emoji */}
                      <span className="text-sm">{getMoodEmoji(entry.mood)}</span>
                      <span
                        className="text-[10px] font-bold font-heading"
                        style={{ color: 'var(--life-accent)' }}
                      >
                        {entry.mood}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {/* Date */}
                      <span className="text-[10px] text-life-text3 font-body">
                        {formatDate(entry.date)}
                      </span>
                      {/* Delete button */}
                      <motion.button
                        onClick={() => handleDelete(entry.id)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center
                          bg-life-bg3 border border-life-border text-life-text3
                          hover:text-red-400 hover:border-red-400/30 hover:bg-red-500/10
                          transition-all duration-200 opacity-0 group-hover:opacity-100"
                        whileTap={{ scale: 0.9 }}
                      >
                        <Trash2 className="w-3 h-3" />
                      </motion.button>
                    </div>
                  </div>

                  {/* Content */}
                  <p className="text-sm text-life-text2 font-body leading-relaxed">
                    {entry.content}
                  </p>

                  {/* Gratitude (if present) */}
                  {entry.gratitude && (
                    <div className="mt-2 flex items-start gap-1.5">
                      <Heart className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
                      <span className="text-xs text-life-text3 font-body italic">
                        {entry.gratitude}
                      </span>
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
