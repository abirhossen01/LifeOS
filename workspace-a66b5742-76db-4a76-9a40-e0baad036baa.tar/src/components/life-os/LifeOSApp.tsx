'use client';

import { useLifeOSStore, TabPage } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion, AnimatePresence } from 'framer-motion';
import DashboardPage from './DashboardPage';
import PrayerPage from './PrayerPage';
import TodoPage from './TodoPage';
import ExpensePage from './ExpensePage';
import JournalPage from './JournalPage';
import FitnessPage from './FitnessPage';
import SkillsPage from './SkillsPage';
import GoalsPage from './GoalsPage';
import ReviewPage from './ReviewPage';
import SettingsPage from './SettingsPage';
import BooksPage from './BooksPage';
import MindsetPage from './MindsetPage';
import CalendarPage from './CalendarPage';
import ProfilePage from './ProfilePage';
import AuthPage from './AuthPage';
import { useEffect, useMemo, useState } from 'react';
import Image from 'next/image';
import {
  Home, Target, BookOpen, Moon, Settings,
  ListTodo, Wallet, Dumbbell, GraduationCap,
  BarChart3, LogOut, ChevronLeft, ChevronRight,
  Flame, Zap, Church, Brain, Calendar, User,
  Cloud, CloudOff, RefreshCw
} from 'lucide-react';
import { isSupabaseConfigured, supabaseGetSession, supabaseOnAuthStateChange } from '@/lib/supabase';

// ===== Sidebar Nav Items =====
const SIDEBAR_ITEMS: { id: TabPage; icon: React.ReactNode; labelKey: string }[] = [
  { id: 'dashboard', icon: <Home className="w-5 h-5" />, labelKey: 'nav.home' },
  { id: 'namaz', icon: <Church className="w-5 h-5" />, labelKey: 'nav.namaz' },
  { id: 'todo', icon: <ListTodo className="w-5 h-5" />, labelKey: 'nav.todo' },
  { id: 'books', icon: <BookOpen className="w-5 h-5" />, labelKey: 'nav.books' },
  { id: 'mindset', icon: <Brain className="w-5 h-5" />, labelKey: 'nav.mindset' },
  { id: 'calendar', icon: <Calendar className="w-5 h-5" />, labelKey: 'nav.calendar' },
  { id: 'journal', icon: <BookOpen className="w-5 h-5" />, labelKey: 'nav.journal' },
  { id: 'fitness', icon: <Dumbbell className="w-5 h-5" />, labelKey: 'nav.fitness' },
  { id: 'skills', icon: <GraduationCap className="w-5 h-5" />, labelKey: 'nav.skills' },
  { id: 'goals', icon: <Target className="w-5 h-5" />, labelKey: 'nav.goals' },
  { id: 'expense', icon: <Wallet className="w-5 h-5" />, labelKey: 'nav.expense' },
  { id: 'review', icon: <BarChart3 className="w-5 h-5" />, labelKey: 'nav.review' },
];

// ===== Bottom Nav Items (5 main — mobile) =====
const BOTTOM_NAV_ITEMS: { id: TabPage; icon: React.ReactNode; labelKey: string }[] = [
  { id: 'dashboard', icon: <Home className="w-5 h-5" />, labelKey: 'nav.home' },
  { id: 'books', icon: <BookOpen className="w-5 h-5" />, labelKey: 'nav.books' },
  { id: 'calendar', icon: <Calendar className="w-5 h-5" />, labelKey: 'nav.calendar' },
  { id: 'namaz', icon: <Moon className="w-5 h-5" />, labelKey: 'nav.namaz' },
  { id: 'profile', icon: <User className="w-5 h-5" />, labelKey: 'nav.profile' },
];

// ===== Date helpers =====
const DAYS_BN = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];
const DAYS_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS_BN = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
const MONTHS_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// ===== Page Transition Variants =====
const pageVariants = {
  initial: { opacity: 0, y: 8 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -4 },
};

const pageTransition = {
  type: 'spring' as const,
  stiffness: 300,
  damping: 30,
  mass: 0.8,
};

// ===== Main App Component =====
export default function LifeOSApp() {
  const {
    activeTab,
    setActiveTab,
    loadDailyLog,
    loadSettings,
    loadCustomSkills,
    dailyLog,
    loading,
    theme,
    fontSize,
    language,
    setLanguage,
    setVideoIdeas,
    xp,
    level,
    supabaseUser,
    setSupabaseUser,
    isAuthenticated,
    isSyncing,
    syncToCloud,
    lastSyncAt,
    initialDataLoaded,
  } = useLifeOSStore();

  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Supabase auth initialization
  useEffect(() => {
    if (!isSupabaseConfigured()) return;
    let unsub = () => {};
    const init = async () => {
      const session = await supabaseGetSession();
      if (session?.user) {
        setSupabaseUser({ id: session.user.id, email: session.user.email || '', name: session.user.user_metadata?.name, avatar_url: session.user.user_metadata?.avatar_url });
      }
      const result = await supabaseOnAuthStateChange((event, s) => {
        if (event === 'SIGNED_IN' && s && 'user' in s) {
          const user = s.user;
          const meta = (user.user_metadata || {}) as Record<string, unknown>;
          setSupabaseUser({ id: user.id, email: user.email || '', name: meta.name ? String(meta.name) : undefined, avatar_url: meta.avatar_url ? String(meta.avatar_url) : undefined });
        } else if (event === 'SIGNED_OUT') { setSupabaseUser(null); }
      });
      unsub = result.unsubscribe;
    };
    init();
    return () => { unsub(); };
  }, [setSupabaseUser]);

  // Auto-sync every 5 minutes when authenticated
  useEffect(() => {
    if (!isAuthenticated) return;
    const interval = setInterval(() => {
      syncToCloud();
    }, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [isAuthenticated, syncToCloud]);

  // Load data on mount
  useEffect(() => {
    loadDailyLog();
    loadSettings();
    loadCustomSkills();
    fetch('/api/video-ideas')
      .then(res => res.ok ? res.json() : [])
      .then(data => setVideoIdeas(data))
      .catch(() => {});
  }, [loadDailyLog, loadSettings, loadCustomSkills, setVideoIdeas]);

  // Date string
  const dateStr = useMemo(() => {
    const today = new Date();
    const DAYS = language === 'bn' ? DAYS_BN : DAYS_EN;
    const MONTHS = language === 'bn' ? MONTHS_BN : MONTHS_EN;
    return `${DAYS[today.getDay()]}, ${today.getDate()} ${MONTHS[today.getMonth()]} ${today.getFullYear()}`;
  }, [language]);

  // Map activeTab to bottom nav for highlighting
  const bottomNavActiveTab = useMemo((): TabPage => {
    if (BOTTOM_NAV_ITEMS.some(item => item.id === activeTab)) {
      return activeTab;
    }
    return activeTab;
  }, [activeTab]);

  // Render the active page content
  const renderPage = () => {
    switch (activeTab) {
      case 'dashboard': return <DashboardPage />;
      case 'namaz': return <PrayerPage />;
      case 'todo': return <TodoPage />;
      case 'expense': return <ExpensePage />;
      case 'journal': return <JournalPage />;
      case 'fitness': return <FitnessPage />;
      case 'skills': return <SkillsPage />;
      case 'goals': return <GoalsPage />;
      case 'review': return <ReviewPage />;
      case 'settings': return <SettingsPage />;
      case 'books': return <BooksPage />;
      case 'mindset': return <MindsetPage />;
      case 'calendar': return <CalendarPage />;
      case 'profile': return <ProfilePage />;
      case 'auth': return <AuthPage />;
      default: return <DashboardPage />;
    }
  };

  // Get page title for breadcrumb
  const getPageTitle = () => {
    if (activeTab === 'dashboard') return language === 'bn' ? 'প্রধান ড্যাশবোর্ড' : 'Main Dashboard';
    if (activeTab === 'auth') return t('auth.cloudSync', language);
    return t(`nav.${activeTab === 'namaz' ? 'namaz' : activeTab}`, language);
  };

  const xpInLevel = xp % 100;

  return (
    <div
      className="min-h-screen flex relative overflow-hidden"
      data-theme={theme}
      data-font-size={fontSize}
      style={{ backgroundColor: 'var(--life-bg)', color: 'var(--life-text)' }}
    >
      {/* ===== LEFT SIDEBAR (Desktop only) ===== */}
      <aside
        className={`hidden lg:flex flex-col border-r transition-all duration-300 ease-out relative z-40`}
        style={{
          width: sidebarCollapsed ? '72px' : '220px',
          backgroundColor: 'var(--life-bg2)',
          borderColor: 'var(--life-border)',
        }}
      >
        {/* Logo Section */}
        <div
          className="flex items-center gap-3 px-4 py-5 border-b"
          style={{ borderColor: 'var(--life-border)' }}
        >
          <div className="w-9 h-9 rounded-lg overflow-hidden flex-shrink-0" style={{ boxShadow: '0 0 12px rgba(255,107,53,0.2)' }}>
            <Image
              src="/life-os-logo.png"
              alt="Life OS"
              width={36}
              height={36}
              className="w-full h-full object-cover"
              priority
            />
          </div>
          {!sidebarCollapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.2 }}
            >
              <h1 className="font-heading text-[15px] font-bold" style={{ color: 'var(--life-accent)' }}>
                Life OS
              </h1>
              <p className="text-[9px]" style={{ color: 'var(--life-text3)' }}>
                {t('app.tagline', language)}
              </p>
            </motion.div>
          )}
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 py-4 px-2 space-y-1 life-scrollbar overflow-y-auto">
          {SIDEBAR_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`
                  w-full flex items-center gap-3 rounded-lg transition-all duration-200
                  ${sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'px-3 py-2.5'}
                  ${isActive
                    ? 'text-white'
                    : 'hover:bg-white/5'
                  }
                `}
                style={{
                  backgroundColor: isActive ? 'var(--life-accent)' : 'transparent',
                  color: isActive ? '#FFFFFF' : 'var(--life-text2)',
                }}
                aria-label={t(item.labelKey, language)}
                aria-current={isActive ? 'page' : undefined}
              >
                <span className={`flex-shrink-0 ${isActive ? 'text-white' : ''}`} style={{ color: isActive ? '#FFFFFF' : 'var(--life-text2)' }}>
                  {item.icon}
                </span>
                {!sidebarCollapsed && (
                  <span className={`text-[13px] font-medium truncate ${isActive ? 'text-white' : ''}`} style={{ color: isActive ? '#FFFFFF' : 'var(--life-text2)' }}>
                    {t(item.labelKey, language)}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom Section: Cloud Sync + Profile + Settings + Collapse */}
        <div className="border-t px-2 py-3 space-y-1" style={{ borderColor: 'var(--life-border)' }}>
          {/* Cloud Sync Button */}
          <button
            onClick={() => setActiveTab('auth')}
            className={`
              w-full flex items-center gap-3 rounded-lg transition-all duration-200
              ${sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'px-3 py-2.5'}
              ${activeTab === 'auth' ? '' : 'hover:bg-white/5'}
            `}
            style={{
              backgroundColor: activeTab === 'auth' ? 'var(--life-accent)' : 'transparent',
              color: activeTab === 'auth' ? '#FFFFFF' : 'var(--life-text2)',
            }}
          >
            {isAuthenticated ? (
              <Cloud className="w-5 h-5 flex-shrink-0" style={{ color: activeTab === 'auth' ? '#FFFFFF' : '#22C55E' }} />
            ) : (
              <CloudOff className="w-5 h-5 flex-shrink-0" />
            )}
            {!sidebarCollapsed && (
              <span className="text-[13px] font-medium">{t('auth.cloudSync', language)}</span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('profile')}
            className={`
              w-full flex items-center gap-3 rounded-lg transition-all duration-200
              ${sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'px-3 py-2.5'}
              ${activeTab === 'profile' ? '' : 'hover:bg-white/5'}
            `}
            style={{
              backgroundColor: activeTab === 'profile' ? 'var(--life-accent)' : 'transparent',
              color: activeTab === 'profile' ? '#FFFFFF' : 'var(--life-text2)',
            }}
          >
            <User className="w-5 h-5 flex-shrink-0" />
            {!sidebarCollapsed && (
              <span className="text-[13px] font-medium">{t('nav.profile', language)}</span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`
              w-full flex items-center gap-3 rounded-lg transition-all duration-200
              ${sidebarCollapsed ? 'justify-center px-2 py-2.5' : 'px-3 py-2.5'}
              ${activeTab === 'settings' ? '' : 'hover:bg-white/5'}
            `}
            style={{
              backgroundColor: activeTab === 'settings' ? 'var(--life-accent)' : 'transparent',
              color: activeTab === 'settings' ? '#FFFFFF' : 'var(--life-text2)',
            }}
          >
            <Settings className="w-5 h-5 flex-shrink-0" />
            {!sidebarCollapsed && (
              <span className="text-[13px] font-medium">{t('nav.settings', language)}</span>
            )}
          </button>

          {/* Collapse toggle */}
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="w-full flex items-center justify-center gap-2 rounded-lg px-3 py-2 transition-all duration-200 hover:bg-white/5"
            style={{ color: 'var(--life-text3)' }}
          >
            {sidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            {!sidebarCollapsed && <span className="text-[11px]">{language === 'bn' ? 'সংকুচিত' : 'Collapse'}</span>}
          </button>
        </div>
      </aside>

      {/* ===== MAIN CONTENT AREA ===== */}
      <div className="flex-1 flex flex-col min-h-screen relative">
        {/* ===== TOP NAVBAR ===== */}
        <header
          className="sticky top-0 z-50 px-4 sm:px-6 py-3 flex items-center justify-between border-b"
          style={{
            backgroundColor: 'var(--life-bg2)',
            borderColor: 'var(--life-border)',
          }}
        >
          {/* Left: Breadcrumb */}
          <div className="flex items-center gap-2">
            <span className="text-[12px]" style={{ color: 'var(--life-text3)' }}>
              {language === 'bn' ? 'পৃষ্ঠা' : 'Pages'}
            </span>
            <span className="text-[12px]" style={{ color: 'var(--life-text3)' }}>/</span>
            <span className="text-[13px] font-medium" style={{ color: 'var(--life-text)' }}>
              {getPageTitle()}
            </span>
          </div>

          {/* Right: Sync + Streak + XP + Lang Toggle + Date */}
          <div className="flex items-center gap-3">
            {/* Sync Indicator */}
            {isAuthenticated ? (
              <button
                onClick={() => syncToCloud()}
                disabled={isSyncing}
                className="flex items-center gap-1.5 rounded-full px-2.5 py-1 transition-all duration-200"
                style={{ backgroundColor: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.2)' }}
                aria-label={t('auth.syncNow', language)}
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} style={{ color: '#22C55E' }} />
                <span className="text-[10px] font-medium" style={{ color: '#22C55E' }}>{isSyncing ? t('auth.syncing', language) : t('auth.connected', language)}</span>
              </button>
            ) : isSupabaseConfigured() ? (
              <button
                onClick={() => setActiveTab('auth')}
                className="flex items-center gap-1.5 rounded-full px-2.5 py-1 transition-all duration-200"
                style={{ backgroundColor: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.2)' }}
                aria-label={t('auth.offlineMode', language)}
              >
                <CloudOff className="w-3.5 h-3.5" style={{ color: '#F59E0B' }} />
                <span className="text-[10px] font-medium" style={{ color: '#F59E0B' }}>{t('auth.offlineMode', language)}</span>
              </button>
            ) : null}
            {/* Streak */}
            <div className="flex items-center gap-1.5 rounded-full px-2.5 py-1" style={{ backgroundColor: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.2)' }}>
              <Flame className="w-3.5 h-3.5" style={{ color: '#F59E0B' }} />
              <span className="text-xs font-bold" style={{ color: '#F59E0B' }}>{dailyLog?.streak || 0}</span>
            </div>

            {/* XP Level */}
            <div className="hidden sm:flex items-center gap-1.5 rounded-full px-2.5 py-1" style={{ backgroundColor: 'rgba(255,107,53,0.1)', border: '1px solid rgba(255,107,53,0.2)' }}>
              <div className="w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold text-white" style={{ background: 'linear-gradient(135deg, var(--life-accent), var(--life-secondary))' }}>
                {level}
              </div>
              <span className="text-[10px] font-medium" style={{ color: 'var(--life-accent)' }}>{xpInLevel}/100 XP</span>
            </div>

            {/* Language Toggle */}
            <button
              onClick={() => setLanguage(language === 'bn' ? 'en' : 'bn')}
              className="flex items-center gap-0.5 rounded-full px-2 py-1 transition-colors duration-200 touch-target"
              style={{ backgroundColor: 'var(--life-bg3)', border: '1px solid var(--life-border)' }}
              aria-label="Toggle language"
            >
              <span className={`text-[10px] font-bold ${language === 'bn' ? '' : ''}`} style={{ color: language === 'bn' ? 'var(--life-accent)' : 'var(--life-text3)' }}>BD</span>
              <span className="text-[8px]" style={{ color: 'var(--life-text3)' }}>/</span>
              <span className={`text-[10px] font-bold`} style={{ color: language === 'en' ? 'var(--life-accent)' : 'var(--life-text3)' }}>EN</span>
            </button>

            {/* Date */}
            <div className="hidden md:block text-[11px]" style={{ color: 'var(--life-text3)' }}>
              {dateStr}
            </div>
          </div>
        </header>

        {/* ===== CONTENT ===== */}
        <main className="flex-1 overflow-y-auto life-scrollbar relative z-10" style={{ paddingBottom: 'calc(5rem + env(safe-area-inset-bottom, 0px))' }}>
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              variants={pageVariants}
              initial="initial"
              animate="animate"
              exit="exit"
              transition={pageTransition}
              className="p-4 sm:p-5 md:p-6"
            >
              {!initialDataLoaded && loading ? (
                <div className="flex flex-col items-center justify-center py-24 gap-3">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full border-2 border-white/10 border-t-[var(--life-accent)] animate-spin" />
                  </div>
                  <p className="text-sm" style={{ color: 'var(--life-text3)' }}>{t('common.loading', language)}</p>
                </div>
              ) : (
                renderPage()
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* ===== BOTTOM NAVIGATION (Mobile only) ===== */}
      <nav
        className="lg:hidden fixed bottom-0 left-0 right-0 z-50 border-t"
        style={{
          backgroundColor: 'var(--life-bg2)',
          borderColor: 'var(--life-border)',
          paddingBottom: 'max(8px, env(safe-area-inset-bottom))',
        }}
      >
        <div className="flex items-center justify-around px-2 pt-2 pb-1">
          {BOTTOM_NAV_ITEMS.map((item) => {
            const isActive = bottomNavActiveTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`
                  relative flex flex-col items-center justify-center gap-0.5 py-1.5 px-3 rounded-xl
                  transition-all duration-200 touch-target
                  ${isActive ? 'scale-105' : 'hover:scale-102'}
                `}
                aria-label={t(item.labelKey, language)}
                aria-current={isActive ? 'page' : undefined}
              >
                {/* Active indicator */}
                {isActive && (
                  <motion.div
                    layoutId="mobileNavIndicator"
                    className="absolute inset-0 rounded-xl"
                    style={{ backgroundColor: 'var(--life-accent)' }}
                    transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                  />
                )}

                {/* Icon */}
                <span className={`relative z-10 transition-all duration-200 ${isActive ? 'text-white' : ''}`} style={{ color: isActive ? '#FFFFFF' : 'var(--life-text3)' }}>
                  {item.icon}
                </span>

                {/* Label */}
                <span
                  className={`relative z-10 text-[9px] sm:text-[10px] whitespace-nowrap font-medium transition-colors duration-200`}
                  style={{ color: isActive ? '#FFFFFF' : 'var(--life-text3)' }}
                >
                  {t(item.labelKey, language)}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
