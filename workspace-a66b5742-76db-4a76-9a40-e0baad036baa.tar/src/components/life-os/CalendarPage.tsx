'use client';

import { useLifeOSStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { fadeInUp, staggerContainer } from '@/lib/animations';
import {
  Calendar,
  Plus,
  Clock,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Check,
  Tag,
  Repeat,
  CalendarDays,
} from 'lucide-react';

// ===== Animation Variants =====
const fadeIn = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0 },
};

// ===== Category Config =====
const EVENT_CATEGORIES = [
  { value: 'personal', labelKey: 'calendar.personal', color: '#F59E0B' },
  { value: 'work', labelKey: 'calendar.work', color: '#7C3AED' },
  { value: 'study', labelKey: 'calendar.study', color: '#06B6D4' },
  { value: 'fitness', labelKey: 'calendar.fitness', color: '#22C55E' },
  { value: 'spiritual', labelKey: 'calendar.spiritual', color: '#EC4899' },
] as const;

const RECURRING_OPTIONS = [
  { value: 'none', labelKey: 'calendar.none' },
  { value: 'daily', labelKey: 'calendar.daily' },
  { value: 'weekly', labelKey: 'calendar.weekly' },
  { value: 'monthly', labelKey: 'calendar.monthly' },
] as const;

// ===== Day names (Sat-start for Islamic calendar preference) =====
const DAY_NAMES_EN = ['Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
const DAY_NAMES_BN = ['শনি', 'রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র'];

const MONTH_NAMES_EN = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];
const MONTH_NAMES_BN = [
  'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
  'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর',
];

function getCategoryInfo(category: string) {
  return EVENT_CATEGORIES.find(c => c.value === category) || EVENT_CATEGORIES[0];
}

function formatDateStr(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

// ===== Calendar Grid Logic =====
function getCalendarDays(year: number, month: number) {
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();

  // getDay() returns 0=Sun, 1=Mon, ..., 6=Sat
  // We want Sat=0, Sun=1, ..., Fri=6
  let startDow = firstDay.getDay(); // 0=Sun
  const satBasedDow = (startDow + 1) % 7; // Sat=0, Sun=1, ..., Fri=6

  const prevMonthLastDay = new Date(year, month, 0).getDate();

  const days: { date: number; month: 'prev' | 'current' | 'next'; fullDate: string }[] = [];

  // Previous month filler
  for (let i = satBasedDow - 1; i >= 0; i--) {
    const d = prevMonthLastDay - i;
    const pm = month === 0 ? 11 : month - 1;
    const py = month === 0 ? year - 1 : year;
    days.push({
      date: d,
      month: 'prev',
      fullDate: formatDateStr(new Date(py, pm, d)),
    });
  }

  // Current month
  for (let d = 1; d <= daysInMonth; d++) {
    days.push({
      date: d,
      month: 'current',
      fullDate: formatDateStr(new Date(year, month, d)),
    });
  }

  // Next month filler (fill to complete the last row)
  const remaining = 7 - (days.length % 7);
  if (remaining < 7) {
    for (let d = 1; d <= remaining; d++) {
      const nm = month === 11 ? 0 : month + 1;
      const ny = month === 11 ? year + 1 : year;
      days.push({
        date: d,
        month: 'next',
        fullDate: formatDateStr(new Date(ny, nm, d)),
      });
    }
  }

  return days;
}

export default function CalendarPage() {
  const {
    calendarEvents,
    addCalendarEvent,
    toggleCalendarEvent,
    deleteCalendarEvent,
    language,
  } = useLifeOSStore();

  const today = useMemo(() => new Date(), []);
  const todayStr = useMemo(() => formatDateStr(today), [today]);

  const [currentYear, setCurrentYear] = useState(today.getFullYear());
  const [currentMonth, setCurrentMonth] = useState(today.getMonth());
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);

  // Form state
  const [showForm, setShowForm] = useState(false);
  const [formTitle, setFormTitle] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formTime, setFormTime] = useState('09:00');
  const [formEndTime, setFormEndTime] = useState('10:00');
  const [formCategory, setFormCategory] = useState<string>('personal');
  const [formRecurring, setFormRecurring] = useState<string>('none');

  // ===== Computed =====
  const calendarDays = useMemo(
    () => getCalendarDays(currentYear, currentMonth),
    [currentYear, currentMonth],
  );

  const eventDateSet = useMemo(() => {
    const set = new Set<string>();
    calendarEvents.forEach(e => set.add(e.date));
    return set;
  }, [calendarEvents]);

  const selectedDayEvents = useMemo(
    () => calendarEvents
      .filter(e => e.date === selectedDate)
      .sort((a, b) => (a.time || '').localeCompare(b.time || '')),
    [calendarEvents, selectedDate],
  );

  const todayEvents = useMemo(
    () => calendarEvents.filter(e => e.date === todayStr),
    [calendarEvents, todayStr],
  );

  const monthNames = language === 'bn' ? MONTH_NAMES_BN : MONTH_NAMES_EN;
  const dayNames = language === 'bn' ? DAY_NAMES_BN : DAY_NAMES_EN;

  // ===== Handlers =====
  const goToPrevMonth = useCallback(() => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(y => y - 1);
    } else {
      setCurrentMonth(m => m - 1);
    }
  }, [currentMonth]);

  const goToNextMonth = useCallback(() => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(y => y + 1);
    } else {
      setCurrentMonth(m => m + 1);
    }
  }, [currentMonth]);

  const goToToday = useCallback(() => {
    setCurrentYear(today.getFullYear());
    setCurrentMonth(today.getMonth());
    setSelectedDate(todayStr);
  }, [today, todayStr]);

  const handleDayClick = useCallback((dateStr: string) => {
    setSelectedDate(dateStr);
  }, []);

  const handleAddEvent = useCallback(async () => {
    if (!formTitle.trim()) return;
    await addCalendarEvent(
      formTitle.trim(),
      formDescription.trim(),
      selectedDate,
      formTime,
      formEndTime,
      formCategory,
      formRecurring,
    );
    setFormTitle('');
    setFormDescription('');
    setFormTime('09:00');
    setFormEndTime('10:00');
    setFormCategory('personal');
    setFormRecurring('none');
    setShowForm(false);
  }, [formTitle, formDescription, selectedDate, formTime, formEndTime, formCategory, formRecurring, addCalendarEvent]);

  const formatDisplayDate = useCallback((dateStr: string) => {
    const d = new Date(dateStr + 'T00:00:00');
    const dayNum = d.getDate();
    const monthName = monthNames[d.getMonth()];
    const yearNum = d.getFullYear();
    return language === 'bn'
      ? `${dayNum} ${monthName}, ${yearNum}`
      : `${monthName} ${dayNum}, ${yearNum}`;
  }, [language, monthNames]);

  return (
    <motion.div
      className="space-y-5 pb-4"
      variants={staggerContainer}
      initial="hidden"
      animate="show"
    >
      {/* ===== Page Header ===== */}
      <motion.div variants={fadeInUp} className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}
          >
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-heading text-xl font-bold text-life-text">
              {t('calendar.title', language)}
            </h1>
            <p className="text-xs text-life-text3">{t('calendar.subtitle', language)}</p>
          </div>
        </div>

        {/* Today's Overview */}
        <motion.div
          variants={fadeIn}
          className="rounded-xl px-3 py-2 flex items-center gap-2"
          style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
        >
          <CalendarDays className="w-4 h-4" style={{ color: 'var(--life-accent)' }} />
          <div className="text-right">
            <div className="text-[10px] text-life-text3 uppercase tracking-wide">
              {t('calendar.today', language)}
            </div>
            <div className="text-sm font-bold" style={{ color: 'var(--life-accent)' }}>
              {todayEvents.length} {language === 'bn' ? 'ইভেন্ট' : 'events'}
            </div>
          </div>
        </motion.div>
      </motion.div>

      {/* ===== Calendar Card ===== */}
      <motion.div
        variants={fadeInUp}
        className="rounded-xl p-4 relative overflow-hidden"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl pointer-events-none opacity-30" style={{ background: 'var(--life-accent)' }} />

        <div className="relative z-10">
          {/* Month Navigation */}
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={goToPrevMonth}
              className="w-9 h-9 rounded-lg flex items-center justify-center transition-all hover:scale-105 active:scale-95"
              style={{ backgroundColor: 'var(--life-bg3)' }}
            >
              <ChevronLeft className="w-5 h-5 text-life-text2" />
            </button>

            <button
              onClick={goToToday}
              className="flex items-center gap-2 group"
            >
              <span className="font-heading text-lg font-bold text-life-text group-hover:underline underline-offset-4 transition-all" style={{ textDecorationColor: 'var(--life-accent)' }}>
                {monthNames[currentMonth]} {currentYear}
              </span>
            </button>

            <button
              onClick={goToNextMonth}
              className="w-9 h-9 rounded-lg flex items-center justify-center transition-all hover:scale-105 active:scale-95"
              style={{ backgroundColor: 'var(--life-bg3)' }}
            >
              <ChevronRight className="w-5 h-5 text-life-text2" />
            </button>
          </div>

          {/* Day Headers */}
          <div className="grid grid-cols-7 gap-1 mb-1">
            {dayNames.map((name, i) => (
              <div
                key={i}
                className="text-center text-[11px] font-semibold py-1.5 uppercase tracking-wide text-life-text3"
              >
                {name}
              </div>
            ))}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day) => {
              const isCurrentMonth = day.month === 'current';
              const isToday = day.fullDate === todayStr;
              const isSelected = day.fullDate === selectedDate;
              const hasEvents = eventDateSet.has(day.fullDate);

              return (
                <button
                  key={day.fullDate}
                  onClick={() => handleDayClick(day.fullDate)}
                  className={`
                    relative aspect-square rounded-lg flex flex-col items-center justify-center
                    transition-all duration-200 text-sm
                    ${isCurrentMonth ? 'text-life-text' : 'text-life-text3 opacity-40'}
                    ${isSelected ? 'scale-105' : 'hover:scale-105'}
                    active:scale-95
                  `}
                  style={{
                    backgroundColor: isSelected
                      ? 'var(--life-accent)'
                      : isToday
                        ? 'var(--life-bg3)'
                        : 'transparent',
                    color: isSelected
                      ? '#FFFFFF'
                      : undefined,
                    border: isToday && !isSelected
                      ? '2px solid var(--life-accent)'
                      : '2px solid transparent',
                    borderRadius: '10px',
                  }}
                >
                  <span className={`font-medium ${isSelected ? 'font-bold' : ''}`}>
                    {day.date}
                  </span>
                  {hasEvents && (
                    <div
                      className="absolute bottom-1 w-1.5 h-1.5 rounded-full"
                      style={{
                        backgroundColor: isSelected ? '#FFFFFF' : 'var(--life-accent)',
                      }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </motion.div>

      {/* ===== Selected Day Header + Add Button ===== */}
      <motion.div variants={fadeInUp} className="flex items-center justify-between">
        <div>
          <h2 className="font-heading text-base font-bold text-life-text">
            {formatDisplayDate(selectedDate)}
          </h2>
          <p className="text-xs text-life-text3 mt-0.5">
            {selectedDayEvents.length} {language === 'bn' ? 'ইভেন্ট' : 'events'}
          </p>
        </div>
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors"
          style={{
            backgroundColor: showForm ? 'var(--life-bg3)' : 'var(--life-accent)',
            color: showForm ? 'var(--life-text2)' : '#FFFFFF',
          }}
        >
          <Plus className="w-4 h-4" />
          {t('calendar.addEvent', language)}
        </motion.button>
      </motion.div>

      {/* ===== Add Event Form ===== */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div
              className="rounded-xl p-5 relative overflow-hidden space-y-3"
              style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
            >
              <div className="absolute bottom-0 left-0 w-24 h-24 rounded-full blur-2xl pointer-events-none opacity-20" style={{ background: 'var(--life-accent)' }} />

              <div className="relative z-10 space-y-3">
                {/* Title */}
                <input
                  className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors placeholder:text-life-text3"
                  placeholder={t('calendar.eventTitle', language)}
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddEvent()}
                />

                {/* Description */}
                <textarea
                  className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors resize-none min-h-[60px] placeholder:text-life-text3"
                  placeholder={t('calendar.description', language)}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                />

                {/* Date (auto-filled) */}
                <div>
                  <div className="font-heading text-xs font-semibold text-life-text2 uppercase tracking-wide mb-1.5">
                    {t('calendar.date', language)}
                  </div>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-life-text3 pointer-events-none" />
                    <input
                      type="date"
                      className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl pl-10 pr-4 py-3 text-sm focus:border-life-primary transition-colors"
                      value={selectedDate}
                      onChange={(e) => setSelectedDate(e.target.value)}
                    />
                  </div>
                </div>

                {/* Time Row */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="font-heading text-xs font-semibold text-life-text2 uppercase tracking-wide mb-1.5 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {t('calendar.time', language)}
                    </div>
                    <input
                      type="time"
                      className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors"
                      value={formTime}
                      onChange={(e) => setFormTime(e.target.value)}
                    />
                  </div>
                  <div>
                    <div className="font-heading text-xs font-semibold text-life-text2 uppercase tracking-wide mb-1.5 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {t('calendar.endTime', language)}
                    </div>
                    <input
                      type="time"
                      className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors"
                      value={formEndTime}
                      onChange={(e) => setFormEndTime(e.target.value)}
                    />
                  </div>
                </div>

                {/* Category Pills */}
                <div>
                  <div className="font-heading text-xs font-semibold text-life-text2 uppercase tracking-wide mb-2 flex items-center gap-1">
                    <Tag className="w-3 h-3" />
                    {t('calendar.category', language)}
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {EVENT_CATEGORIES.map(cat => (
                      <button
                        key={cat.value}
                        onClick={() => setFormCategory(cat.value)}
                        className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                          formCategory === cat.value
                            ? 'ring-2 scale-105'
                            : 'opacity-60 hover:opacity-90'
                        }`}
                        style={{
                          background: cat.color + '20',
                          color: cat.color,
                          boxShadow: formCategory === cat.value ? `0 0 0 2px ${cat.color}` : 'none',
                        }}
                      >
                        {t(cat.labelKey, language)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Recurring Dropdown */}
                <div>
                  <div className="font-heading text-xs font-semibold text-life-text2 uppercase tracking-wide mb-1.5 flex items-center gap-1">
                    <Repeat className="w-3 h-3" />
                    {t('calendar.recurring', language)}
                  </div>
                  <select
                    className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors appearance-none cursor-pointer"
                    value={formRecurring}
                    onChange={(e) => setFormRecurring(e.target.value)}
                  >
                    {RECURRING_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value}>
                        {t(opt.labelKey, language)}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Buttons */}
                <div className="flex gap-3 pt-1">
                  <button
                    onClick={handleAddEvent}
                    disabled={!formTitle.trim()}
                    className="flex-1 py-3 rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
                    style={{
                      backgroundColor: 'var(--life-accent)',
                      color: '#FFFFFF',
                    }}
                  >
                    <Plus className="w-4 h-4" />
                    {t('calendar.add', language)}
                  </button>
                  <button
                    onClick={() => {
                      setShowForm(false);
                      setFormTitle('');
                      setFormDescription('');
                      setFormTime('09:00');
                      setFormEndTime('10:00');
                      setFormCategory('personal');
                      setFormRecurring('none');
                    }}
                    className="px-5 py-3 rounded-xl text-sm text-life-text2 hover:text-life-text transition-colors"
                    style={{ backgroundColor: 'var(--life-bg3)' }}
                  >
                    {t('common.cancel', language)}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== Selected Day Events List ===== */}
      <AnimatePresence mode="popLayout">
        {selectedDayEvents.length > 0 ? (
          <motion.div variants={fadeInUp} className="space-y-3">
            {selectedDayEvents.map((event) => {
              const catInfo = getCategoryInfo(event.category);
              return (
                <motion.div
                  key={event.id}
                  layout
                  className="rounded-xl p-4 relative overflow-hidden group"
                  style={{
                    backgroundColor: 'var(--life-bg2)',
                    border: '1px solid var(--life-border)',
                    opacity: event.completed ? 0.5 : 1,
                  }}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: event.completed ? 0.5 : 1, y: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Category accent line */}
                  <div
                    className="absolute left-0 top-0 bottom-0 w-1 rounded-l-2xl"
                    style={{ background: catInfo.color }}
                  />

                  <div className="pl-3">
                    <div className="flex items-start gap-3">
                      {/* Completed checkbox */}
                      <button
                        onClick={() => toggleCalendarEvent(event.id)}
                        className={`w-5 h-5 mt-0.5 border-2 rounded-md flex items-center justify-center flex-shrink-0 transition-all ${
                          event.completed
                            ? 'border-life-green bg-life-green'
                            : 'border-life-border2 hover:border-life-primary'
                        }`}
                      >
                        {event.completed && <Check className="w-3 h-3 text-white" />}
                      </button>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className={`text-sm font-medium text-life-text ${event.completed ? 'line-through' : ''}`}>
                            {event.title}
                          </span>
                          <span
                            className="text-[10px] px-2.5 py-0.5 rounded-full font-medium"
                            style={{ background: catInfo.color + '20', color: catInfo.color }}
                          >
                            {t(catInfo.labelKey, language)}
                          </span>
                          {event.recurring && event.recurring !== 'none' && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full font-medium bg-life-bg3 text-life-text3 flex items-center gap-1">
                              <Repeat className="w-2.5 h-2.5" />
                              {t(`calendar.${event.recurring}` as 'calendar.daily', language)}
                            </span>
                          )}
                        </div>

                        {event.description && (
                          <div className="text-xs text-life-text3 mb-2 line-clamp-2">{event.description}</div>
                        )}

                        {/* Time */}
                        <div className="flex items-center gap-3 text-[11px] text-life-text3">
                          {(event.time || event.endTime) && (
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {event.time || '—'} {event.endTime ? `→ ${event.endTime}` : ''}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Delete */}
                      <button
                        onClick={() => deleteCalendarEvent(event.id)}
                        className="text-life-text3 hover:text-life-coral transition-colors p-1 mt-0.5"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        ) : (
          <motion.div
            key="empty"
            variants={fadeIn}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="rounded-xl p-8 border-2 border-dashed border-life-border text-center"
            style={{ backgroundColor: 'var(--life-bg2)' }}
          >
            <Calendar className="w-10 h-10 mx-auto mb-3 text-life-text3" />
            <div className="text-sm text-life-text3">{t('calendar.noEvents', language)}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
