'use client';

import { useLifeOSStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState } from 'react';
import {
  supabaseSignIn,
  supabaseSignUp,
  supabaseSignOut,
  supabaseResetPassword,
  supabaseSignInWithGoogle,
  supabaseSignInWithGitHub,
  isSupabaseConfigured,
} from '@/lib/supabase';
import { Cloud, CloudOff, RefreshCw, Mail, Lock, User, Eye, EyeOff, AlertCircle, CheckCircle } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AuthPage() {
  const { language, supabaseUser, isAuthenticated, isSyncing, syncToCloud, lastSyncAt } = useLifeOSStore();
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const configured = isSupabaseConfigured();

  const handleSignIn = async () => {
    setError('');
    setSuccess('');
    if (!email || !password) { setError(language === 'bn' ? 'ইমেইল ও পাসওয়ার্ড দিন' : 'Email and password required'); return; }
    setSubmitting(true);
    try {
      await supabaseSignIn(email, password);
      setSuccess(t('auth.success', language));
    } catch {
      setError(t('auth.error', language));
    } finally {
      setSubmitting(false);
    }
  };

  const handleSignUp = async () => {
    setError('');
    setSuccess('');
    if (!email || !password || !name) { setError(language === 'bn' ? 'সব ফিল্ড পূরণ করুন' : 'All fields required'); return; }
    if (password !== confirmPassword) { setError(language === 'bn' ? 'পাসওয়ার্ড মিলছে না' : 'Passwords do not match'); return; }
    if (password.length < 6) { setError(language === 'bn' ? 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে' : 'Password must be at least 6 characters'); return; }
    setSubmitting(true);
    try {
      await supabaseSignUp(email, password, name);
      setSuccess(t('auth.signupSuccess', language));
    } catch {
      setError(t('auth.errorGeneric', language));
    } finally {
      setSubmitting(false);
    }
  };

  const handleForgotPassword = async () => {
    setError('');
    setSuccess('');
    if (!email) { setError(language === 'bn' ? 'ইমেইল দিন' : 'Enter your email'); return; }
    setSubmitting(true);
    try {
      await supabaseResetPassword(email);
      setSuccess(t('auth.resetSent', language));
    } catch {
      setError(t('auth.errorGeneric', language));
    } finally {
      setSubmitting(false);
    }
  };

  const handleSignOut = async () => {
    try { await supabaseSignOut(); } catch {}
  };

  // Authenticated view
  if (isAuthenticated && supabaseUser) {
    return (
      <div className="max-w-md mx-auto space-y-6">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center" style={{ background: 'linear-gradient(135deg, var(--life-accent), var(--life-secondary))' }}>
            <Cloud className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-lg font-bold" style={{ color: 'var(--life-text)' }}>{t('auth.cloudSync', language)}</h2>
          <p className="text-sm mt-1" style={{ color: 'var(--life-text2)' }}>{t('auth.syncDesc', language)}</p>
        </div>

        {/* User Info Card */}
        <div className="rounded-xl p-4 space-y-3" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold text-white" style={{ background: 'linear-gradient(135deg, var(--life-accent), var(--life-secondary))' }}>
              {supabaseUser.name?.[0]?.toUpperCase() || supabaseUser.email[0]?.toUpperCase() || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold truncate" style={{ color: 'var(--life-text)' }}>{supabaseUser.name || supabaseUser.email}</p>
              <p className="text-xs truncate" style={{ color: 'var(--life-text3)' }}>{supabaseUser.email}</p>
            </div>
            <div className="flex items-center gap-1 px-2 py-1 rounded-full" style={{ backgroundColor: 'rgba(34,197,94,0.1)' }}>
              <CheckCircle className="w-3 h-3" style={{ color: '#22C55E' }} />
              <span className="text-[10px] font-medium" style={{ color: '#22C55E' }}>{t('auth.connected', language)}</span>
            </div>
          </div>

          {/* Last Sync */}
          {lastSyncAt && (
            <p className="text-xs" style={{ color: 'var(--life-text3)' }}>
              {t('auth.lastSync', language)}: {new Date(lastSyncAt).toLocaleString(language === 'bn' ? 'bn-BD' : 'en-US')}
            </p>
          )}

          {/* Sync Now */}
          <button
            onClick={() => syncToCloud()}
            disabled={isSyncing}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all duration-200"
            style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            {isSyncing ? t('auth.syncing', language) : t('auth.syncNow', language)}
          </button>
        </div>

        {/* Data Safe Notice */}
        <div className="rounded-xl p-4 text-center" style={{ backgroundColor: 'rgba(34,197,94,0.05)', border: '1px solid rgba(34,197,94,0.15)' }}>
          <p className="text-xs" style={{ color: 'var(--life-text2)' }}>{t('auth.dataSafe', language)}</p>
        </div>

        {/* Sign Out */}
        <button
          onClick={handleSignOut}
          className="w-full py-2.5 rounded-lg text-sm font-medium transition-all duration-200"
          style={{ backgroundColor: 'rgba(239,68,68,0.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.2)' }}
        >
          {t('auth.signOut', language)}
        </button>
      </div>
    );
  }

  // Not configured view
  if (!configured) {
    return (
      <div className="max-w-md mx-auto space-y-6">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center" style={{ backgroundColor: 'rgba(245,158,11,0.1)' }}>
            <CloudOff className="w-8 h-8" style={{ color: '#F59E0B' }} />
          </div>
          <h2 className="text-lg font-bold" style={{ color: 'var(--life-text)' }}>{t('auth.offlineMode', language)}</h2>
          <p className="text-sm mt-1" style={{ color: 'var(--life-text2)' }}>{t('auth.offlineDesc', language)}</p>
        </div>
        <div className="rounded-xl p-4 text-center" style={{ backgroundColor: 'rgba(245,158,11,0.05)', border: '1px solid rgba(245,158,11,0.15)' }}>
          <p className="text-xs" style={{ color: 'var(--life-text2)' }}>{t('auth.notConfigured', language)}</p>
        </div>
      </div>
    );
  }

  // Login / Signup / Forgot Password form
  return (
    <div className="max-w-md mx-auto space-y-6">
      <div className="text-center">
        <div className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center" style={{ background: 'linear-gradient(135deg, var(--life-accent), var(--life-secondary))' }}>
          <Cloud className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-lg font-bold" style={{ color: 'var(--life-text)' }}>{t('auth.welcome', language)}</h2>
        <p className="text-sm mt-1" style={{ color: 'var(--life-text2)' }}>{t('auth.subtitle', language)}</p>
      </div>

      {/* Error / Success Messages */}
      {error && (
        <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 p-3 rounded-lg" style={{ backgroundColor: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)' }}>
          <AlertCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#EF4444' }} />
          <p className="text-xs" style={{ color: '#EF4444' }}>{error}</p>
        </motion.div>
      )}
      {success && (
        <motion.div initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 p-3 rounded-lg" style={{ backgroundColor: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.2)' }}>
          <CheckCircle className="w-4 h-4 flex-shrink-0" style={{ color: '#22C55E' }} />
          <p className="text-xs" style={{ color: '#22C55E' }}>{success}</p>
        </motion.div>
      )}

      {/* Form */}
      <div className="space-y-4">
        {mode === 'signup' && (
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--life-text3)' }} />
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder={t('auth.name', language)}
              className="w-full pl-10 pr-4 py-2.5 rounded-lg text-sm outline-none transition-all duration-200"
              style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)', color: 'var(--life-text)' }}
            />
          </div>
        )}

        <div className="relative">
          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--life-text3)' }} />
          <input
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder={t('auth.email', language)}
            className="w-full pl-10 pr-4 py-2.5 rounded-lg text-sm outline-none transition-all duration-200"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)', color: 'var(--life-text)' }}
          />
        </div>

        {mode !== 'forgot' && (
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--life-text3)' }} />
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder={t('auth.password', language)}
              className="w-full pl-10 pr-10 py-2.5 rounded-lg text-sm outline-none transition-all duration-200"
              style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)', color: 'var(--life-text)' }}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2"
              style={{ color: 'var(--life-text3)' }}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        )}

        {mode === 'signup' && (
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'var(--life-text3)' }} />
            <input
              type={showPassword ? 'text' : 'password'}
              value={confirmPassword}
              onChange={e => setConfirmPassword(e.target.value)}
              placeholder={t('auth.confirmPassword', language)}
              className="w-full pl-10 pr-4 py-2.5 rounded-lg text-sm outline-none transition-all duration-200"
              style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)', color: 'var(--life-text)' }}
            />
          </div>
        )}

        {/* Submit Button */}
        <button
          onClick={mode === 'login' ? handleSignIn : mode === 'signup' ? handleSignUp : handleForgotPassword}
          disabled={submitting}
          className="w-full py-2.5 rounded-lg text-sm font-medium transition-all duration-200"
          style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}
        >
          {submitting
            ? mode === 'login' ? t('auth.signingIn', language) : mode === 'signup' ? t('auth.signingUp', language) : '...'
            : mode === 'login' ? t('auth.signIn', language) : mode === 'signup' ? t('auth.signUp', language) : t('auth.forgotPassword', language)
          }
        </button>

        {/* Mode Toggle */}
        <div className="text-center space-y-2">
          {mode === 'login' && (
            <>
              <button onClick={() => { setMode('forgot'); setError(''); setSuccess(''); }} className="text-xs hover:underline" style={{ color: 'var(--life-accent)' }}>
                {t('auth.forgotPassword', language)}
              </button>
              <p className="text-xs" style={{ color: 'var(--life-text3)' }}>
                {t('auth.noAccount', language)}{' '}
                <button onClick={() => { setMode('signup'); setError(''); setSuccess(''); }} className="hover:underline" style={{ color: 'var(--life-accent)' }}>
                  {t('auth.signUp', language)}
                </button>
              </p>
            </>
          )}
          {mode === 'signup' && (
            <p className="text-xs" style={{ color: 'var(--life-text3)' }}>
              {t('auth.hasAccount', language)}{' '}
              <button onClick={() => { setMode('login'); setError(''); setSuccess(''); }} className="hover:underline" style={{ color: 'var(--life-accent)' }}>
                {t('auth.signIn', language)}
              </button>
            </p>
          )}
          {mode === 'forgot' && (
            <button onClick={() => { setMode('login'); setError(''); setSuccess(''); }} className="text-xs hover:underline" style={{ color: 'var(--life-accent)' }}>
              {t('auth.signIn', language)}
            </button>
          )}
        </div>

        {/* Divider */}
        {mode !== 'forgot' && (
          <div className="flex items-center gap-3">
            <div className="flex-1 h-px" style={{ backgroundColor: 'var(--life-border)' }} />
            <span className="text-[10px]" style={{ color: 'var(--life-text3)' }}>{t('auth.orContinue', language)}</span>
            <div className="flex-1 h-px" style={{ backgroundColor: 'var(--life-border)' }} />
          </div>
        )}

        {/* OAuth Buttons */}
        {mode !== 'forgot' && (
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => supabaseSignInWithGoogle()}
              className="flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-medium transition-all duration-200"
              style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)', color: 'var(--life-text2)' }}
            >
              {t('auth.google', language)}
            </button>
            <button
              onClick={() => supabaseSignInWithGitHub()}
              className="flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-medium transition-all duration-200"
              style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)', color: 'var(--life-text2)' }}
            >
              {t('auth.github', language)}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
