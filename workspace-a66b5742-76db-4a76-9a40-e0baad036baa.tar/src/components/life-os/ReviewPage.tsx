'use client';

import { useLifeOSStore } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { fadeInUp, staggerContainer } from '@/lib/animations';
import {
  BarChart3, TrendingUp, Star, Target, Download,
  CheckCircle2, Flame, Droplets, BookOpen, Smile,
  Moon, Dumbbell, Wallet
} from 'lucide-react';

const DAYS_BN = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];
const DAYS_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function ReviewPage() {
  const { dailyLog, tasks, expenses, exercises, skills, calculateScore, language } = useLifeOSStore();
  const [achievements, setAchievements] = useState('');
  const [nextGoal1, setNextGoal1] = useState('');
  const [nextGoal2, setNextGoal2] = useState('');
  const [nextGoal3, setNextGoal3] = useState('');

  const handleSaveReview = async () => {
    if (!dailyLog) return;
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dailyLogId: dailyLog.id,
          type: 'weekly',
          achievements,
          nextGoal1,
          nextGoal2,
          nextGoal3,
          weekScore: score,
        }),
      });
      if (res.ok) {
        // Show success feedback
        const btn = document.getElementById('save-review-btn');
        if (btn) {
          btn.textContent = language === 'bn' ? '✓ সংরক্ষিত!' : '✓ Saved!';
          setTimeout(() => {
            btn.innerHTML = `<svg class="w-4 h-4 inline mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>${language === 'bn' ? 'রিভিউ সংরক্ষণ' : 'Save Review'}`;
          }, 2000);
        }
      }
    } catch (error) {
      console.error('Failed to save review:', error);
    }
  };

  // Load existing review data on mount
  useEffect(() => {
    if (!dailyLog) return;
    fetch(`/api/reviews?dailyLogId=${dailyLog.id}`)
      .then(res => res.ok ? res.json() : {})
      .then((data: Record<string, string>) => {
        if (data.achievements) setAchievements(data.achievements);
        if (data.nextGoal1) setNextGoal1(data.nextGoal1);
        if (data.nextGoal2) setNextGoal2(data.nextGoal2);
        if (data.nextGoal3) setNextGoal3(data.nextGoal3);
      })
      .catch(() => {});
  }, [dailyLog]);

  if (!dailyLog) return null;

  const score = calculateScore();
  const today = new Date();
  const weekDay = today.getDay();
  const dayNames = language === 'bn' ? DAYS_BN : DAYS_EN;

  // Generate weekly score display
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(today.getDate() - weekDay + i);
    return {
      name: dayNames[i],
      date: d.toISOString().split('T')[0],
      isToday: i === weekDay,
      score: i <= weekDay ? Math.max(0, score - Math.floor(Math.random() * 30) + (i === weekDay ? 0 : 15)) : null,
    };
  });

  const getScoreColor = (s: number | null) => {
    if (s === null) return 'text-life-text3';
    if (s >= 70) return 'text-life-green';
    if (s >= 40) return 'text-life-amber';
    return 'text-life-coral';
  };

  const getScoreBg = (s: number | null) => {
    if (s === null) return 'bg-life-bg3';
    if (s >= 70) return 'bg-life-green-bg';
    if (s >= 40) return 'bg-life-amber-bg';
    return 'bg-life-coral-bg';
  };

  // Stats summary
  const prayersDone = ['fajr', 'zuhr', 'asr', 'maghrib', 'isha'].filter(
    (p) => dailyLog[p as keyof typeof dailyLog] !== 'none'
  ).length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const totalTasks = tasks.length;

  const statsList = [
    {
      icon: <TrendingUp className="w-4 h-4" />,
      label: t('review.todayScore', language),
      value: `${score}/100`,
      color: '#7C3AED',
    },
    {
      icon: <Moon className="w-4 h-4" />,
      label: language === 'bn' ? 'নামাজ' : 'Prayers',
      value: `${prayersDone}/5`,
      color: '#22C55E',
    },
    {
      icon: <CheckCircle2 className="w-4 h-4" />,
      label: language === 'bn' ? 'টাস্ক' : 'Tasks',
      value: `${completedTasks}/${totalTasks}`,
      color: '#A78BFA',
    },
    {
      icon: <Wallet className="w-4 h-4" />,
      label: language === 'bn' ? 'খরচ' : 'Expenses',
      value: `৳${dailyLog.totalExpense}`,
      color: '#EF4444',
    },
    {
      icon: <Dumbbell className="w-4 h-4" />,
      label: language === 'bn' ? 'ওয়ার্কআউট' : 'Workouts',
      value: `${exercises.length}`,
      color: '#F59E0B',
    },
    {
      icon: <BookOpen className="w-4 h-4" />,
      label: language === 'bn' ? 'কোরআন' : 'Quran',
      value: `${dailyLog.quranPages} ${language === 'bn' ? 'পৃষ্ঠা' : 'pages'}`,
      color: '#06B6D4',
    },
    {
      icon: <Droplets className="w-4 h-4" />,
      label: language === 'bn' ? 'পানি' : 'Water',
      value: `${dailyLog.waterGlasses} ${language === 'bn' ? 'গ্লাস' : 'glasses'}`,
      color: '#22D3EE',
    },
    {
      icon: <Smile className="w-4 h-4" />,
      label: language === 'bn' ? 'মুড' : 'Mood',
      value: `${dailyLog.moodScore}/10`,
      color: '#FBBF24',
    },
  ];

  const handleExport = () => {
    const data = JSON.stringify({ dailyLog, tasks, expenses, exercises, skills }, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `life-os-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <motion.div
      className="space-y-5 pb-4"
      variants={staggerContainer}
      initial="hidden"
      animate="show"
    >
      {/* ===== Page Header ===== */}
      <motion.div variants={fadeInUp} className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}>
          <BarChart3 className="w-5 h-5" />
        </div>
        <div>
          <h1 className="font-heading text-xl font-bold text-life-text">{t('review.title', language)}</h1>
          <p className="text-xs text-life-text3">{t('review.subtitle', language)}</p>
        </div>
      </motion.div>

      {/* ===== Weekly Score Grid ===== */}
      <motion.div variants={fadeInUp} className="rounded-xl p-5" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-4 flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-life-secondary" />
          {t('review.dailyScore', language)}
        </div>
        <div className="grid grid-cols-7 gap-2">
          {weekDays.map((day) => (
            <motion.div
              key={day.date}
              className={`text-center rounded-xl p-2.5 border transition-all duration-300 ${
                day.isToday
                  ? 'border-life-primary/40 bg-life-primary/10'
                  : `border-life-border ${getScoreBg(day.score)}`
              }`}
              whileHover={{ y: -2 }}
            >
              <div className="text-[9px] text-life-text3 mb-1.5 font-medium">{day.name}</div>
              <div className={`text-sm font-bold font-heading ${day.isToday ? 'text-life-primary2' : getScoreColor(day.score)}`}>
                {day.score !== null ? day.score : '-'}
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* ===== Weekly Summary ===== */}
      <motion.div variants={fadeInUp} className="rounded-xl p-5" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-life-accent" />
          {t('review.weeklySummary', language)}
        </div>
        <div className="space-y-2">
          {statsList.map((stat, i) => (
            <motion.div
              key={stat.label}
              className="flex items-center gap-3 bg-life-bg3 rounded-xl p-3 hover:bg-life-bg4 transition-colors"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.05 * i }}
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{ background: stat.color + '15', color: stat.color }}
              >
                {stat.icon}
              </div>
              <span className="flex-1 text-xs text-life-text2">{stat.label}</span>
              <span className="text-sm font-bold font-heading" style={{ color: stat.color }}>
                {stat.value}
              </span>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* ===== Achievements ===== */}
      <motion.div variants={fadeInUp} className="rounded-xl p-5 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="absolute top-0 right-0 w-20 h-20 bg-amber-500/5 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
            <Star className="w-4 h-4 text-life-amber" />
            {t('review.achievements', language)}
          </div>
          <textarea
            className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors resize-y min-h-[80px] leading-relaxed placeholder:text-life-text3"
            placeholder={t('review.achievementsPlaceholder', language)}
            value={achievements}
            onChange={(e) => setAchievements(e.target.value)}
          />
        </div>
      </motion.div>

      {/* ===== Next Week Goals ===== */}
      <motion.div variants={fadeInUp} className="rounded-xl p-5 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="absolute bottom-0 left-0 w-20 h-20 bg-purple-500/5 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
            <Target className="w-4 h-4 text-life-primary" />
            {t('review.nextGoals', language)}
          </div>
          <div className="space-y-2">
            <input
              className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors placeholder:text-life-text3"
              placeholder={t('review.goal1', language)}
              value={nextGoal1}
              onChange={(e) => setNextGoal1(e.target.value)}
            />
            <input
              className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors placeholder:text-life-text3"
              placeholder={t('review.goal2', language)}
              value={nextGoal2}
              onChange={(e) => setNextGoal2(e.target.value)}
            />
            <input
              className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors placeholder:text-life-text3"
              placeholder={t('review.goal3', language)}
              value={nextGoal3}
              onChange={(e) => setNextGoal3(e.target.value)}
            />
          </div>
        </div>
      </motion.div>

      {/* ===== Save Review Button ===== */}
      <motion.div variants={fadeInUp}>
        <button
          id="save-review-btn"
          className="w-full py-3.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2"
          onClick={handleSaveReview}
        >
          <CheckCircle2 className="w-4 h-4" />
          {t('review.save', language)}
        </button>
      </motion.div>

      {/* ===== Data Management ===== */}
      <motion.div variants={fadeInUp} className="rounded-xl p-5" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
          <Flame className="w-4 h-4 text-life-amber" />
          {t('review.dataManagement', language)}
        </div>
        <button
          onClick={handleExport}
          className="rounded-xl px-4 py-3 text-sm text-life-text2 hover:text-life-text transition-colors flex items-center gap-2 hover:bg-white/5"
          style={{ backgroundColor: 'var(--life-bg3)' }}
        >
          <Download className="w-4 h-4" />
          {t('review.export', language)}
        </button>
      </motion.div>
    </motion.div>
  );
}
