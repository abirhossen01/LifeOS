'use client';

import { useLifeOSStore, GoalCategory } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { fadeInUp, staggerContainer } from '@/lib/animations';
import { Target, Plus, X, Check, Trash2, Calendar, Pencil } from 'lucide-react';

// ===== Animation Variants =====
// Imported from @/lib/animations to avoid TypeScript
// "Type 'string' is not assignable to type 'Easing'" errors.

const GOAL_CATEGORIES: { value: GoalCategory; labelKey: string; color: string; bgClass: string }[] = [
  { value: 'personal', labelKey: 'goals.personal', color: '#D4A020', bgClass: 'bg-life-amber-bg' },
  { value: 'career', labelKey: 'goals.career', color: '#7C3AED', bgClass: 'bg-life-purple-bg' },
  { value: 'health', labelKey: 'goals.health', color: '#EF4444', bgClass: 'bg-life-coral-bg' },
  { value: 'spiritual', labelKey: 'goals.spiritual', color: '#22C55E', bgClass: 'bg-life-green-bg' },
  { value: 'financial', labelKey: 'goals.financial', color: '#F59E0B', bgClass: 'bg-life-amber-bg' },
  { value: 'education', labelKey: 'goals.education', color: '#06B6D4', bgClass: 'bg-life-blue-bg' },
];

export default function GoalsPage() {
  const { goals, addGoal, toggleGoal, deleteGoal, updateGoalProgress, language } = useLifeOSStore();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<GoalCategory>('personal');
  const [targetDate, setTargetDate] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingProgress, setEditingProgress] = useState<string | null>(null);
  const [progressInput, setProgressInput] = useState('');
  const [editingGoalId, setEditingGoalId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editCategory, setEditCategory] = useState<GoalCategory>('personal');
  const [editTargetDate, setEditTargetDate] = useState('');

  const handleAddGoal = async () => {
    if (!title.trim()) return;
    await addGoal(title.trim(), description, category, targetDate || undefined);
    setTitle('');
    setDescription('');
    setTargetDate('');
    setShowForm(false);
  };

  const handleUpdateProgress = async (id: string) => {
    const val = parseInt(progressInput);
    if (isNaN(val) || val < 0 || val > 100) return;
    await updateGoalProgress(id, val);
    setEditingProgress(null);
    setProgressInput('');
  };

  const handleEditGoal = async (id: string) => {
    try {
      const res = await fetch(`/api/goals/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: editTitle,
          description: editDescription,
          category: editCategory,
          targetDate: editTargetDate || null,
        }),
      });
      if (res.ok) {
        const { goals } = useLifeOSStore.getState();
        useLifeOSStore.getState().setGoals(
          goals.map(g => g.id === id ? { ...g, title: editTitle, description: editDescription, category: editCategory, targetDate: editTargetDate || undefined } : g)
        );
        setEditingGoalId(null);
      }
    } catch (error) {
      console.error('Failed to edit goal:', error);
    }
  };

  const startEditingGoal = (goal: typeof goals[0]) => {
    setEditingGoalId(goal.id);
    setEditTitle(goal.title);
    setEditDescription(goal.description);
    setEditCategory(goal.category);
    setEditTargetDate(goal.targetDate || '');
    setEditingProgress(null);
  };

  const activeGoals = goals.filter(g => !g.completed);
  const completedGoals = goals.filter(g => g.completed);
  const overallProgress = goals.length > 0 ? Math.round(goals.reduce((sum, g) => sum + g.progress, 0) / goals.length) : 0;

  const getCategoryInfo = (cat: string) => {
    return GOAL_CATEGORIES.find(c => c.value === cat) || GOAL_CATEGORIES[0];
  };

  return (
    <motion.div
      className="space-y-5 pb-4"
      variants={staggerContainer}
      initial="hidden"
      animate="show"
    >
      {/* ===== Page Header ===== */}
      <motion.div variants={fadeInUp} className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}>
          <Target className="w-5 h-5" />
        </div>
        <div>
          <h1 className="font-heading text-xl font-bold text-life-text">{t('goals.title', language)}</h1>
          <p className="text-xs text-life-text3">{t('goals.subtitle', language)}</p>
        </div>
      </motion.div>

      {/* ===== Overall Progress ===== */}
      {goals.length > 0 && (
        <motion.div variants={fadeInUp} className="rounded-xl p-5 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
          <div className="absolute top-0 right-0 w-24 h-24 bg-green-500/5 rounded-full blur-2xl pointer-events-none" />
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-3">
              <span className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide">
                {t('goals.overallProgress', language)}
              </span>
              <span className="text-2xl font-bold font-heading" style={{ color: 'var(--life-accent)' }}>
                {overallProgress}%
              </span>
            </div>
            <div className="h-3 bg-life-bg3 rounded-full overflow-hidden">
              <motion.div
                className="h-full rounded-full"
                style={{ background: 'linear-gradient(90deg, #22C55E, #F59E0B)' }}
                initial={{ width: 0 }}
                animate={{ width: `${overallProgress}%` }}
                transition={{ duration: 1, ease: 'easeOut' }}
              />
            </div>
            <div className="flex justify-between mt-3">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-life-primary" />
                <span className="text-[11px] text-life-text3">
                  {activeGoals.length} {language === 'bn' ? 'চলমান' : 'active'}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-life-green" />
                <span className="text-[11px] text-life-text3">
                  {completedGoals.length} {language === 'bn' ? 'সম্পন্ন' : 'completed'}
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* ===== Add Goal ===== */}
      <motion.div variants={fadeInUp}>
        {!showForm ? (
          <button
            onClick={() => setShowForm(true)}
            className="w-full rounded-xl p-4 border-2 border-dashed border-life-border hover:border-life-primary/40 text-sm text-life-text2 font-medium transition-all duration-300 flex items-center justify-center gap-2 group hover:bg-life-primary/5"
          >
            <Plus className="w-4 h-4 text-life-primary group-hover:scale-110 transition-transform" />
            {t('goals.addGoal', language)}
          </button>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="rounded-xl p-5 relative overflow-hidden"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
          >
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-purple-500/5 rounded-full blur-2xl pointer-events-none" />

            <div className="relative z-10 space-y-3">
              {/* Title */}
              <input
                className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors placeholder:text-life-text3"
                placeholder={t('goals.goalTitle', language)}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddGoal()}
              />

              {/* Description */}
              <textarea
                className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-3 text-sm focus:border-life-primary transition-colors resize-none min-h-[70px] placeholder:text-life-text3"
                placeholder={t('goals.description', language)}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />

              {/* Category Pills */}
              <div>
                <div className="font-heading text-xs font-semibold text-life-text2 uppercase tracking-wide mb-2">
                  {t('goals.category', language)}
                </div>
                <div className="flex gap-2 flex-wrap">
                  {GOAL_CATEGORIES.map(cat => (
                    <button
                      key={cat.value}
                      onClick={() => setCategory(cat.value)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                        category === cat.value
                          ? 'ring-2 scale-105'
                          : 'opacity-60 hover:opacity-90'
                      }`}
                      style={{
                        background: cat.color + '20',
                        color: cat.color,
                        boxShadow: category === cat.value ? `0 0 0 2px ${cat.color}` : 'none',
                      }}
                    >
                      {t(cat.labelKey, language)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Target Date */}
              <div>
                <div className="font-heading text-xs font-semibold text-life-text2 uppercase tracking-wide mb-2">
                  {t('goals.targetDate', language)}
                </div>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-life-text3 pointer-events-none" />
                  <input
                    type="date"
                    className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl pl-10 pr-4 py-3 text-sm focus:border-life-primary transition-colors"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                  />
                </div>
              </div>

              {/* Buttons */}
              <div className="flex gap-3 pt-1">
                <button
                  onClick={handleAddGoal}
                  className="flex-1 py-3 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2"
                >
                  <Plus className="w-4 h-4" />
                  {t('goals.add', language)}
                </button>
                <button
                  onClick={() => { setShowForm(false); setTitle(''); setDescription(''); setTargetDate(''); }}
                  className="px-5 py-3 rounded-xl text-sm text-life-text2 hover:text-life-text transition-colors"
                  style={{ backgroundColor: 'var(--life-bg3)' }}
                >
                  {t('common.cancel', language)}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>

      {/* ===== Active Goals ===== */}
      <AnimatePresence mode="popLayout">
        {activeGoals.length > 0 && (
          <motion.div variants={fadeInUp} className="space-y-3">
            <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide">
              {t('goals.active', language)}
            </div>
            {activeGoals.map((goal) => {
              const catInfo = getCategoryInfo(goal.category);
              return (
                <motion.div
                  key={goal.id}
                  layout
                  className="rounded-xl p-4 relative overflow-hidden group"
                  style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Category accent line */}
                  <div
                    className="absolute left-0 top-0 bottom-0 w-1 rounded-l-2xl"
                    style={{ background: catInfo.color }}
                  />

                  <div className="pl-3">
                    {/* Header row */}
                    <div className="flex items-start gap-3">
                      <button
                        onClick={() => toggleGoal(goal.id)}
                        className="w-5 h-5 mt-0.5 border-2 rounded-md flex items-center justify-center flex-shrink-0 transition-all border-life-border2 hover:border-life-primary"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="text-sm font-medium text-life-text">{goal.title}</span>
                          <span
                            className="text-[10px] px-2.5 py-0.5 rounded-full font-medium"
                            style={{ background: catInfo.color + '20', color: catInfo.color }}
                          >
                            {t(catInfo.labelKey, language)}
                          </span>
                        </div>
                        {goal.description && (
                          <div className="text-xs text-life-text3 mb-3 line-clamp-2">{goal.description}</div>
                        )}

                        {/* Progress Bar */}
                        <div className="flex items-center gap-3 mb-1">
                          <div className="flex-1 h-2.5 bg-life-bg3 rounded-full overflow-hidden">
                            <motion.div
                              className="h-full rounded-full"
                              style={{ background: catInfo.color }}
                              initial={{ width: 0 }}
                              animate={{ width: `${goal.progress}%` }}
                              transition={{ duration: 0.6, ease: 'easeOut' }}
                            />
                          </div>
                          <span className="text-xs font-bold min-w-[36px] text-right" style={{ color: catInfo.color }}>
                            {goal.progress}%
                          </span>
                        </div>

                        {/* Target Date */}
                        {goal.targetDate && (
                          <div className="text-[11px] text-life-text3 flex items-center gap-1 mt-1 mb-2">
                            <Calendar className="w-3 h-3" />
                            {language === 'bn' ? 'লক্ষ্য' : 'Target'}: {goal.targetDate}
                          </div>
                        )}

                        {/* Inline Edit Form or Progress/Actions */}
                        {editingGoalId === goal.id ? (
                          <div className="space-y-3 mt-3 pt-3 border-t border-life-border">
                            <input
                              className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-2.5 text-sm focus:border-life-primary transition-colors placeholder:text-life-text3"
                              placeholder={t('goals.goalTitle', language)}
                              value={editTitle}
                              onChange={(e) => setEditTitle(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleEditGoal(goal.id)}
                              autoFocus
                            />
                            <textarea
                              className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-4 py-2.5 text-sm focus:border-life-primary transition-colors resize-none min-h-[60px] placeholder:text-life-text3"
                              placeholder={t('goals.description', language)}
                              value={editDescription}
                              onChange={(e) => setEditDescription(e.target.value)}
                            />
                            <div>
                              <div className="font-heading text-xs font-semibold text-life-text2 uppercase tracking-wide mb-2">
                                {t('goals.category', language)}
                              </div>
                              <div className="flex gap-2 flex-wrap">
                                {GOAL_CATEGORIES.map(cat => (
                                  <button
                                    key={cat.value}
                                    onClick={() => setEditCategory(cat.value)}
                                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                                      editCategory === cat.value
                                        ? 'ring-2 scale-105'
                                        : 'opacity-60 hover:opacity-90'
                                    }`
                                  }
                                    style={{
                                      background: cat.color + '20',
                                      color: cat.color,
                                      boxShadow: editCategory === cat.value ? `0 0 0 2px ${cat.color}` : 'none',
                                    }}
                                  >
                                    {t(cat.labelKey, language)}
                                  </button>
                                ))}
                              </div>
                            </div>
                            <div>
                              <div className="font-heading text-xs font-semibold text-life-text2 uppercase tracking-wide mb-2">
                                {t('goals.targetDate', language)}
                              </div>
                              <div className="relative">
                                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-life-text3 pointer-events-none" />
                                <input
                                  type="date"
                                  className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl pl-10 pr-4 py-2.5 text-sm focus:border-life-primary transition-colors"
                                  value={editTargetDate}
                                  onChange={(e) => setEditTargetDate(e.target.value)}
                                />
                              </div>
                            </div>
                            <div className="flex gap-3 pt-1">
                              <button
                                onClick={() => handleEditGoal(goal.id)}
                                className="px-4 py-2 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5"
                              >
                                <Check className="w-3.5 h-3.5" />
                                {t('common.save', language)}
                              </button>
                              <button
                                onClick={() => setEditingGoalId(null)}
                                className="px-4 py-2 rounded-xl text-xs text-life-text2 hover:text-life-text transition-colors"
                                style={{ backgroundColor: 'var(--life-bg3)' }}
                              >
                                {t('common.cancel', language)}
                              </button>
                            </div>
                          </div>
                        ) : editingProgress === goal.id ? (
                          <div className="flex gap-2 mt-2 items-center">
                            <input
                              type="number"
                              className="w-20 bg-life-bg3 border border-life-border text-life-text rounded-lg px-3 py-1.5 text-xs focus:border-life-primary transition-colors"
                              placeholder="0-100"
                              min={0}
                              max={100}
                              value={progressInput}
                              onChange={(e) => setProgressInput(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleUpdateProgress(goal.id)}
                              autoFocus
                            />
                            <button
                              onClick={() => handleUpdateProgress(goal.id)}
                              className="px-3 py-1.5 bg-life-primary text-white rounded-lg text-xs font-semibold hover:bg-life-primary/90 transition-colors"
                            >
                              {t('common.save', language)}
                            </button>
                            <button
                              onClick={() => { setEditingProgress(null); setProgressInput(''); }}
                              className="text-xs text-life-text3 hover:text-life-text transition-colors"
                            >
                              {t('common.cancel', language)}
                            </button>
                          </div>
                        ) : (
                          <div className="flex gap-3 mt-2 flex-wrap">
                            <button
                              onClick={() => { setEditingProgress(goal.id); setProgressInput(String(goal.progress)); }}
                              className="text-[11px] text-life-primary hover:text-life-primary2 transition-colors font-medium"
                            >
                              {t('goals.updateProgress', language)}
                            </button>
                            <button
                              onClick={() => toggleGoal(goal.id)}
                              className="text-[11px] text-life-green hover:text-life-green2 transition-colors font-medium"
                            >
                              {t('goals.markComplete', language)}
                            </button>
                            <button
                              onClick={() => startEditingGoal(goal)}
                              className="text-[11px] text-life-text2 hover:text-life-text transition-colors font-medium flex items-center gap-1"
                            >
                              <Pencil className="w-3 h-3" />
                              {language === 'bn' ? 'সম্পাদনা' : 'Edit'}
                            </button>
                          </div>
                        )}
                      </div>

                      <button
                        onClick={() => deleteGoal(goal.id)}
                        className="text-life-text3 hover:text-life-coral transition-colors p-1 mt-0.5"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== Completed Goals ===== */}
      <AnimatePresence mode="popLayout">
        {completedGoals.length > 0 && (
          <motion.div variants={fadeInUp} className="space-y-2">
            <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide">
              {t('goals.completed', language)}
            </div>
            {completedGoals.map((goal) => {
              const catInfo = getCategoryInfo(goal.category);
              return (
                <motion.div
                  key={goal.id}
                  layout
                  className="rounded-xl p-3 opacity-60"
                  style={{ backgroundColor: 'var(--life-bg3)' }}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 0.6, y: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-life-green rounded-md flex items-center justify-center flex-shrink-0">
                      <Check className="w-3 h-3 text-white" />
                    </div>
                    <span className="flex-1 text-sm line-through text-life-text3">{goal.title}</span>
                    <span
                      className="text-[10px] px-2 py-0.5 rounded-full"
                      style={{ background: catInfo.color + '20', color: catInfo.color }}
                    >
                      {t(catInfo.labelKey, language)}
                    </span>
                    <button
                      onClick={() => toggleGoal(goal.id)}
                      className="text-[11px] text-life-blue hover:text-life-secondary2 transition-colors"
                    >
                      {t('goals.markIncomplete', language)}
                    </button>
                    <button
                      onClick={() => deleteGoal(goal.id)}
                      className="text-life-text3 hover:text-life-coral transition-colors p-0.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== Empty State ===== */}
      {goals.length === 0 && !showForm && (
        <motion.div
          variants={fadeInUp}
          className="rounded-xl p-8 border-2 border-dashed border-life-border text-center"
          style={{ backgroundColor: 'var(--life-bg2)' }}
        >
          <div className="text-5xl mb-4 animate-float" style={{ color: 'var(--life-accent)' }}>
            <Target className="w-12 h-12 mx-auto" />
          </div>
          <div className="text-sm text-life-text3 mb-4">{t('goals.noGoals', language)}</div>
          <button
            onClick={() => setShowForm(true)}
            className="px-5 py-2.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-sm font-semibold transition-colors inline-flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            {t('goals.addGoal', language)}
          </button>
        </motion.div>
      )}
    </motion.div>
  );
}
