'use client';

import { useLifeOSStore, PrayerStatus } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion } from 'framer-motion';
import type { Variants } from 'framer-motion';
import { useState } from 'react';
import { Moon, BookOpen, BarChart3 } from 'lucide-react';

const PRAYERS = [
  { key: 'fajr' as const, nameKey: 'prayer.fajr', icon: '🌅' },
  { key: 'zuhr' as const, nameKey: 'prayer.zuhr', icon: '☀️' },
  { key: 'asr' as const, nameKey: 'prayer.asr', icon: '🌤️' },
  { key: 'maghrib' as const, nameKey: 'prayer.maghrib', icon: '🌅' },
  { key: 'isha' as const, nameKey: 'prayer.isha', icon: '🌙' },
];

const statusConfig: Record<PrayerStatus, { labelKey: string; color: string; icon: string }> = {
  none: { labelKey: 'prayer.none', color: 'text-life-text3', icon: '✗' },
  alone: { labelKey: 'prayer.alone', color: 'text-life-green', icon: '✅' },
  jamaat: { labelKey: 'prayer.jamaat', color: 'text-life-blue', icon: '🕌' },
};

const cardVariants: Variants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    scale: 1,
    transition: {
      delay: i * 0.08,
      duration: 0.4,
      ease: [0.25, 0.46, 0.45, 0.94],
    },
  }),
};

export default function PrayerPage() {
  const { dailyLog, updatePrayer, updateQuranPages, language } = useLifeOSStore();
  const [quranInput, setQuranInput] = useState('');

  if (!dailyLog) return null;

  const handlePrayerClick = (prayer: 'fajr' | 'zuhr' | 'asr' | 'maghrib' | 'isha') => {
    const current = dailyLog[prayer];
    let next: PrayerStatus;
    if (current === 'none') next = 'alone';
    else if (current === 'alone') next = 'jamaat';
    else next = 'none';
    updatePrayer(prayer, next);
  };

  const handleSaveQuran = () => {
    const pages = parseInt(quranInput) || 0;
    updateQuranPages(pages);
    setQuranInput('');
  };

  const completedCount = PRAYERS.filter((p) => dailyLog[p.key] !== 'none').length;
  const jamaatCount = PRAYERS.filter((p) => dailyLog[p.key] === 'jamaat').length;

  return (
    <div className="space-y-4">
      {/* ===== Page Header ===== */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex items-center gap-3"
      >
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}>
          <Moon className="w-5 h-5" />
        </div>
        <div>
          <h2 className="font-heading text-xl font-bold text-life-text">
            {t('prayer.title', language)}
          </h2>
          <p className="text-xs text-life-text3 mt-0.5 font-islamic">
            {t('prayer.subtitle', language)}
          </p>
        </div>
      </motion.div>

      {/* ===== Prayer Cards (Vertical Layout) ===== */}
      <div className="space-y-3">
        {PRAYERS.map((prayer, i) => {
          const status = dailyLog[prayer.key];
          const config = statusConfig[status];

          return (
            <motion.button
              key={prayer.key}
              custom={i}
              variants={cardVariants}
              initial="hidden"
              animate="visible"
              onClick={() => handlePrayerClick(prayer.key)}
              className={`
                w-full rounded-xl p-4 flex items-center gap-4
                transition-all duration-300 ease-out cursor-pointer touch-target
                hover:scale-[1.01] active:scale-[0.99]
              `}
              style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Prayer Icon */}
              <div
                className={`
                  w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0
                  transition-all duration-300
                  ${status === 'none'
                    ? 'bg-life-bg3 border border-life-border'
                    : status === 'alone'
                      ? 'bg-life-green/10 border border-life-green/30'
                      : 'bg-life-blue/10 border border-life-blue/30'
                  }
                `}
              >
                {prayer.icon}
              </div>

              {/* Prayer Name + Status */}
              <div className="flex-1 text-left">
                <div className="font-heading text-sm font-semibold text-life-text">
                  {t(prayer.nameKey, language)}
                </div>
                <div className={`text-xs mt-0.5 font-medium ${config.color}`}>
                  {t(config.labelKey, language)}
                </div>
              </div>

              {/* Status Icon Badge */}
              <div
                className={`
                  w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0
                  transition-all duration-300
                  ${status === 'none'
                    ? 'bg-life-bg3 border border-life-border2'
                    : status === 'alone'
                      ? 'bg-life-green/15 border border-life-green/40 text-life-green'
                      : 'bg-life-blue/15 border border-life-blue/40 text-life-blue'
                  }
                `}
              >
                <span className="text-sm">{config.icon}</span>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* ===== Quran Tracker ===== */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.4 }}
        className="rounded-xl p-4"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="flex items-center gap-2 mb-3">
          <BookOpen className="w-4 h-4 text-life-amber" />
          <span className="font-heading text-sm font-semibold text-life-amber">
            {t('prayer.quran', language)}
          </span>
        </div>

        <div className="flex gap-2 items-center">
          <input
            type="number"
            className="flex-1 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm focus:border-life-primary transition-colors"
            placeholder={t('prayer.pageCount', language)}
            value={quranInput}
            onChange={(e) => setQuranInput(e.target.value)}
            min={0}
            onKeyDown={(e) => e.key === 'Enter' && handleSaveQuran()}
          />
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleSaveQuran}
            className="px-4 py-2.5 bg-life-amber hover:bg-life-amber/90 text-black rounded-xl text-sm font-semibold transition-colors touch-target"
          >
            {t('prayer.save', language)}
          </motion.button>
        </div>

        {dailyLog.quranPages > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mt-3 flex items-center gap-2 bg-life-amber/10 border border-life-amber/20 rounded-xl px-3 py-2"
          >
            <span className="text-life-amber text-sm">✅</span>
            <span className="text-sm text-life-amber font-medium">
              {dailyLog.quranPages} {t('prayer.todayRead', language)}
            </span>
          </motion.div>
        )}
      </motion.div>

      {/* ===== Prayer Summary ===== */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6, duration: 0.4 }}
        className="rounded-xl p-4"
        style={{ backgroundColor: 'var(--life-bg3)' }}
      >
        <div className="flex items-center gap-2 mb-3">
          <BarChart3 className="w-4 h-4 text-life-text2" />
          <span className="font-heading text-sm font-semibold text-life-text2">
            {t('prayer.summary', language)}
          </span>
        </div>

        <div className="space-y-2">
          {PRAYERS.map((prayer) => {
            const status = dailyLog[prayer.key];
            const config = statusConfig[status];
            return (
              <div
                key={prayer.key}
                className="flex items-center justify-between py-2 px-3 bg-life-bg3/60 rounded-xl"
              >
                <span className="text-sm text-life-text flex items-center gap-2">
                  <span>{prayer.icon}</span>
                  <span className="font-body">{t(prayer.nameKey, language)}</span>
                </span>
                <span className={`text-xs font-medium ${config.color}`}>
                  {status === 'none'
                    ? t('prayer.notRead', language)
                    : `${config.icon} ${t(config.labelKey, language)}`
                  }
                </span>
              </div>
            );
          })}
        </div>

        <div className="mt-3 pt-3 border-t border-life-border flex justify-between items-center">
          <span className="text-xs text-life-text3">{t('prayer.completed', language)}</span>
          <div className="flex items-center gap-3">
            <span className="text-sm font-bold text-life-accent">
              {completedCount}/5
            </span>
            {jamaatCount > 0 && (
              <span className="text-xs text-life-blue bg-life-blue/10 border border-life-blue/20 px-2 py-0.5 rounded-full">
                🕌 {jamaatCount} {t('prayer.jamaat', language)}
              </span>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
