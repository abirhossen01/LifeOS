'use client';

import { useLifeOSStore, DefaultSkillConfig } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  GraduationCap, Star, Plus, Trash2, Clock, Play,
  Youtube, Lightbulb, Crown, Swords, X, Pencil, Check,
} from 'lucide-react';
import { fadeInUpScale, staggerContainer } from '@/lib/animations';

const INITIAL_DEFAULT_SKILLS: Omit<DefaultSkillConfig, 'id'>[] = [
  { name: 'SQL', color: '#06B6D4', icon: '🗃️' },
  { name: 'Python', color: '#22C55E', icon: '🐍' },
  { name: 'Power BI', color: '#F59E0B', icon: '📊' },
  { name: 'Data Analysis', color: '#7C3AED', icon: '🧠' },
];

const SKILL_ICONS = ['📘', '💻', '🧠', '🎨', '📊', '🔧', '📱', '🎯', '🚀', '💡', '📐', '🔬', '🗃️', '🐍', '📈', '🧩'];
const SKILL_COLORS = ['#06B6D4', '#22C55E', '#F59E0B', '#7C3AED', '#EF4444', '#EC4899', '#1DB88A', '#A78BFA', '#F0ABFC', '#FBBF24'];

// Animation variants imported from @/lib/animations

export default function SkillsPage() {
  const {
    skills, addSkill, updateSkill,
    customSkills, addCustomSkill, deleteCustomSkill, logCustomSkillTime,
    settings, incrementYT, updateChess,
    videoIdeas, addVideoIdea, deleteVideoIdea,
    language,
    defaultSkillConfigs, setDefaultSkillConfigs,
    addDefaultSkillConfig, updateDefaultSkillConfig, deleteDefaultSkillConfig,
  } = useLifeOSStore();

  const [ideaInput, setIdeaInput] = useState('');
  const [skillMinutes, setSkillMinutes] = useState<Record<string, string>>({});

  // Initialize default skills on first load
  useEffect(() => {
    if (defaultSkillConfigs.length === 0 && settings) {
      const initialConfigs: DefaultSkillConfig[] = INITIAL_DEFAULT_SKILLS.map((s, i) => ({
        id: `default_${i}_${Date.now()}`,
        ...s,
      }));
      setDefaultSkillConfigs(initialConfigs);
      // Persist to settings
      useLifeOSStore.getState().updateSettings({ defaultSkillConfigs: JSON.stringify(initialConfigs) });
    }
  }, [settings, defaultSkillConfigs.length, setDefaultSkillConfigs]);

  // Custom skill form
  const [showAddSkill, setShowAddSkill] = useState(false);
  const [newSkillName, setNewSkillName] = useState('');
  const [newSkillIcon, setNewSkillIcon] = useState('📘');
  const [newSkillColor, setNewSkillColor] = useState('#06B6D4');
  const [newSkillTarget, setNewSkillTarget] = useState('100');

  // Edit custom skill
  const [editingSkillId, setEditingSkillId] = useState<string | null>(null);
  const [editSkillName, setEditSkillName] = useState('');
  const [editSkillIcon, setEditSkillIcon] = useState('📘');
  const [editSkillColor, setEditSkillColor] = useState('#06B6D4');
  const [editSkillTarget, setEditSkillTarget] = useState('100');

  // Edit default skill
  const [editingDefaultId, setEditingDefaultId] = useState<string | null>(null);
  const [editDefaultName, setEditDefaultName] = useState('');
  const [editDefaultIcon, setEditDefaultIcon] = useState('📘');
  const [editDefaultColor, setEditDefaultColor] = useState('#06B6D4');

  // Add default skill form
  const [showAddDefaultSkill, setShowAddDefaultSkill] = useState(false);
  const [newDefaultName, setNewDefaultName] = useState('');
  const [newDefaultIcon, setNewDefaultIcon] = useState('📘');
  const [newDefaultColor, setNewDefaultColor] = useState('#06B6D4');

  // Custom skill time logging
  const [timeInputs, setTimeInputs] = useState<Record<string, string>>({});

  // Delete confirmation
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [deleteConfirmType, setDeleteConfirmType] = useState<'default' | 'custom' | null>(null);

  const handleLogSkill = async (skillName: string) => {
    const minutes = parseInt(skillMinutes[skillName] || '0');
    if (minutes <= 0) return;
    const existing = skills.find(s => s.skillName === skillName);
    if (existing) {
      await updateSkill(existing.id, existing.minutes + minutes, Math.min(existing.progress + 2, 100));
    } else {
      await addSkill(skillName, minutes, 2);
    }
    setSkillMinutes(prev => ({ ...prev, [skillName]: '' }));
  };

  const handleAddCustomSkill = async () => {
    if (!newSkillName.trim()) return;
    await addCustomSkill(newSkillName.trim(), newSkillIcon, newSkillColor, parseInt(newSkillTarget) || 100);
    setNewSkillName('');
    setNewSkillIcon('📘');
    setNewSkillColor('#06B6D4');
    setNewSkillTarget('100');
    setShowAddSkill(false);
  };

  const handleLogCustomTime = async (id: string) => {
    const minutes = parseInt(timeInputs[id] || '0');
    if (minutes <= 0) return;
    await logCustomSkillTime(id, minutes);
    setTimeInputs(prev => ({ ...prev, [id]: '' }));
  };

  const handleEditCustomSkill = async (id: string) => {
    try {
      const res = await fetch(`/api/custom-skills/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editSkillName,
          icon: editSkillIcon,
          color: editSkillColor,
          targetHours: parseInt(editSkillTarget) || 100,
        }),
      });
      if (res.ok) {
        const { customSkills } = useLifeOSStore.getState();
        useLifeOSStore.getState().setCustomSkills(
          customSkills.map(s => s.id === id ? { ...s, name: editSkillName, icon: editSkillIcon, color: editSkillColor, targetHours: parseInt(editSkillTarget) || 100 } : s)
        );
        setEditingSkillId(null);
      }
    } catch (error) {
      console.error('Failed to edit skill:', error);
    }
  };

  const startEditingSkill = (skill: typeof customSkills[0]) => {
    setEditingSkillId(skill.id);
    setEditSkillName(skill.name);
    setEditSkillIcon(skill.icon);
    setEditSkillColor(skill.color);
    setEditSkillTarget(String(skill.targetHours));
  };

  const startEditingDefaultSkill = (config: DefaultSkillConfig) => {
    setEditingDefaultId(config.id);
    setEditDefaultName(config.name);
    setEditDefaultIcon(config.icon);
    setEditDefaultColor(config.color);
  };

  const handleSaveDefaultSkill = async () => {
    if (!editingDefaultId || !editDefaultName.trim()) return;
    await updateDefaultSkillConfig(editingDefaultId, {
      name: editDefaultName.trim(),
      icon: editDefaultIcon,
      color: editDefaultColor,
    });
    setEditingDefaultId(null);
  };

  const handleAddDefaultSkill = async () => {
    if (!newDefaultName.trim()) return;
    await addDefaultSkillConfig(newDefaultName.trim(), newDefaultColor, newDefaultIcon);
    setNewDefaultName('');
    setNewDefaultIcon('📘');
    setNewDefaultColor('#06B6D4');
    setShowAddDefaultSkill(false);
  };

  const handleDeleteConfirm = async () => {
    if (!deleteConfirmId) return;
    if (deleteConfirmType === 'default') {
      await deleteDefaultSkillConfig(deleteConfirmId);
    } else if (deleteConfirmType === 'custom') {
      await deleteCustomSkill(deleteConfirmId);
    }
    setDeleteConfirmId(null);
    setDeleteConfirmType(null);
  };

  const handleAddIdea = async () => {
    if (!ideaInput.trim()) return;
    await addVideoIdea(ideaInput.trim());
    setIdeaInput('');
  };

  return (
    <motion.div
      className="space-y-4 pb-4"
      variants={staggerContainer}
      initial="hidden"
      animate="show"
    >
      {/* Page Title */}
      <motion.div variants={fadeInUpScale}>
        <h1 className="font-heading text-2xl sm:text-3xl font-bold text-life-text flex items-center gap-2.5">
          <GraduationCap className="w-6 h-6" />
          {t('skills.title', language)}
        </h1>
        <p className="text-sm text-life-text3 mt-1 font-body">{t('skills.subtitle', language)}</p>
      </motion.div>

      {/* ===== DELETE CONFIRMATION DIALOG ===== */}
      <AnimatePresence>
        {deleteConfirmId && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="rounded-2xl p-6 max-w-sm w-full mx-4"
              style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
            >
              <div className="text-center">
                <div className="w-14 h-14 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-4">
                  <Trash2 className="w-7 h-7 text-red-400" />
                </div>
                <h3 className="font-heading text-lg font-bold text-life-text mb-2">
                  {language === 'bn' ? 'মুছে ফেলতে চান?' : 'Delete this skill?'}
                </h3>
                <p className="text-sm text-life-text3 mb-5">
                  {language === 'bn'
                    ? 'এই স্কিল মুছে গেলে আর ফেরত পাওয়া যাবে না।'
                    : 'This action cannot be undone. The skill will be permanently deleted.'}
                </p>
                <div className="flex gap-3">
                  <button
                    onClick={() => { setDeleteConfirmId(null); setDeleteConfirmType(null); }}
                    className="flex-1 py-3 rounded-xl text-sm font-semibold border border-life-border text-life-text2 hover:bg-life-bg3 transition-colors"
                  >
                    {t('common.cancel', language)}
                  </button>
                  <button
                    onClick={handleDeleteConfirm}
                    className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl text-sm font-semibold transition-colors"
                  >
                    {language === 'bn' ? 'মুছুন' : 'Delete'}
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ===== DATA ANALYSIS SKILLS ===== */}
      <motion.div variants={fadeInUpScale} className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-life-secondary" />
              {t('skills.dataAnalysis', language)}
            </div>
            <motion.button
              onClick={() => setShowAddDefaultSkill(!showAddDefaultSkill)}
              className="text-xs text-life-primary hover:text-life-primary2 font-medium flex items-center gap-1 transition-colors"
              whileTap={{ scale: 0.95 }}
            >
              <Plus className="w-3.5 h-3.5" />
              {language === 'bn' ? 'স্কিল যোগ' : 'Add Skill'}
            </motion.button>
          </div>

          {/* Add Default Skill Form */}
          <AnimatePresence>
            {showAddDefaultSkill && (
              <motion.div
                className="rounded-xl p-4 mb-4 border border-life-primary/20"
                style={{ backgroundColor: 'var(--life-bg3)' }}
                initial={{ opacity: 0, height: 0, marginBottom: 0 }}
                animate={{ opacity: 1, height: 'auto', marginBottom: 16 }}
                exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                transition={{ duration: 0.3 }}
              >
                <input
                  className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary mb-3 font-body placeholder:text-life-text3"
                  placeholder={t('skills.skillName', language)}
                  value={newDefaultName}
                  onChange={(e) => setNewDefaultName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddDefaultSkill()}
                  autoFocus
                />

                {/* Icon Selector */}
                <div className="text-[11px] text-life-text3 mb-1.5">{t('skills.skillIcon', language)}</div>
                <div className="flex gap-1.5 flex-wrap mb-3">
                  {SKILL_ICONS.map(icon => (
                    <button
                      key={icon}
                      onClick={() => setNewDefaultIcon(icon)}
                      className={`w-9 h-9 rounded-lg border flex items-center justify-center text-base transition-all ${
                        newDefaultIcon === icon
                          ? 'border-life-primary bg-life-purple-bg scale-110'
                          : 'border-life-border hover:border-life-border2'
                      }`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>

                {/* Color Selector */}
                <div className="text-[11px] text-life-text3 mb-1.5">{t('skills.skillColor', language)}</div>
                <div className="flex gap-2 flex-wrap mb-3">
                  {SKILL_COLORS.map(color => (
                    <button
                      key={color}
                      onClick={() => setNewDefaultColor(color)}
                      className={`w-8 h-8 rounded-lg border-2 transition-all ${
                        newDefaultColor === color ? 'border-white scale-110 shadow-lg' : 'border-transparent'
                      }`}
                      style={{ background: color }}
                    />
                  ))}
                </div>

                <div className="flex gap-2">
                  <motion.button
                    onClick={handleAddDefaultSkill}
                    className="flex-1 py-2.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-xs font-semibold transition-colors"
                    whileTap={{ scale: 0.97 }}
                  >
                    {t('skills.add', language)}
                  </motion.button>
                  <button
                    onClick={() => setShowAddDefaultSkill(false)}
                    className="px-4 py-2.5 border border-life-border text-life-text2 rounded-xl text-xs hover:bg-life-bg4 transition-colors"
                  >
                    {t('common.cancel', language)}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="space-y-4">
            {defaultSkillConfigs.length === 0 && !showAddDefaultSkill ? (
              <div className="text-center text-life-text3 text-xs py-6 border border-dashed border-life-border rounded-xl">
                {language === 'bn' ? 'কোর্স যোগ করুন' : 'Add your courses'}
              </div>
            ) : (
              defaultSkillConfigs.map((config) => {
                const skill = skills.find(s => s.skillName === config.name);
                const progress = skill?.progress || 0;
                const minutes = skill?.minutes || 0;

                if (editingDefaultId === config.id) {
                  // ===== Edit Mode for Default Skill =====
                  return (
                    <motion.div
                      key={config.id}
                      className="rounded-xl p-4 border border-life-primary/20"
                      style={{ backgroundColor: 'var(--life-bg3)' }}
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                    >
                      <div className="space-y-3">
                        <input
                          className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary font-body placeholder:text-life-text3"
                          placeholder={t('skills.skillName', language)}
                          value={editDefaultName}
                          onChange={(e) => setEditDefaultName(e.target.value)}
                          autoFocus
                        />

                        {/* Icon Selector */}
                        <div className="text-[11px] text-life-text3 mb-1.5">{t('skills.skillIcon', language)}</div>
                        <div className="flex gap-1.5 flex-wrap">
                          {SKILL_ICONS.map(icon => (
                            <button
                              key={icon}
                              onClick={() => setEditDefaultIcon(icon)}
                              className={`w-8 h-8 rounded-lg border flex items-center justify-center text-sm transition-all ${
                                editDefaultIcon === icon
                                  ? 'border-life-primary bg-life-purple-bg scale-110'
                                  : 'border-life-border hover:border-life-border2'
                              }`}
                            >
                              {icon}
                            </button>
                          ))}
                        </div>

                        {/* Color Selector */}
                        <div className="text-[11px] text-life-text3 mb-1.5">{t('skills.skillColor', language)}</div>
                        <div className="flex gap-2 flex-wrap">
                          {SKILL_COLORS.map(color => (
                            <button
                              key={color}
                              onClick={() => setEditDefaultColor(color)}
                              className={`w-7 h-7 rounded-lg border-2 transition-all ${
                                editDefaultColor === color ? 'border-white scale-110 shadow-lg' : 'border-transparent'
                              }`}
                              style={{ background: color }}
                            />
                          ))}
                        </div>

                        <div className="flex gap-2">
                          <motion.button
                            onClick={handleSaveDefaultSkill}
                            className="flex-1 py-2.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
                            whileTap={{ scale: 0.97 }}
                          >
                            <Check className="w-3.5 h-3.5" />
                            {t('common.save', language)}
                          </motion.button>
                          <button
                            onClick={() => setEditingDefaultId(null)}
                            className="px-4 py-2.5 border border-life-border text-life-text2 rounded-xl text-xs hover:bg-life-bg4 transition-colors"
                          >
                            {t('common.cancel', language)}
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  );
                }

                // ===== Normal Display Mode for Default Skill =====
                return (
                  <div key={config.id}>
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-8 h-8 rounded-lg flex items-center justify-center text-base border"
                          style={{
                            background: `${config.color}15`,
                            borderColor: `${config.color}40`,
                          }}
                        >
                          {config.icon}
                        </div>
                        <span className="text-sm font-medium text-life-text">{config.name}</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px] text-life-text3">
                          {progress}% • {minutes} {t('skills.minutes', language)}
                        </span>
                        <button
                          onClick={() => startEditingDefaultSkill(config)}
                          className="text-life-text3 hover:text-life-primary transition-colors p-0.5"
                          title={language === 'bn' ? 'সম্পাদনা' : 'Edit'}
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => { setDeleteConfirmId(config.id); setDeleteConfirmType('default'); }}
                          className="text-life-text3 hover:text-life-coral transition-colors p-0.5"
                          title={language === 'bn' ? 'মুছুন' : 'Delete'}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                    <div className="h-2 bg-life-bg3 rounded-full overflow-hidden mb-2">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ background: config.color }}
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        transition={{ duration: 0.8, ease: 'easeOut' }}
                      />
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        className="flex-1 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2 text-xs outline-none focus:border-life-primary font-body placeholder:text-life-text3"
                        placeholder={t('skills.minutes', language)}
                        min={0}
                        value={skillMinutes[config.name] || ''}
                        onChange={(e) => setSkillMinutes(prev => ({ ...prev, [config.name]: e.target.value }))}
                      />
                      <motion.button
                        onClick={() => handleLogSkill(config.name)}
                        className="px-3 py-2 bg-life-bg3 border border-life-border2 text-life-text2 rounded-xl text-xs font-medium hover:bg-life-bg4 transition-colors flex items-center gap-1"
                        whileTap={{ scale: 0.95 }}
                      >
                        <Play className="w-3 h-3" />
                        {t('skills.log', language)}
                      </motion.button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </motion.div>

      {/* ===== CUSTOM SKILLS ===== */}
      <motion.div variants={fadeInUpScale} className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="absolute bottom-0 left-0 w-24 h-24 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide flex items-center gap-2">
              <Star className="w-4 h-4 text-life-primary" />
              {t('skills.customSkills', language)}
            </div>
            <motion.button
              onClick={() => setShowAddSkill(!showAddSkill)}
              className="text-xs text-life-primary hover:text-life-primary2 font-medium flex items-center gap-1 transition-colors"
              whileTap={{ scale: 0.95 }}
            >
              <Plus className="w-3.5 h-3.5" />
              {t('skills.addSkill', language)}
            </motion.button>
          </div>

          {/* Add Custom Skill Form */}
          <AnimatePresence>
            {showAddSkill && (
              <motion.div
                className="rounded-xl p-4 mb-4 border border-life-primary/20"
                style={{ backgroundColor: 'var(--life-bg3)' }}
                initial={{ opacity: 0, height: 0, marginBottom: 0 }}
                animate={{ opacity: 1, height: 'auto', marginBottom: 16 }}
                exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                transition={{ duration: 0.3 }}
              >
                <input
                  className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary mb-3 font-body placeholder:text-life-text3"
                  placeholder={t('skills.skillName', language)}
                  value={newSkillName}
                  onChange={(e) => setNewSkillName(e.target.value)}
                />

                {/* Icon Selector */}
                <div className="text-[11px] text-life-text3 mb-1.5">{t('skills.skillIcon', language)}</div>
                <div className="flex gap-1.5 flex-wrap mb-3">
                  {SKILL_ICONS.map(icon => (
                    <button
                      key={icon}
                      onClick={() => setNewSkillIcon(icon)}
                      className={`w-9 h-9 rounded-lg border flex items-center justify-center text-base transition-all ${
                        newSkillIcon === icon
                          ? 'border-life-primary bg-life-purple-bg scale-110'
                          : 'border-life-border hover:border-life-border2'
                      }`}
                    >
                      {icon}
                    </button>
                  ))}
                </div>

                {/* Color Selector */}
                <div className="text-[11px] text-life-text3 mb-1.5">{t('skills.skillColor', language)}</div>
                <div className="flex gap-2 flex-wrap mb-3">
                  {SKILL_COLORS.map(color => (
                    <button
                      key={color}
                      onClick={() => setNewSkillColor(color)}
                      className={`w-8 h-8 rounded-lg border-2 transition-all ${
                        newSkillColor === color ? 'border-white scale-110 shadow-lg' : 'border-transparent'
                      }`}
                      style={{ background: color }}
                    />
                  ))}
                </div>

                {/* Target Hours */}
                <div className="flex gap-2 items-center mb-3">
                  <span className="text-[11px] text-life-text3">{t('skills.targetHours', language)}:</span>
                  <input
                    type="number"
                    className="w-24 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2 text-xs outline-none focus:border-life-primary font-body"
                    value={newSkillTarget}
                    onChange={(e) => setNewSkillTarget(e.target.value)}
                  />
                </div>

                <div className="flex gap-2">
                  <motion.button
                    onClick={handleAddCustomSkill}
                    className="flex-1 py-2.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-xs font-semibold transition-colors"
                    whileTap={{ scale: 0.97 }}
                  >
                    {t('skills.add', language)}
                  </motion.button>
                  <button
                    onClick={() => setShowAddSkill(false)}
                    className="px-4 py-2.5 border border-life-border text-life-text2 rounded-xl text-xs hover:bg-life-bg4 transition-colors"
                  >
                    {t('common.cancel', language)}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Custom Skills List */}
          {customSkills.length === 0 && !showAddSkill ? (
            <div className="text-center text-life-text3 text-xs py-6 border border-dashed border-life-border rounded-xl">
              {language === 'bn' ? 'কাস্টম স্কিল যোগ করুন' : 'Add your custom skills'}
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto life-scrollbar">
              {customSkills.map((skill, i) => (
                <motion.div
                  key={skill.id}
                  className="rounded-xl p-3.5"
                  style={{ backgroundColor: 'var(--life-bg3)' }}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                >
                  {editingSkillId === skill.id ? (
                    /* ===== Edit Form ===== */
                    <div className="space-y-3">
                      <input
                        className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary font-body placeholder:text-life-text3"
                        placeholder={t('skills.skillName', language)}
                        value={editSkillName}
                        onChange={(e) => setEditSkillName(e.target.value)}
                        autoFocus
                      />

                      {/* Icon Selector */}
                      <div className="text-[11px] text-life-text3 mb-1.5">{t('skills.skillIcon', language)}</div>
                      <div className="flex gap-1.5 flex-wrap">
                        {SKILL_ICONS.map(icon => (
                          <button
                            key={icon}
                            onClick={() => setEditSkillIcon(icon)}
                            className={`w-8 h-8 rounded-lg border flex items-center justify-center text-sm transition-all ${
                              editSkillIcon === icon
                                ? 'border-life-primary bg-life-purple-bg scale-110'
                                : 'border-life-border hover:border-life-border2'
                            }`}
                          >
                            {icon}
                          </button>
                        ))}
                      </div>

                      {/* Color Selector */}
                      <div className="text-[11px] text-life-text3 mb-1.5">{t('skills.skillColor', language)}</div>
                      <div className="flex gap-2 flex-wrap">
                        {SKILL_COLORS.map(color => (
                          <button
                            key={color}
                            onClick={() => setEditSkillColor(color)}
                            className={`w-7 h-7 rounded-lg border-2 transition-all ${
                              editSkillColor === color ? 'border-white scale-110 shadow-lg' : 'border-transparent'
                            }`}
                            style={{ background: color }}
                          />
                        ))}
                      </div>

                      {/* Target Hours */}
                      <div className="flex gap-2 items-center">
                        <span className="text-[11px] text-life-text3">{t('skills.targetHours', language)}:</span>
                        <input
                          type="number"
                          className="w-24 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2 text-xs outline-none focus:border-life-primary font-body"
                          value={editSkillTarget}
                          onChange={(e) => setEditSkillTarget(e.target.value)}
                        />
                      </div>

                      <div className="flex gap-2">
                        <motion.button
                          onClick={() => handleEditCustomSkill(skill.id)}
                          className="flex-1 py-2.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
                          whileTap={{ scale: 0.97 }}
                        >
                          <Check className="w-3.5 h-3.5" />
                          {t('common.save', language)}
                        </motion.button>
                        <button
                          onClick={() => setEditingSkillId(null)}
                          className="px-4 py-2.5 border border-life-border text-life-text2 rounded-xl text-xs hover:bg-life-bg4 transition-colors"
                        >
                          {t('common.cancel', language)}
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* ===== Normal Skill Display ===== */
                    <>
                      <div className="flex items-center gap-3 mb-2.5">
                        <div
                          className="w-10 h-10 rounded-lg flex items-center justify-center text-xl border"
                          style={{
                            background: `${skill.color}15`,
                            borderColor: `${skill.color}40`,
                          }}
                        >
                          {skill.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium text-life-text">{skill.name}</span>
                            <span className="text-[11px] text-life-text3">
                              {skill.progress}% • {skill.loggedHours}/{skill.targetHours}h
                            </span>
                          </div>
                          <div className="h-2 bg-life-bg3 rounded-full overflow-hidden mt-1.5">
                            <motion.div
                              className="h-full rounded-full"
                              style={{ background: skill.color }}
                              initial={{ width: 0 }}
                              animate={{ width: `${skill.progress}%` }}
                              transition={{ duration: 0.8, ease: 'easeOut' }}
                            />
                          </div>
                        </div>
                        <button
                          onClick={() => startEditingSkill(skill)}
                          className="text-life-text3 hover:text-life-primary transition-colors p-1"
                          title={language === 'bn' ? 'সম্পাদনা' : 'Edit'}
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => { setDeleteConfirmId(skill.id); setDeleteConfirmType('custom'); }}
                          className="text-life-text3 hover:text-life-coral transition-colors p-1"
                          title={language === 'bn' ? 'মুছুন' : 'Delete'}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="flex gap-2">
                        <input
                          type="number"
                          className="flex-1 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2 text-xs outline-none focus:border-life-primary font-body placeholder:text-life-text3"
                          placeholder={t('skills.minutes', language)}
                          min={0}
                          value={timeInputs[skill.id] || ''}
                          onChange={(e) => setTimeInputs(prev => ({ ...prev, [skill.id]: e.target.value }))}
                        />
                        <motion.button
                          onClick={() => handleLogCustomTime(skill.id)}
                          className="px-3 py-2 bg-life-bg3 border border-life-border2 text-life-text2 rounded-xl text-xs font-medium hover:bg-life-bg4 transition-colors flex items-center gap-1"
                          whileTap={{ scale: 0.95 }}
                        >
                          <Play className="w-3 h-3" />
                          {t('skills.log', language)}
                        </motion.button>
                      </div>
                    </>
                  )}
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </motion.div>

      {/* ===== YOUTUBE TRACKER ===== */}
      <motion.div variants={fadeInUpScale} className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="absolute top-0 left-0 w-24 h-24 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-4 flex items-center gap-2">
            <Youtube className="w-4 h-4 text-life-coral" />
            {language === 'bn' ? 'ইউটিউব ট্র্যাকার' : 'YouTube Tracker'}
          </div>

          {/* Channel Cards */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="rounded-xl p-3.5 text-center border border-life-coral/20" style={{ backgroundColor: 'var(--life-bg3)' }}>
              <div className="text-[11px] text-life-text3 mb-2">Learn to Make</div>
              <div className="text-3xl font-bold font-heading text-life-coral">{settings?.ytVideos1 || 0}</div>
              <div className="text-[10px] text-life-text3 mt-1">
                {language === 'bn' ? 'ভিডিও আপলোড' : 'Videos'}
              </div>
              <motion.button
                onClick={() => incrementYT(1)}
                className="mt-2 w-full px-2 py-2 border border-life-border2 text-life-text2 rounded-lg text-xs hover:bg-life-bg4 transition-colors flex items-center justify-center gap-1"
                whileTap={{ scale: 0.95 }}
              >
                <Plus className="w-3 h-3" />
                {language === 'bn' ? 'ভিডিও' : 'Video'}
              </motion.button>
            </div>
            <div className="rounded-xl p-3.5 text-center border border-life-blue/20" style={{ backgroundColor: 'var(--life-bg3)' }}>
              <div className="text-[11px] text-life-text3 mb-2">Learn with AI</div>
              <div className="text-3xl font-bold font-heading text-life-blue">{settings?.ytVideos2 || 0}</div>
              <div className="text-[10px] text-life-text3 mt-1">
                {language === 'bn' ? 'ভিডিও আপলোড' : 'Videos'}
              </div>
              <motion.button
                onClick={() => incrementYT(2)}
                className="mt-2 w-full px-2 py-2 border border-life-border2 text-life-text2 rounded-lg text-xs hover:bg-life-bg4 transition-colors flex items-center justify-center gap-1"
                whileTap={{ scale: 0.95 }}
              >
                <Plus className="w-3 h-3" />
                {language === 'bn' ? 'ভিডিও' : 'Video'}
              </motion.button>
            </div>
          </div>

          {/* Video Idea Bank */}
          <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-3 flex items-center gap-2">
            <Lightbulb className="w-4 h-4 text-life-amber" />
            {language === 'bn' ? 'ভিডিও আইডিয়া ব্যাংক' : 'Video Idea Bank'}
          </div>

          {videoIdeas.length > 0 && (
            <div className="space-y-1.5 mb-3 max-h-40 overflow-y-auto life-scrollbar">
              {videoIdeas.map((idea) => (
                <div key={idea.id} className="flex items-center gap-2 py-1.5 px-2 rounded-lg group" style={{ backgroundColor: 'var(--life-bg3)' }}>
                  <span className="flex-1 text-[13px] text-life-text truncate">• {idea.title}</span>
                  <button
                    onClick={() => deleteVideoIdea(idea.id)}
                    className="text-life-text3 hover:text-life-coral transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            <input
              className="flex-1 bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm outline-none focus:border-life-primary font-body placeholder:text-life-text3"
              placeholder={language === 'bn' ? 'নতুন ভিডিও আইডিয়া...' : 'New video idea...'}
              value={ideaInput}
              onChange={(e) => setIdeaInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddIdea()}
            />
            <motion.button
              onClick={handleAddIdea}
              className="px-4 py-2.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-xs font-semibold transition-colors"
              whileTap={{ scale: 0.95 }}
            >
              {t('common.add', language)}
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* ===== CHESS TRACKER ===== */}
      <motion.div variants={fadeInUpScale} className="rounded-xl p-4 relative overflow-hidden" style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}>
        <div className="absolute bottom-0 right-0 w-24 h-24 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold text-life-text2 uppercase tracking-wide mb-4 flex items-center gap-2">
            <Swords className="w-4 h-4 text-life-primary" />
            {language === 'bn' ? 'চেস ট্র্যাকার' : 'Chess Tracker'}
          </div>

          {/* Rating & Games */}
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className="rounded-xl p-3.5" style={{ backgroundColor: 'var(--life-bg3)' }}>
              <div className="text-[11px] text-life-text3 mb-1.5 flex items-center gap-1">
                <Crown className="w-3 h-3" />
                {language === 'bn' ? 'বর্তমান রেটিং' : 'Current Rating'}
              </div>
              <input
                type="number"
                className="w-full bg-transparent text-life-text text-xl font-bold font-heading outline-none text-center"
                value={settings?.chessRating || 1200}
                onChange={(e) => updateChess('chessRating', parseInt(e.target.value) || 1200)}
              />
            </div>
            <div className="rounded-xl p-3.5" style={{ backgroundColor: 'var(--life-bg3)' }}>
              <div className="text-[11px] text-life-text3 mb-1.5 flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {language === 'bn' ? 'আজকে খেলেছি' : 'Games Today'}
              </div>
              <input
                type="number"
                className="w-full bg-transparent text-life-text text-xl font-bold font-heading outline-none text-center"
                value={settings?.chessGames || 0}
                onChange={(e) => updateChess('chessGames', parseInt(e.target.value) || 0)}
              />
            </div>
          </div>

          {/* W/L/D Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-xl p-3 text-center border border-life-green/20" style={{ backgroundColor: 'var(--life-bg3)' }}>
              <div className="text-2xl font-bold font-heading text-life-green">{settings?.chessWins || 0}</div>
              <div className="text-[10px] text-life-text3 mt-0.5">{language === 'bn' ? 'জয়' : 'Wins'}</div>
              <motion.button
                onClick={() => updateChess('chessWins', (settings?.chessWins || 0) + 1)}
                className="mt-1.5 w-full px-2 py-1.5 border border-life-border2 text-life-text2 rounded-lg text-xs hover:bg-life-bg4 transition-colors"
                whileTap={{ scale: 0.9 }}
              >
                +
              </motion.button>
            </div>
            <div className="rounded-xl p-3 text-center border border-life-coral/20" style={{ backgroundColor: 'var(--life-bg3)' }}>
              <div className="text-2xl font-bold font-heading text-life-coral">{settings?.chessLosses || 0}</div>
              <div className="text-[10px] text-life-text3 mt-0.5">{language === 'bn' ? 'হার' : 'Losses'}</div>
              <motion.button
                onClick={() => updateChess('chessLosses', (settings?.chessLosses || 0) + 1)}
                className="mt-1.5 w-full px-2 py-1.5 border border-life-border2 text-life-text2 rounded-lg text-xs hover:bg-life-bg4 transition-colors"
                whileTap={{ scale: 0.9 }}
              >
                +
              </motion.button>
            </div>
            <div className="rounded-xl p-3 text-center border border-life-amber/20" style={{ backgroundColor: 'var(--life-bg3)' }}>
              <div className="text-2xl font-bold font-heading text-life-amber">{settings?.chessDraws || 0}</div>
              <div className="text-[10px] text-life-text3 mt-0.5">{language === 'bn' ? 'ড্র' : 'Draws'}</div>
              <motion.button
                onClick={() => updateChess('chessDraws', (settings?.chessDraws || 0) + 1)}
                className="mt-1.5 w-full px-2 py-1.5 border border-life-border2 text-life-text2 rounded-lg text-xs hover:bg-life-bg4 transition-colors"
                whileTap={{ scale: 0.9 }}
              >
                +
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
