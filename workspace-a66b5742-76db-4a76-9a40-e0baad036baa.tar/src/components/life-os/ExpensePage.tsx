'use client';

import { useLifeOSStore, ExpenseCategory } from '@/lib/store';
import { t } from '@/lib/i18n';
import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { Wallet, PlusCircle, Receipt, Banknote, CircleDollarSign } from 'lucide-react';

const EXPENSE_CATEGORIES: { value: ExpenseCategory; labelKey: string; color: string }[] = [
  { value: 'food', labelKey: 'expense.food', color: '#EF4444' },
  { value: 'transport', labelKey: 'expense.transport', color: '#06B6D4' },
  { value: 'study', labelKey: 'expense.study', color: '#7C3AED' },
  { value: 'health', labelKey: 'expense.health', color: '#22C55E' },
  { value: 'entertainment', labelKey: 'expense.entertainment', color: '#F59E0B' },
  { value: 'other', labelKey: 'expense.other', color: '#94A3B8' },
];

export default function ExpensePage() {
  const { dailyLog, expenses, incomes, addExpense, deleteExpense, addIncome, updateSettings, language } = useLifeOSStore();
  const [expName, setExpName] = useState('');
  const [expAmount, setExpAmount] = useState('');
  const [expCategory, setExpCategory] = useState<ExpenseCategory>('food');
  const [incSource, setIncSource] = useState('');
  const [incAmount, setIncAmount] = useState('');

  if (!dailyLog) return null;

  const budget = dailyLog.dailyBudget;
  const budgetPercent = budget > 0 ? Math.min((dailyLog.totalExpense / budget) * 100, 100) : 0;

  // Budget bar gradient: green → amber → red based on % spent
  const getBudgetGradient = () => {
    if (budgetPercent > 80) return 'from-red-500 to-red-600';
    if (budgetPercent > 50) return 'from-amber-500 to-amber-600';
    return 'from-green-500 to-green-600';
  };

  const totalIncome = incomes.reduce((sum, i) => sum + i.amount, 0);

  const getCategoryInfo = (cat: ExpenseCategory) => {
    return EXPENSE_CATEGORIES.find((c) => c.value === cat) || EXPENSE_CATEGORIES[5];
  };

  const handleAddExpense = async () => {
    if (!expName.trim() || !expAmount) return;
    await addExpense(expName.trim(), parseInt(expAmount), expCategory);
    setExpName('');
    setExpAmount('');
  };

  const handleAddIncome = async () => {
    if (!incSource.trim() || !incAmount) return;
    await addIncome(incSource.trim(), parseInt(incAmount));
    setIncSource('');
    setIncAmount('');
  };

  return (
    <div className="space-y-4">
      {/* ===== Page Header ===== */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex items-center gap-3"
      >
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}>
          <Wallet className="w-5 h-5" />
        </div>
        <div>
          <h2 className="font-heading text-xl font-bold text-life-text">
            {t('expense.title', language)}
          </h2>
          <p className="text-xs text-life-text3 mt-0.5">
            {t('expense.subtitle', language)}
          </p>
        </div>
      </motion.div>

      {/* ===== Total Expense Card ===== */}
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ delay: 0.1, duration: 0.4 }}
        className="rounded-xl p-5 text-center"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="text-xs text-life-text3 uppercase tracking-wider mb-1 font-heading">
          {t('expense.todayTotal', language)}
        </div>
        <motion.div
          key={dailyLog.totalExpense}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
          className="text-4xl font-bold text-life-coral font-heading"
        >
          ৳{dailyLog.totalExpense}
        </motion.div>

        {/* Budget Bar */}
        <div className="mt-4 flex items-center gap-3">
          <div className="text-[11px] text-life-text3 whitespace-nowrap">
            {t('expense.dailyBudget', language)}
          </div>
          <input
            type="number"
            className="bg-life-bg3 border border-life-border text-life-text rounded-lg px-2.5 py-1.5 text-sm focus:border-life-primary w-[90px] transition-colors"
            value={dailyLog.dailyBudget}
            onChange={(e) => {
              const val = parseInt(e.target.value) || 500;
              updateSettings({ dailyBudget: val });
              // Also update current dailyLog budget for immediate UI feedback
              if (dailyLog) {
                fetch(`/api/daily-log/${dailyLog.id}`, {
                  method: 'PATCH',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ dailyBudget: val }),
                });
                useLifeOSStore.getState().setDailyLog({ ...dailyLog, dailyBudget: val });
              }
            }}
          />
          <div className="flex-1">
            <div className="h-2 bg-life-bg3 rounded-full overflow-hidden">
              <motion.div
                className={`h-full rounded-full bg-gradient-to-r ${getBudgetGradient()}`}
                initial={{ width: 0 }}
                animate={{ width: `${budgetPercent}%` }}
                transition={{ duration: 0.6, ease: 'easeOut' }}
              />
            </div>
          </div>
          <span className="text-xs text-life-text3 font-mono min-w-[32px] text-right">
            {Math.round(budgetPercent)}%
          </span>
        </div>
      </motion.div>

      {/* ===== Add Expense ===== */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.4 }}
        className="rounded-xl p-4"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="flex items-center gap-2 mb-3">
          <PlusCircle className="w-4 h-4 text-life-text2" />
          <span className="font-heading text-sm font-semibold text-life-text2">
            {t('expense.addNew', language)}
          </span>
        </div>

        <input
          className="w-full bg-life-bg3 border border-life-border text-life-text rounded-xl px-3.5 py-2.5 text-sm focus:border-life-primary mb-2 transition-colors"
          placeholder={t('expense.whatSpent', language)}
          value={expName}
          onChange={(e) => setExpName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleAddExpense()}
        />

        <div className="flex gap-2 mb-3">
          <input
            type="number"
            className="flex-1 min-w-[100px] bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm focus:border-life-primary transition-colors"
            placeholder={t('expense.amount', language)}
            value={expAmount}
            onChange={(e) => setExpAmount(e.target.value)}
            min={0}
          />
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleAddExpense}
            className="px-4 py-2.5 bg-life-primary hover:bg-life-primary/90 text-white rounded-xl text-sm font-semibold transition-colors touch-target"
          >
            {t('expense.add', language)}
          </motion.button>
        </div>

        {/* Category Selector Pills */}
        <div className="flex flex-wrap gap-1.5">
          {EXPENSE_CATEGORIES.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setExpCategory(cat.value)}
              className={`
                px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all duration-200 touch-target
                ${expCategory === cat.value
                  ? 'text-white'
                  : 'bg-life-bg3 text-life-text3 border border-life-border hover:border-life-border2'
                }
              `}
              style={expCategory === cat.value ? { background: cat.color } : undefined}
            >
              <span
                className="inline-block w-1.5 h-1.5 rounded-full mr-1"
                style={{ background: expCategory === cat.value ? '#fff' : cat.color }}
              />
              {t(cat.labelKey, language)}
            </button>
          ))}
        </div>
      </motion.div>

      {/* ===== Expense List ===== */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.4 }}
        className="space-y-2"
      >
        <div className="flex items-center gap-2 mb-1">
          <Receipt className="w-4 h-4 text-life-text2" />
          <span className="font-heading text-sm font-semibold text-life-text2">
            {t('expense.list', language)}
          </span>
        </div>

        <AnimatePresence mode="popLayout">
          {expenses.length === 0 ? (
            <motion.div
              key="empty"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="rounded-xl p-6 border-2 border-dashed border-life-border2 flex flex-col items-center gap-2"
              style={{ backgroundColor: 'var(--life-bg3)' }}
            >
              <CircleDollarSign className="w-8 h-8 text-life-text3 opacity-40" />
              <p className="text-sm text-life-text3 text-center">{t('expense.noExpenses', language)}</p>
            </motion.div>
          ) : (
            expenses.map((expense) => {
              const catInfo = getCategoryInfo(expense.category);
              return (
                <motion.div
                  key={expense.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20, scale: 0.95 }}
                  transition={{
                    layout: { type: 'spring', stiffness: 400, damping: 30 },
                    opacity: { duration: 0.2 },
                    x: { duration: 0.3 },
                  }}
                  className="rounded-xl p-4 flex items-center gap-3"
                  style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
                >
                  {/* Category Color Dot */}
                  <div
                    className="w-3 h-3 rounded-full flex-shrink-0"
                    style={{ background: catInfo.color }}
                  />

                  {/* Name + Amount */}
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-life-text truncate">{expense.name}</div>
                    <div className="text-[10px] text-life-text3">{t(catInfo.labelKey, language)}</div>
                  </div>

                  {/* Amount */}
                  <span className="text-sm font-bold text-life-coral flex-shrink-0 font-heading">
                    ৳{expense.amount}
                  </span>

                  {/* Delete Button */}
                  <motion.button
                    whileTap={{ scale: 0.85 }}
                    onClick={() => deleteExpense(expense.id)}
                    className="text-life-text3 hover:text-life-coral text-sm transition-colors touch-target px-1"
                    aria-label={t('common.delete', language)}
                  >
                    ×
                  </motion.button>
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </motion.div>

      {/* ===== Income Section ===== */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.4 }}
        className="rounded-xl p-4"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="flex items-center gap-2 mb-3">
          <Banknote className="w-4 h-4 text-life-green" />
          <span className="font-heading text-sm font-semibold text-life-green">
            {t('expense.incomeLog', language)}
          </span>
        </div>

        <div className="flex gap-2 mb-3">
          <input
            className="flex-1 min-w-[120px] bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm focus:border-life-primary transition-colors"
            placeholder={t('expense.incomeSource', language)}
            value={incSource}
            onChange={(e) => setIncSource(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddIncome()}
          />
          <input
            type="number"
            className="w-[100px] bg-life-bg3 border border-life-border text-life-text rounded-xl px-3 py-2.5 text-sm focus:border-life-primary transition-colors"
            placeholder={t('expense.taka', language)}
            value={incAmount}
            onChange={(e) => setIncAmount(e.target.value)}
            min={0}
          />
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleAddIncome}
            className="px-4 py-2.5 bg-life-green hover:bg-life-green/90 text-white rounded-xl text-sm font-semibold transition-colors touch-target"
          >
            {t('common.add', language)}
          </motion.button>
        </div>

        {/* Income List */}
        <AnimatePresence>
          {incomes.map((income) => (
            <motion.div
              key={income.id}
              layout
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="flex items-center gap-2.5 px-3 py-2 bg-life-bg3/60 rounded-xl mb-1.5"
            >
              <span className="flex-1 text-sm text-life-text">{income.source}</span>
              <span className="text-sm font-semibold text-life-green">৳{income.amount}</span>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Total Income */}
        {totalIncome > 0 && (
          <div className="flex justify-between mt-3 pt-3 border-t border-life-border items-center">
            <span className="text-xs text-life-text2">{t('expense.totalIncome', language)}</span>
            <span className="text-sm font-bold text-life-green font-heading">৳{totalIncome}</span>
          </div>
        )}
      </motion.div>
    </div>
  );
}
