'use client';

import { useLifeOSStore, ThemeName, FontSize } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Settings as SettingsIcon, Palette, Type, Globe, Sliders,
  Check, Sparkles, Heart, Info, Save, Cog
} from 'lucide-react';
import { fadeInUp, staggerContainer } from '@/lib/animations';

const THEMES: { value: ThemeName; labelKey: string; gradient: string; icon: string }[] = [
  { value: 'dashboard', labelKey: 'settings.themeDashboard', gradient: 'from-[#1E1E1E] to-[#333333]', icon: '📊' },
  { value: 'dark-gold', labelKey: 'settings.themeDarkGold', gradient: 'from-[#0B1020] to-[#243049]', icon: '🌙' },
  { value: 'dark-emerald', labelKey: 'settings.themeDarkEmerald', gradient: 'from-[#051510] to-[#1B3D2B]', icon: '🌿' },
  { value: 'dark-midnight', labelKey: 'settings.themeDarkMidnight', gradient: 'from-[#0A0A1A] to-[#222260]', icon: '🌌' },
  { value: 'light', labelKey: 'settings.themeLight', gradient: 'from-[#F8FAFC] to-[#E2E8F0]', icon: '☀️' },
  { value: 'cyberpunk', labelKey: 'settings.themeCyberpunk', gradient: 'from-[#0A0014] to-[#25004A]', icon: '🟣' },
];

const FONT_SIZES: { value: FontSize; labelKey: string }[] = [
  { value: 'small', labelKey: 'settings.fontSizeSmall' },
  { value: 'medium', labelKey: 'settings.fontSizeMedium' },
  { value: 'large', labelKey: 'settings.fontSizeLarge' },
  { value: 'xlarge', labelKey: 'settings.fontSizeXLarge' },
];

const FONT_SIZE_SAMPLES: Record<FontSize, string> = {
  small: 'text-sm',
  medium: 'text-base',
  large: 'text-lg',
  xlarge: 'text-xl',
};

export default function SettingsPage() {
  const { theme, setTheme, fontSize, setFontSize, language, setLanguage, settings, updateSettings, xp, level } = useLifeOSStore();
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    await updateSettings({
      theme,
      fontSize,
      language,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const xpForNextLevel = level * 100;
  const currentLevelXp = (level - 1) * 100;
  const xpProgress = xpForNextLevel > currentLevelXp
    ? ((xp - currentLevelXp) / (xpForNextLevel - currentLevelXp)) * 100
    : 0;

  return (
    <motion.div
      className="space-y-5 pb-4"
      variants={staggerContainer}
      initial="hidden"
      animate="show"
    >
      {/* ===== Page Header ===== */}
      <motion.div variants={fadeInUp} className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}
        >
          <Cog className="w-5 h-5" />
        </div>
        <div>
          <h1 className="font-heading text-xl font-bold" style={{ color: 'var(--life-text)' }}>{t('settings.title', language)}</h1>
          <p className="text-xs" style={{ color: 'var(--life-text3)' }}>{t('settings.subtitle', language)}</p>
        </div>
      </motion.div>

      {/* ===== Appearance Section ===== */}
      <motion.div
        variants={fadeInUp}
        className="rounded-xl p-5 relative overflow-hidden"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold uppercase tracking-wide mb-5 flex items-center gap-2" style={{ color: 'var(--life-text2)' }}>
            <Palette className="w-4 h-4" style={{ color: 'var(--life-accent)' }} />
            {t('settings.appearance', language)}
          </div>

          {/* Theme Selection */}
          <div className="mb-6">
            <div className="text-xs font-medium mb-3" style={{ color: 'var(--life-text3)' }}>{t('settings.theme', language)}</div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {THEMES.map((th) => (
                <motion.button
                  key={th.value}
                  onClick={() => setTheme(th.value)}
                  className={`relative rounded-xl p-3 border-2 transition-all duration-300 group ${
                    theme === th.value
                      ? ''
                      : ''
                  }`}
                  style={{
                    borderColor: theme === th.value ? 'var(--life-accent)' : 'var(--life-border)',
                    backgroundColor: theme === th.value ? 'rgba(255,107,53,0.05)' : 'transparent',
                  }}
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.97 }}
                >
                  <div className={`w-full h-12 rounded-lg mb-2.5 bg-gradient-to-br ${th.gradient} flex items-center justify-center text-lg`}>
                    {th.icon}
                  </div>
                  <div className="text-xs font-medium text-center" style={{ color: 'var(--life-text)' }}>{t(th.labelKey, language)}</div>
                  {theme === th.value && (
                    <motion.div
                      className="absolute top-2 right-2 w-5 h-5 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: 'var(--life-accent)' }}
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: 'spring', stiffness: 300 }}
                    >
                      <Check className="w-3 h-3 text-white" />
                    </motion.div>
                  )}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Font Size Selection */}
          <div className="mb-6">
            <div className="text-xs font-medium mb-3 flex items-center gap-1.5" style={{ color: 'var(--life-text3)' }}>
              <Type className="w-3.5 h-3.5" />
              {t('settings.fontSize', language)}
            </div>
            <div className="flex gap-2">
              {FONT_SIZES.map((fs) => (
                <motion.button
                  key={fs.value}
                  onClick={() => setFontSize(fs.value)}
                  className="flex-1 rounded-xl py-3 px-2 transition-all duration-200 flex flex-col items-center gap-1.5"
                  style={{
                    backgroundColor: fontSize === fs.value ? 'rgba(255,107,53,0.1)' : 'var(--life-bg3)',
                    border: fontSize === fs.value ? '2px solid var(--life-accent)' : '1px solid var(--life-border)',
                  }}
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span className={`font-bold ${FONT_SIZE_SAMPLES[fs.value]}`} style={{ color: 'var(--life-text)' }}>A</span>
                  <span className="text-[10px]" style={{ color: 'var(--life-text2)' }}>{t(fs.labelKey, language)}</span>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Language Selection */}
          <div>
            <div className="text-xs font-medium mb-3 flex items-center gap-1.5" style={{ color: 'var(--life-text3)' }}>
              <Globe className="w-3.5 h-3.5" />
              {t('settings.language', language)}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <motion.button
                onClick={() => setLanguage('bn')}
                className="rounded-xl py-4 transition-all duration-200 flex flex-col items-center gap-2"
                style={{
                  backgroundColor: language === 'bn' ? 'rgba(255,107,53,0.1)' : 'var(--life-bg3)',
                  border: language === 'bn' ? '2px solid var(--life-accent)' : '1px solid var(--life-border)',
                }}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.97 }}
              >
                <span className="text-2xl">🇧🇩</span>
                <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>{t('settings.bengali', language)}</span>
              </motion.button>
              <motion.button
                onClick={() => setLanguage('en')}
                className="rounded-xl py-4 transition-all duration-200 flex flex-col items-center gap-2"
                style={{
                  backgroundColor: language === 'en' ? 'rgba(255,107,53,0.1)' : 'var(--life-bg3)',
                  border: language === 'en' ? '2px solid var(--life-accent)' : '1px solid var(--life-border)',
                }}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.97 }}
              >
                <span className="text-2xl">🇺🇸</span>
                <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>{t('settings.english', language)}</span>
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ===== Preferences Section ===== */}
      <motion.div
        variants={fadeInUp}
        className="rounded-xl p-5 relative overflow-hidden"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold uppercase tracking-wide mb-5 flex items-center gap-2" style={{ color: 'var(--life-text2)' }}>
            <Sliders className="w-4 h-4" style={{ color: '#F59E0B' }} />
            {t('settings.preferences', language)}
          </div>

          <div className="space-y-4">
            <div>
              <div className="text-xs font-medium mb-2" style={{ color: 'var(--life-text3)' }}>{t('settings.dailyBudget', language)}</div>
              <input
                type="number"
                className="w-full rounded-xl px-4 py-3 text-sm transition-colors"
                style={{ backgroundColor: 'var(--life-bg3)', border: '1px solid var(--life-border)', color: 'var(--life-text)' }}
                value={settings?.dailyBudget || 500}
                onChange={(e) => updateSettings({ dailyBudget: parseInt(e.target.value) || 500 })}
              />
            </div>
            <div>
              <div className="text-xs font-medium mb-2" style={{ color: 'var(--life-text3)' }}>{t('settings.waterGoal', language)}</div>
              <input
                type="number"
                className="w-full rounded-xl px-4 py-3 text-sm transition-colors"
                style={{ backgroundColor: 'var(--life-bg3)', border: '1px solid var(--life-border)', color: 'var(--life-text)' }}
                value={settings?.waterGoal || 8}
                onChange={(e) => updateSettings({ waterGoal: parseInt(e.target.value) || 8 })}
              />
            </div>
            <div>
              <div className="text-xs font-medium mb-2" style={{ color: 'var(--life-text3)' }}>{t('settings.height', language)}</div>
              <input
                type="number"
                className="w-full rounded-xl px-4 py-3 text-sm transition-colors"
                style={{ backgroundColor: 'var(--life-bg3)', border: '1px solid var(--life-border)', color: 'var(--life-text)' }}
                value={settings?.height || 170}
                onChange={(e) => updateSettings({ height: parseFloat(e.target.value) || 170 })}
              />
            </div>
          </div>
        </div>
      </motion.div>

      {/* ===== XP Level Display ===== */}
      <motion.div
        variants={fadeInUp}
        className="rounded-xl p-5 relative overflow-hidden"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="relative z-10">
          <div className="font-heading text-sm font-semibold uppercase tracking-wide mb-4 flex items-center gap-2" style={{ color: 'var(--life-text2)' }}>
            <Sparkles className="w-4 h-4" style={{ color: '#22C55E' }} />
            {language === 'bn' ? 'এক্সপিরিয়েন্স লেভেল' : 'Experience Level'}
          </div>

          <div className="flex items-center gap-4 mb-4">
            <div
              className="w-14 h-14 rounded-xl flex items-center justify-center text-xl font-bold font-heading text-white"
              style={{ backgroundColor: 'var(--life-accent)' }}
            >
              {level}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium" style={{ color: 'var(--life-text)' }}>
                  {t('xp.level', language)} {level}
                </span>
                <span className="text-xs" style={{ color: 'var(--life-text3)' }}>
                  {xp} / {xpForNextLevel} {t('xp.points', language)}
                </span>
              </div>
              <div className="h-3 rounded-full overflow-hidden" style={{ backgroundColor: 'var(--life-bg3)' }}>
                <motion.div
                  className="h-full rounded-full"
                  style={{ background: 'linear-gradient(90deg, var(--life-accent), var(--life-secondary))' }}
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(xpProgress, 100)}%` }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                />
              </div>
              <div className="text-[11px] mt-1" style={{ color: 'var(--life-text3)' }}>
                {t('xp.nextLevel', language)}: {level + 1} ({xpForNextLevel - xp} {t('xp.points', language)})
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* ===== Save Button ===== */}
      <motion.div variants={fadeInUp}>
        <button
          onClick={handleSave}
          className="w-full py-3.5 rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2 text-white"
          style={{ backgroundColor: 'var(--life-accent)' }}
        >
          <Save className="w-4 h-4" />
          {t('common.save', language)}
        </button>
        {saved && (
          <motion.div
            className="text-center py-2 text-sm"
            style={{ color: '#22C55E' }}
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
          >
            ✅ {language === 'bn' ? 'সেভ হয়েছে!' : 'Saved!'}
          </motion.div>
        )}
      </motion.div>

      {/* ===== About Section ===== */}
      <motion.div
        variants={fadeInUp}
        className="rounded-xl p-5 text-center"
        style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
      >
        <div className="text-3xl mb-3">🧭</div>
        <div className="font-heading text-lg font-bold mb-1" style={{ color: 'var(--life-accent)' }}>
          Life OS
        </div>
        <div className="text-xs mb-2 flex items-center justify-center gap-1" style={{ color: 'var(--life-text3)' }}>
          <Info className="w-3 h-3" />
          {t('settings.version', language)}: 2.0.0
        </div>
        <div className="text-xs flex items-center justify-center gap-1" style={{ color: 'var(--life-text3)' }}>
          <Heart className="w-3 h-3" style={{ color: '#EF4444' }} />
          {t('settings.madeWith', language)}
        </div>
      </motion.div>
    </motion.div>
  );
}
