'use client';

import { useLifeOSStore, BookItem } from '@/lib/store';
import { t } from '@/lib/i18n';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BookOpen, Plus, ChevronRight, Star, Trash2, Library, BookMarked, CheckCircle2, Clock } from 'lucide-react';
import { fadeInUp, staggerContainer } from '@/lib/animations';

// ===== Category Config =====
type BookCategory = 'islamic' | 'self-help' | 'technical' | 'fiction' | 'other';

const BOOK_CATEGORIES: { value: BookCategory; labelKey: string; color: string }[] = [
  { value: 'islamic', labelKey: 'books.islamic', color: '#22C55E' },
  { value: 'self-help', labelKey: 'books.selfHelp', color: '#F59E0B' },
  { value: 'technical', labelKey: 'books.technical', color: '#06B6D4' },
  { value: 'fiction', labelKey: 'books.fiction', color: '#A855F7' },
  { value: 'other', labelKey: 'books.other', color: '#6B7280' },
];

// ===== Status Config =====
type BookStatus = 'want-to-read' | 'reading' | 'completed';

const STATUS_CONFIG: Record<BookStatus, { labelKey: string; color: string; bgColor: string }> = {
  'want-to-read': { labelKey: 'books.wantToRead', color: '#F59E0B', bgColor: 'rgba(245, 158, 11, 0.15)' },
  'reading': { labelKey: 'books.reading', color: '#06B6D4', bgColor: 'rgba(6, 182, 212, 0.15)' },
  'completed': { labelKey: 'books.completed', color: '#22C55E', bgColor: 'rgba(34, 197, 94, 0.15)' },
};

// ===== Filter Tabs =====
type FilterTab = 'all' | 'want-to-read' | 'reading' | 'completed';

const FILTER_TABS: { value: FilterTab; labelKey: string }[] = [
  { value: 'all', labelKey: 'books.all' },
  { value: 'want-to-read', labelKey: 'books.wantToRead' },
  { value: 'reading', labelKey: 'books.reading' },
  { value: 'completed', labelKey: 'books.completed' },
];

export default function BooksPage() {
  const { books, addBook, updateBookProgress, deleteBook, updateBook, language } = useLifeOSStore();
  const [activeFilter, setActiveFilter] = useState<FilterTab>('all');
  const [showForm, setShowForm] = useState(false);
  const [formTitle, setFormTitle] = useState('');
  const [formAuthor, setFormAuthor] = useState('');
  const [formCategory, setFormCategory] = useState<BookCategory>('other');
  const [formTotalPages, setFormTotalPages] = useState('');
  const [editingProgressId, setEditingProgressId] = useState<string | null>(null);
  const [progressInput, setProgressInput] = useState('');

  // ===== Computed =====
  const filteredBooks = activeFilter === 'all'
    ? books
    : books.filter(b => b.status === activeFilter);

  const totalBooks = books.length;
  const readingCount = books.filter(b => b.status === 'reading').length;
  const completedCount = books.filter(b => b.status === 'completed').length;
  const totalPagesRead = books.reduce((sum, b) => sum + b.readPages, 0);

  // ===== Handlers =====
  const handleAddBook = async () => {
    if (!formTitle.trim()) return;
    const pages = parseInt(formTotalPages) || 0;
    await addBook(formTitle.trim(), formAuthor.trim(), formCategory, pages > 0 ? pages : 0);
    setFormTitle('');
    setFormAuthor('');
    setFormCategory('other');
    setFormTotalPages('');
    setShowForm(false);
  };

  const handleUpdateProgress = async (id: string) => {
    const val = parseInt(progressInput);
    if (isNaN(val) || val < 0) return;
    await updateBookProgress(id, val);
    setEditingProgressId(null);
    setProgressInput('');
  };

  const handleSetRating = async (id: string, rating: number) => {
    await updateBook(id, { rating });
  };

  const getCategoryInfo = (cat: string) => {
    return BOOK_CATEGORIES.find(c => c.value === cat) || BOOK_CATEGORIES[4];
  };

  const getStatusInfo = (status: string) => {
    return STATUS_CONFIG[status as BookStatus] || STATUS_CONFIG['want-to-read'];
  };

  // ===== Star Rating Component =====
  const StarRating = ({ book }: { book: BookItem }) => (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          onClick={() => handleSetRating(book.id, star)}
          className="transition-transform hover:scale-125"
        >
          <Star
            className={`w-3.5 h-3.5 ${
              star <= book.rating
                ? 'fill-amber-400 text-amber-400'
                : 'text-gray-600 hover:text-amber-300'
            }`}
          />
        </button>
      ))}
    </div>
  );

  return (
    <motion.div
      className="space-y-5 pb-4"
      variants={staggerContainer}
      initial="hidden"
      animate="show"
    >
      {/* ===== Page Header ===== */}
      <motion.div variants={fadeInUp} className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}
        >
          <BookOpen className="w-5 h-5" />
        </div>
        <div>
          <h1 className="font-heading text-xl font-bold" style={{ color: 'var(--life-text)' }}>
            {t('books.title', language)}
          </h1>
          <p className="text-xs" style={{ color: 'var(--life-text3)' }}>
            {t('books.subtitle', language)}
          </p>
        </div>
      </motion.div>

      {/* ===== Stats Section ===== */}
      <motion.div variants={fadeInUp} className="grid grid-cols-4 gap-3">
        {[
          { icon: Library, value: totalBooks, label: language === 'bn' ? 'মোট বই' : 'Total Books', color: 'var(--life-accent)' },
          { icon: Clock, value: readingCount, label: language === 'bn' ? 'পড়ছি' : 'Reading', color: '#06B6D4' },
          { icon: CheckCircle2, value: completedCount, label: language === 'bn' ? 'সম্পন্ন' : 'Completed', color: '#22C55E' },
          { icon: BookMarked, value: totalPagesRead, label: language === 'bn' ? 'পৃষ্ঠা পড়া' : 'Pages Read', color: '#F59E0B' },
        ].map((stat, i) => (
          <motion.div
            key={i}
            className="rounded-xl p-3 text-center relative overflow-hidden"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
            whileHover={{ scale: 1.03 }}
            transition={{ duration: 0.2 }}
          >
            <stat.icon className="w-4 h-4 mx-auto mb-1.5" style={{ color: stat.color }} />
            <div className="text-lg font-bold font-heading" style={{ color: stat.color }}>
              {stat.value}
            </div>
            <div className="text-[10px] mt-0.5" style={{ color: 'var(--life-text3)' }}>
              {stat.label}
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* ===== Filter Tabs ===== */}
      <motion.div variants={fadeInUp} className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
        {FILTER_TABS.map((tab) => {
          const isActive = activeFilter === tab.value;
          const statusColor = tab.value === 'all'
            ? 'var(--life-accent)'
            : STATUS_CONFIG[tab.value as BookStatus]?.color || 'var(--life-accent)';
          return (
            <button
              key={tab.value}
              onClick={() => setActiveFilter(tab.value)}
              className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all duration-200 ${
                isActive ? 'scale-105 shadow-lg' : 'opacity-60 hover:opacity-90'
              }`}
              style={{
                backgroundColor: isActive ? statusColor + '25' : 'var(--life-bg2)',
                color: isActive ? statusColor : 'var(--life-text2)',
                border: isActive ? `1.5px solid ${statusColor}50` : '1px solid var(--life-border)',
              }}
            >
              {t(tab.labelKey, language)}
            </button>
          );
        })}
      </motion.div>

      {/* ===== Add Book ===== */}
      <motion.div variants={fadeInUp}>
        {!showForm ? (
          <button
            onClick={() => setShowForm(true)}
            className="w-full rounded-xl p-4 border-2 border-dashed transition-all duration-300 flex items-center justify-center gap-2 group"
            style={{
              borderColor: 'var(--life-border)',
              color: 'var(--life-text2)',
            }}
          >
            <Plus className="w-4 h-4 transition-transform group-hover:scale-110" style={{ color: 'var(--life-accent)' }} />
            <span className="text-sm font-medium">{t('books.addBook', language)}</span>
          </button>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="rounded-xl p-5 relative overflow-hidden"
            style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
          >
            <div className="absolute bottom-0 right-0 w-24 h-24 rounded-full blur-2xl pointer-events-none" style={{ background: 'var(--life-accent)', opacity: 0.04 }} />

            <div className="relative z-10 space-y-3">
              {/* Title */}
              <input
                className="w-full border rounded-xl px-4 py-3 text-sm transition-colors placeholder:opacity-50 focus:outline-none"
                style={{
                  backgroundColor: 'var(--life-bg3, #1a1a2e)',
                  borderColor: 'var(--life-border)',
                  color: 'var(--life-text)',
                }}
                placeholder={t('books.bookTitle', language) + ' *'}
                value={formTitle}
                onChange={(e) => setFormTitle(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddBook()}
              />

              {/* Author */}
              <input
                className="w-full border rounded-xl px-4 py-3 text-sm transition-colors placeholder:opacity-50 focus:outline-none"
                style={{
                  backgroundColor: 'var(--life-bg3, #1a1a2e)',
                  borderColor: 'var(--life-border)',
                  color: 'var(--life-text)',
                }}
                placeholder={t('books.author', language)}
                value={formAuthor}
                onChange={(e) => setFormAuthor(e.target.value)}
              />

              {/* Category Pills */}
              <div>
                <div className="font-heading text-xs font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--life-text2)' }}>
                  {t('books.category', language)}
                </div>
                <div className="flex gap-2 flex-wrap">
                  {BOOK_CATEGORIES.map(cat => (
                    <button
                      key={cat.value}
                      onClick={() => setFormCategory(cat.value)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
                        formCategory === cat.value ? 'ring-2 scale-105' : 'opacity-60 hover:opacity-90'
                      }`}
                      style={{
                        background: cat.color + '20',
                        color: cat.color,
                        boxShadow: formCategory === cat.value ? `0 0 0 2px ${cat.color}` : 'none',
                      }}
                    >
                      {t(cat.labelKey, language)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Total Pages */}
              <div className="relative">
                <BookOpen className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 pointer-events-none" style={{ color: 'var(--life-text3)' }} />
                <input
                  type="number"
                  className="w-full border rounded-xl pl-10 pr-4 py-3 text-sm transition-colors placeholder:opacity-50 focus:outline-none"
                  style={{
                    backgroundColor: 'var(--life-bg3, #1a1a2e)',
                    borderColor: 'var(--life-border)',
                    color: 'var(--life-text)',
                  }}
                  placeholder={t('books.totalPages', language)}
                  min={0}
                  value={formTotalPages}
                  onChange={(e) => setFormTotalPages(e.target.value)}
                />
              </div>

              {/* Buttons */}
              <div className="flex gap-3 pt-1">
                <button
                  onClick={handleAddBook}
                  disabled={!formTitle.trim()}
                  className="flex-1 py-3 rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2 disabled:opacity-40"
                  style={{
                    backgroundColor: 'var(--life-accent)',
                    color: '#FFFFFF',
                  }}
                >
                  <Plus className="w-4 h-4" />
                  {t('books.add', language)}
                </button>
                <button
                  onClick={() => {
                    setShowForm(false);
                    setFormTitle('');
                    setFormAuthor('');
                    setFormTotalPages('');
                  }}
                  className="px-5 py-3 rounded-xl text-sm transition-colors"
                  style={{
                    backgroundColor: 'var(--life-bg3, #1a1a2e)',
                    color: 'var(--life-text2)',
                  }}
                >
                  {t('common.cancel', language)}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>

      {/* ===== Book List ===== */}
      <AnimatePresence mode="popLayout">
        {filteredBooks.length > 0 ? (
          <motion.div variants={fadeInUp} className="space-y-3">
            {filteredBooks.map((book) => {
              const catInfo = getCategoryInfo(book.category);
              const statusInfo = getStatusInfo(book.status);
              const progressPercent = book.totalPages > 0
                ? Math.min(Math.round((book.readPages / book.totalPages) * 100), 100)
                : 0;

              return (
                <motion.div
                  key={book.id}
                  layout
                  className="rounded-xl p-4 relative overflow-hidden group"
                  style={{ backgroundColor: 'var(--life-bg2)', border: '1px solid var(--life-border)' }}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Category accent line */}
                  <div
                    className="absolute left-0 top-0 bottom-0 w-1 rounded-l-2xl"
                    style={{ background: catInfo.color }}
                  />

                  <div className="pl-3">
                    {/* Header Row */}
                    <div className="flex items-start gap-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                        style={{ backgroundColor: catInfo.color + '15' }}
                      >
                        <BookOpen className="w-4.5 h-4.5" style={{ color: catInfo.color }} />
                      </div>

                      <div className="flex-1 min-w-0">
                        {/* Title & Badges */}
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span className="text-sm font-semibold truncate" style={{ color: 'var(--life-text)' }}>
                            {book.title}
                          </span>
                          <span
                            className="text-[10px] px-2.5 py-0.5 rounded-full font-medium flex-shrink-0"
                            style={{ background: catInfo.color + '20', color: catInfo.color }}
                          >
                            {t(catInfo.labelKey, language)}
                          </span>
                          <span
                            className="text-[10px] px-2.5 py-0.5 rounded-full font-medium flex-shrink-0"
                            style={{ background: statusInfo.bgColor, color: statusInfo.color }}
                          >
                            {t(statusInfo.labelKey, language)}
                          </span>
                        </div>

                        {/* Author */}
                        {book.author && (
                          <div className="text-xs mb-2" style={{ color: 'var(--life-text3)' }}>
                            {book.author}
                          </div>
                        )}

                        {/* Progress Bar */}
                        {book.totalPages > 0 && (
                          <div className="mb-2">
                            <div className="flex items-center gap-3 mb-1">
                              <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ backgroundColor: 'var(--life-bg3, #1a1a2e)' }}>
                                <motion.div
                                  className="h-full rounded-full"
                                  style={{ background: statusInfo.color }}
                                  initial={{ width: 0 }}
                                  animate={{ width: `${progressPercent}%` }}
                                  transition={{ duration: 0.6, ease: 'easeOut' }}
                                />
                              </div>
                              <span className="text-[11px] font-bold min-w-[44px] text-right" style={{ color: statusInfo.color }}>
                                {book.readPages}/{book.totalPages}
                              </span>
                            </div>
                            <div className="text-[10px]" style={{ color: 'var(--life-text3)' }}>
                              {progressPercent}% · {t('books.pagesRead', language)}
                            </div>
                          </div>
                        )}

                        {/* Progress Update */}
                        {editingProgressId === book.id ? (
                          <div className="flex gap-2 mt-2 items-center">
                            <input
                              type="number"
                              className="w-24 border rounded-lg px-3 py-1.5 text-xs transition-colors focus:outline-none"
                              style={{
                                backgroundColor: 'var(--life-bg3, #1a1a2e)',
                                borderColor: 'var(--life-border)',
                                color: 'var(--life-text)',
                              }}
                              placeholder={t('books.updateProgress', language)}
                              min={0}
                              max={book.totalPages || 9999}
                              value={progressInput}
                              onChange={(e) => setProgressInput(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleUpdateProgress(book.id)}
                              autoFocus
                            />
                            <button
                              onClick={() => handleUpdateProgress(book.id)}
                              className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
                              style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}
                            >
                              {t('common.save', language)}
                            </button>
                            <button
                              onClick={() => { setEditingProgressId(null); setProgressInput(''); }}
                              className="text-xs transition-colors"
                              style={{ color: 'var(--life-text3)' }}
                            >
                              {t('common.cancel', language)}
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-3 mt-2">
                            <button
                              onClick={() => {
                                setEditingProgressId(book.id);
                                setProgressInput(String(book.readPages));
                              }}
                              className="text-[11px] font-medium transition-colors flex items-center gap-1"
                              style={{ color: 'var(--life-accent)' }}
                            >
                              <ChevronRight className="w-3 h-3" />
                              {t('books.updateProgress', language)}
                            </button>
                          </div>
                        )}

                        {/* Star Rating */}
                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-[10px]" style={{ color: 'var(--life-text3)' }}>
                            {t('books.rate', language)}
                          </span>
                          <StarRating book={book} />
                        </div>
                      </div>

                      {/* Delete Button */}
                      <button
                        onClick={() => deleteBook(book.id)}
                        className="p-1.5 rounded-lg transition-all opacity-40 hover:opacity-100"
                        style={{ color: 'var(--life-text3)' }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        ) : (
          <motion.div
            variants={fadeInUp}
            className="rounded-xl p-8 border-2 border-dashed text-center"
            style={{
              backgroundColor: 'var(--life-bg2)',
              borderColor: 'var(--life-border)',
            }}
          >
            <BookOpen className="w-12 h-12 mx-auto mb-4" style={{ color: 'var(--life-accent)' }} />
            <div className="text-sm mb-4" style={{ color: 'var(--life-text3)' }}>
              {t('books.noBooks', language)}
            </div>
            <button
              onClick={() => setShowForm(true)}
              className="px-5 py-2.5 rounded-xl text-sm font-semibold transition-colors inline-flex items-center gap-2"
              style={{ backgroundColor: 'var(--life-accent)', color: '#FFFFFF' }}
            >
              <Plus className="w-4 h-4" />
              {t('books.addBook', language)}
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
